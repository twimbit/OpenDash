<?php 
include_once(PCMA_DIR . '/default_mail_texts.php'); 
include_once(PC_DIR . '/functions.php'); 



// user categories
$user_cats = get_terms('pg_user_categories', 'orderby=name&hide_empty=0'); 

// WP pages list
$pages = pc_get_pages(); 


// given an array - print mail placeholders legend block
function pcma_phs_legend($ph) {
	$trs = ''; 	
	foreach($ph as $code => $txt) {
		$trs .= '<tr><td style="width: 180px;">'.$code.'</td><td><p class="lcwp_sf_note">'. $txt .'</p></td></tr>';
	}
	
	return array(
		'label'		=> __('Allowed variables for title and text', 'pcma_ml') .'<p class="lcwp_sf_note">'. __('Remember you can use <a href="http://www.lcweb.it/privatecontent/user-data-add-on" target="_blank">User Data add-on</a> shortcode to insert custom fields into the mail text', 'pcma_ml') .'</p>',
		'type'		=> 'label_message',
		'content'	=> '<table class="pcma_placholders_legend">'. $trs .'</table>'
	);
}



////////////////////////////////////////////////////////////



// PCMA-FILTER - manipulate settings tabs
$tabs = array(
	'main_opts' 	=> __('Main Options', 'pcma_ml'),
	'users_verif' 	=> __('Users Verification', 'pcma_ml'),
	'admin_notif'	=> __('Admin Notifier', 'pcma_ml'),
	'user_notif' 	=> __('User Notifier', 'pcma_ml'),
	'welcome_mess' 	=> __('Welcome Message', 'pcma_ml'),
	'import_mess' 	=> __('Import Message', 'pcma_ml'),
	'psw_recovery' 	=> __('Password Recovery', 'pcma_ml'),
	'mailchimp' 	=> __('Mailchimp', 'pcma_ml'),
);
$GLOBALS['pcma_settings_tabs'] = apply_filters('pcma_settings_tabs', $tabs);	




// STRUCTURE
/* tabs index => array( 
	'sect_id' => array(
		'sect_name'	=> name
		'fields'	=> array(
			...
		)
	)
   )
*/

$structure = array();


// MAIN OPTIONS
$structure['main_opts'] = array(
	'mail_data' => array(
		'sect_name'	=>  __('E-mail Data <small>(mandatory to use the add-on)</small>', 'pcma_ml'),
		'fields' 	=> array(
			
			'pcma_from_name' => array(
				'label' 	=> __('"Sent From" name', 'pcma_ml'),
				'type'		=> 'text',
				'def'		=> get_bloginfo('name'),
				'required'	=> true,
				'maxlen'	=> 100,
				'note'		=> __('Name shown in "Sent From" field of the e-mail', 'pcma_ml'),
			),
			'pcma_from_mail' => array(
				'label' 	=> __('"Sent From" e-mail', 'pcma_ml'),
				'type'		=> 'text',
				'def'		=> get_bloginfo('admin_email'),
				'required'	=> true,
				'subtype'	=> 'email',
				'maxlen'	=> 100,
				'note'		=> __('E-mail address shown in "Sent From" field of the e-mail', 'pcma_ml'),
			),
			'pcma_reply_to_name' => array(
				'label' 	=> __('"Reply To" name', 'pcma_ml'),
				'type'		=> 'text',
				'def'		=> get_bloginfo('admin_email'),
				'required'	=> true,
				'maxlen'	=> 100,
				'note'		=> __('Name shown in the "Reply To" field of the e-mail', 'pcma_ml'),
			),
			'pcma_reply_to_mail' => array(
				'label' 	=> __('"Reply To" e-mail', 'pcma_ml'),
				'type'		=> 'text',
				'def'		=> get_bloginfo('admin_email'),
				'required'	=> true,
				'subtype'	=> 'email',
				'maxlen'	=> 100,
				'note'		=> __('E-mail address shown in the "Reply To" field of the e-mail', 'pcma_ml'),
			),
		),
	),
		
		
	'smtp' => array(
		'sect_name'	=>  __('SMTP configuration', 'pcma_ml'),
		'fields' 	=> array(
			
			'pcma_use_smtp' => array(
				'label' => __('Use SMTP to send e-mails?', 'pcma_ml'),
				'type'	=> 'checkbox',
				'note'	=> __('If checked, use the SMTP protocol to send e-mails (use only if required by your server)', 'pcma_ml'),
			),
			'pcma_smtp_host' => array(
				'label' => __('SMTP server address', 'pcma_ml'),
				'type'	=> 'text',
			),
			'pcma_smtp_port' => array(
				'label' 	=> __('SMTP port', 'pcma_ml'),
				'type'		=> 'text',
				'subtype' 	=> 'int',
				'maxlen'	=> 4,
			),
			'pcma_smtp_user' => array(
				'label' 	=> __('E-mail username', 'pcma_ml'),
				'type'		=> 'text',
				'def'		=> get_bloginfo('name'),
				'maxlen'	=> 100,
				'note'		=> __('Username to access the e-mail (normally is the e-mail address itself)', 'pcma_ml'),
			),
			'pcma_smtp_psw' => array(
				'label' 	=> __('E-mail password', 'pcma_ml'),
				'type'		=> 'psw',
				'note'		=> __('Password to access the e-mail <strong>(FYI: is saved but not shown)</strong>', 'pcma_ml'),
			),
			'pcma_use_smtp_auth' => array(
				'label' => __('Require SMTP authorization', 'pcma_ml'),
				'type'	=> 'checkbox',
				'note'	=> __('If checked, use the SMTP protocol to send e-mails (use only if required by your server)', 'pcma_ml'),
			),
			'pcma_smtp_secure' => array(
				'label' => __("Security protocol", 'pcma_ml'),
				'type'	=> 'select',
				'val' 	=> array('none' => __('None', 'pcma_ml'), 'ssl' => 'SSL', 'tcl' => 'TLS'),
			),
		),
	),	
);		
	
// mail tester
if(pcma_is_active()) {
	$structure['main_opts']['mail_tester'] = array(
		'sect_name'	=>  __('Test e-mail settings', 'pcma_ml'),
		'fields' 	=> array(
			
			'pcma_test_mail' => array(
				'label' 	=> __('Send a test e-mail to', 'pcma_ml'),
				'type'		=> 'text',
				'no_save'	=> true,
				'maxlen'	=> 100,
				'note'		=> __('E-mail test receiver', 'pcma_ml'),
			),	
			'pcma_test_mail_btn' => array(
				'type'		=> 'message',
				'content'	=> '<input type="button" id="pcma_test_btn" value="'. __('Send E-mail', 'pcma_ml') .'" class="button-secondary" /> <span id="pcma_test_result" style="padding-left: 25px;"></span>'
			),	
		),
	);
}



// USERS VERIFICATION
$structure['users_verif'] = array(
	'mv_enable' => array(
		'sect_name'	=>  __('Users Verification Through E-mail', 'pcma_ml'),
		'fields' 	=> array(
			
			'pcma_mv_enable' => array(
				'label' => __('Enable users verification?', 'pcma_ml'),
				'type'	=> 'checkbox',
				'note'	=> __("If checked, an-email will be sent to pending users to auto-validate and activate their account", 'pcma_ml'),
			),
		),
	),
	
	'mv_landing_pag' => array(
		'sect_name'	=>  __('Landing Page Setup', 'pcma_ml'),
		'fields' 	=> array(
			
			'pcma_mv_pag' => array(
				'label' 	=> __('Choose a page', 'pcma_ml'),
				'type'		=> 'select',
				'val' 		=> $pages,
				'fullwidth' => true,
				'note'		=> __('Page to use as validation target. If opened directly, redicrects to the homepage. <strong style="color: #D54E21;">Because of this, should be a brand new page!</strong>', 'pcma_ml'),
			),
			'pcma_mv_ok_mess' => array(
				'label' => __("Confirmation message", 'pcma_ml') .'<p class="lcwp_sf_note">'. __('By default is: "Your account has been successfully activated!"', 'pcma_ml') .'</p>',
				'type'	=> 'wp_editor',
				'rows' 	=> 2,
			), 
			'pcma_mv_act_mess' => array(
				'label' => __("Already active message", 'pcma_ml') .'<p class="lcwp_sf_note">'. __('By default is: "Your account has been already activated!"', 'pcma_ml') .'</p>',
				'type'	=> 'wp_editor',
				'rows' 	=> 2,
			), 
			'pcma_mv_bad_mess' => array(
				'label' => __("Error message", 'pcma_ml') .'<p class="lcwp_sf_note">'. __('By default is: "Sorry, your request is invalid or your account has been deleted"', 'pcma_ml') .'</p>',
				'type'	=> 'wp_editor',
				'rows' 	=> 2,
			), 
		),
	),
	
	'mv_mail_builder' => array(
		'sect_name'	=>  __('E-mail builder', 'pcma_ml'),
		'fields' 	=> array(
			
			'mv_legend' => pcma_phs_legend(
				array(
					'%SITE-TITLE%'	=> __('Website title specified in WP settings', 'pcma_ml'),
					'%NAME%'		=> __("User's name", 'pcma_ml'),
					'%SURNAME%'		=> __("User's surame", 'pcma_ml'),
					'%USERNAME%'	=> __("User's userame", 'pcma_ml'),
					'%TEL%'			=> __("User's telephone", 'pcma_ml'),
					'%CAT%'			=> __("User categories", 'pcma_ml'),
					'%VER-URL%'		=> __("Verification URL", 'pcma_ml').' <small style="color: #D54E21;"><strong>('. __("mandatory in e-mail text", 'pcma_ml').')'
				)
			),
			'pcma_mv_subj' => array(
				'label' 	=> __('E-mail title', 'pcma_ml'),
				'type'		=> 'text',
				'def' 		=> $mail_texts['pcma_mv_subj'],
				'fullwidth' => true,
			),
			'pcma_mv_txt' => array(
				'label' => __("E-mail text", 'pcma_ml'),
				'type'	=> 'wp_editor',
				'def' 	=> $mail_texts['pcma_mv_txt'],
				'rows' 	=> 13,
			), 
		),
	),

	'manual_mv' => array(
		'sect_name'	=>  __('Manual E-mail Verification', 'pcma_ml'),
		'fields' 	=> array(
	
			'pcma_manual_mv_field' => array(
				'type'		=> 'custom',
				'callback'	=> 'pcma_manual_mv_field'
			), 
		),
	),
);



// ADMIN NOTIFIER
$structure['admin_notif'] = array(
	
	'pcma_admin_notif_main' => array(
		'sect_name'	=>  __('Common settings', 'pcma_ml'),
		'fields' 	=> array(
			
			'pcma_nnu_mail_multi' => array(
				'type'		=> 'custom',
				'callback'	=> 'pcma_nnu_mail_multi_field',
				'validation'=> array(
					array('index' => 'pcma_nnu_mail_multi', 'label' => __('Admin Notifier - e-mail address', 'pcma_ml'))
				)
			),
			'nnu_legend' => pcma_phs_legend(
				array(
					'%SITE-TITLE%'	=> __('Website title specified in WP settings', 'pcma_ml'),
					'%NAME%'		=> __("User's name", 'pcma_ml'),
					'%SURNAME%'		=> __("User's surame", 'pcma_ml'),
					'%USERNAME%'	=> __("User's userame", 'pcma_ml'),
					'%MAIL%'		=> __("User's e-mail", 'pcma_ml'),
					'%TEL%'			=> __("User's telephone", 'pcma_ml'),
					'%CAT%'			=> __("User categories", 'pcma_ml'),
				)
			),
		),
	),
	
	
	'nnu_mail_builder' => array(
		'sect_name'	=>  __('New Users Notification', 'pcma_ml'),
		'fields' 	=> array(
			
			'pcma_nnu_enable' => array(
				'label' => __('Notify new users?', 'pcma_ml'),
				'type'	=> 'checkbox',
				'note'	=> __("If checked, send an e-mail when a new user registers", 'pcma_ml'),
			),
			'pcma_nnu_subj' => array(
				'label' 	=> __('E-mail title', 'pcma_ml'),
				'type'		=> 'text',
				'def' 		=> $mail_texts['pcma_nnu_subj'],
				'fullwidth' => true,
			),
			'pcma_nnu_txt' => array(
				'label' => __("E-mail text", 'pcma_ml'),
				'type'	=> 'wp_editor',
				'def' 	=> $mail_texts['pcma_nnu_txt'],
				'rows' 	=> 13,
			), 
		),
	),
	
	'dun_mail_builder' => array(
		'sect_name'	=>  __('Deleted Users Notification', 'pcma_ml'),
		'fields' 	=> array(
			
			'pcma_dun_enable' => array(
				'label' => __('Notify deleted users?', 'pcma_ml'),
				'type'	=> 'checkbox',
				'note'	=> __("If checked, send an e-mail when a user self-deletes itself", 'pcma_ml'),
			),
			'pcma_dun_subj' => array(
				'label' 	=> __('E-mail title', 'pcma_ml'),
				'type'		=> 'text',
				'def' 		=> $mail_texts['pcma_dun_subj'],
				'fullwidth' => true,
			),
			'pcma_dun_txt' => array(
				'label' => __("E-mail text", 'pcma_ml'),
				'type'	=> 'wp_editor',
				'def' 	=> $mail_texts['pcma_dun_txt'],
				'rows' 	=> 7,
			), 
		),
	),
);



// USER NOTIFIER
$structure['user_notif'] = array(
	'pcma_nau_enable_switch' => array(
		'sect_name'	=>  __('Activated Users Notification', 'pcma_ml'),
		'fields' 	=> array(
			
			'pcma_nau_enable' => array(
				'label' => __('Notify activated users?', 'pcma_ml'),
				'type'	=> 'checkbox',
				'note'	=> __("If checked, an e-mail is sent to pending users when they are activated by admins", 'pcma_ml'),
			),
		),
	),
	
	'nnu_mail_builder' => array(
		'sect_name'	=>  __('E-mail builder', 'pcma_ml'),
		'fields' 	=> array(
			
			'nau_legend' => pcma_phs_legend(
				array(
					'%SITE-TITLE%'	=> __('Website title specified in WP settings', 'pcma_ml'),
					'%NAME%'		=> __("User's name", 'pcma_ml'),
					'%SURNAME%'		=> __("User's surame", 'pcma_ml'),
					'%USERNAME%'	=> __("User's userame", 'pcma_ml'),
					'%TEL%'			=> __("User's telephone", 'pcma_ml'),
					'%CAT%'			=> __("User categories", 'pcma_ml'),
				)
			),
			'pcma_nau_subj' => array(
				'label' 	=> __('E-mail title', 'pcma_ml'),
				'type'		=> 'text',
				'def' 		=> $mail_texts['pcma_nau_subj'],
				'fullwidth' => true,
			),
			'pcma_nau_txt' => array(
				'label' => __("E-mail text", 'pcma_ml'),
				'type'	=> 'wp_editor',
				'def' 	=> $mail_texts['pcma_nau_txt'],
				'rows' 	=> 13,
			), 
		),
	),
);



// WELCOME MESSAGE
$structure['welcome_mess'] = array(
	'pcma_wm_enable_switch' => array(
		'sect_name'	=>  __('Welcome message e-mail', 'pcma_ml'),
		'fields' 	=> array(
			
			'pcma_wm_enable' => array(
				'label' => __('E-mail registered users?', 'pcma_ml'),
				'type'	=> 'checkbox',
				'note'	=> __("If checked, sends a welcome e-mail to registered users", 'pcma_ml'),
			),
			'pcma_wm_receiver' => array(
				'label' => __("Send welcome message to", 'pcma_ml'),
				'type'	=> 'select',
				'val' 	=> array(
					'active_users' 	=> __("Only active users", 'pcma_ml'), 
					'any_user'		=> __("Any user", 'pcma_ml')
				),
			),
		),
	),
	
	'wm_mail_builder' => array(
		'sect_name'	=>  __('E-mail builder', 'pcma_ml'),
		'fields' 	=> array(
			
			'wm_legend' => pcma_phs_legend(
				array(
					'%SITE-TITLE%'	=> __('Website title specified in WP settings', 'pcma_ml'),
					'%NAME%'		=> __("User's name", 'pcma_ml'),
					'%SURNAME%'		=> __("User's surame", 'pcma_ml'),
					'%USERNAME%'	=> __("User's userame", 'pcma_ml'),
					'%TEL%'			=> __("User's telephone", 'pcma_ml'),
					'%CAT%'			=> __("User categories", 'pcma_ml'),
				)
			),
			'pcma_wm_subj' => array(
				'label' 	=> __('E-mail title', 'pcma_ml'),
				'type'		=> 'text',
				'def' 		=> $mail_texts['pcma_wm_subj'],
				'fullwidth' => true,
			),
			'pcma_wm_txt' => array(
				'label' => __("E-mail text", 'pcma_ml'),
				'type'	=> 'wp_editor',
				'def' 	=> $mail_texts['pcma_wm_txt'],
				'rows' 	=> 13,
			), 
		),
	),
);



// IMPORT MESSAGE
$structure['import_mess'] = array(
	'pcma_niu_enable_switch' => array(
		'sect_name'	=>  __('Imported Users Notifier', 'pcma_ml'),
		'fields' 	=> array(
			
			'pcma_niu_enable' => array(
				'label' => __('Notify imported users?', 'pcma_ml'),
				'type'	=> 'checkbox',
				'note'	=> __("If checked, notifies imported users having an e-mail", 'pcma_ml'),
			),
		),
	),
	
	'niu_mail_builder' => array(
		'sect_name'	=>  __('E-mail builder', 'pcma_ml'),
		'fields' 	=> array(
			
			'niu_legend' => pcma_phs_legend(
				array(
					'%SITE-TITLE%'	=> __('Website title specified in WP settings', 'pcma_ml'),
					'%NAME%'		=> __("User's name", 'pcma_ml'),
					'%SURNAME%'		=> __("User's surame", 'pcma_ml'),
					'%USERNAME%'	=> __("User's userame", 'pcma_ml'),
					'%PSW%'			=> __("User's password", 'pcma_ml'),
					'%TEL%'			=> __("User's telephone", 'pcma_ml'),
					'%CAT%'			=> __("User categories", 'pcma_ml'),
				)
			),
			'pcma_niu_subj' => array(
				'label' 	=> __('E-mail title', 'pcma_ml'),
				'type'		=> 'text',
				'def' 		=> $mail_texts['pcma_nau_subj'],
				'fullwidth' => true,
			),
			'pcma_niu_txt' => array(
				'label' => __("E-mail text", 'pcma_ml'),
				'type'	=> 'wp_editor',
				'def' 	=> $mail_texts['pcma_nau_txt'],
				'rows' 	=> 13,
			), 
		),
	),
);



// PASSWORD RECOVERY
$structure['psw_recovery'] = array(
	'pcma_pr_enable_switch' => array(
		'sect_name'	=>  __('Password Recovery system', 'pcma_ml'),
		'fields' 	=> array(
			
			'pcma_psw_recovery' => array(
				'label' => __('Enable password recovery system?', 'pcma_ml'),
				'type'	=> 'checkbox',
				'note'	=> __("If checked, allows users to recover their passwords via e-mail (through login form)", 'pcma_ml'),
			),
			'pcma_pr_with_email' => array(
				'label' => __('Allow recovery also through e-mail?', 'pcma_ml'),
				'type'	=> 'checkbox',
				'note'	=> __("If checked, allows users to recovery password also using their e-mail", 'pcma_ml') .'<br/><strong style="color: #D54E21;">'. __("Be sure database is ok with this: every user must have a unique e-mail", 'pcma_ml') .'</strong>',
			),
		),
	),
	
	'pr_mail_builder' => array(
		'sect_name'	=>  __('E-mail builder', 'pcma_ml'),
		'fields' 	=> array(
			
			'pr_legend' => pcma_phs_legend(
				array(
					'%SITE-TITLE%'	=> __('Website title specified in WP settings', 'pcma_ml'),
					'%NAME%'		=> __("User's name", 'pcma_ml'),
					'%SURNAME%'		=> __("User's surame", 'pcma_ml'),
					'%USERNAME%'	=> __("User's userame", 'pcma_ml'),
					'%PSW%'			=> __("New Password", 'pcma_ml') .'<small style="color: #D54E21;"><strong>('. __("mandatory in e-mail text", 'pcma_ml') .')</strong></small>',
					'%TEL%'			=> __("User's telephone", 'pcma_ml'),
					'%CAT%'			=> __("User categories", 'pcma_ml'),
				)
			),
			'pcma_psw_mail_subj' => array(
				'label' 	=> __('E-mail title', 'pcma_ml'),
				'type'		=> 'text',
				'def' 		=> $mail_texts['pcma_psw_mail_subj'],
				'fullwidth' => true,
			),
			'pcma_psw_mail_txt' => array(
				'label' => __("E-mail text", 'pcma_ml'),
				'type'	=> 'wp_editor',
				'def' 	=> $mail_texts['pcma_psw_mail_txt'],
				'rows' 	=> 13,
			), 
		),
	),
);



// MAILCHIMP
include_once(PCMA_DIR .'/classes/mailchimp_integration.php');
			
// get mailchimp lists
$mc = new pcma_mailchimp();
$mc_lists = ($mc->is_ready(true)) ? $mc->get_lists() : array();

$mc_lists_final = array('' => __("none", 'pcma_ml'));
foreach($mc_lists as $list) {
	$mc_lists_final[ $list['id'] ] = $list['name'];
}

// manual-sync text
$manual_sync_text = '
<input type="button" id="pcma_mc_sync" value="'. __('Manual Sync', 'pcma_ml') .'" class="button-secondary" />
<div id="pcma_mc_sync_result" style="display: inline-block; padding-left: 15px;"></div>';

$interests = get_option('pcma_interests');
if(empty($interests)) {
	$manual_sync_text .= '
	<p id="pcma_mc_sync_required" style="margin-top: 10px; margin-bottom: 2px;">
		<strong style="color: #D54E21;">'. __('IMPORTANT - no caterories synced yet. Manual sync required!', 'pcma_ml') .'</strong>
	</p>';	
}


$structure['mailchimp'] = array(
	'mailchimp_config' => array(
		'sect_name'	=>  __('Mailchimp Integration', 'pcma_ml'),
		'fields' 	=> array(
			
			'pcma_mc_apikey' => array(
				'label' 	=> __("Api Key", 'pcma_ml') .' (<a href="http://kb.mailchimp.com/article/where-can-i-find-my-api-key" target="_blank">'. __("How to get it?", 'pcma_ml') .'</a>)',
				'type'		=> 'text',
				'maxlen'	=> 40,
				'fullwidth' => true,
			),
			
			'pcma_mc_list' => array(
				'label' => __("Target list", 'pcma_ml'),
				'type'	=> 'select',
				'hide'	=> (empty($mc_lists)) ? true : false, 
				'val' 	=> $mc_lists_final,
				'note'	=> __("Select the list you want to use for sync (should <strong>NOT</strong> be changed in future)", 'pcma_ml')
			),
			'pcma_mc_auto_sync' => array(
				'label' => __('Auto-sync?', 'pcma_ml'),
				'type'	=> 'checkbox',
				'hide'	=> (empty($mc_lists)) ? true : false, 
				'note'	=> __("If checked, performs sync when a user is added or removed", 'pcma_ml'),
			),
			'pcma_mc_sync_all' => array(
				'label' => __('Sync also extra fields?', 'pcma_ml'),
				'type'	=> 'checkbox',
				'hide'	=> (empty($mc_lists)) ? true : false, 
				'note'	=> __("If checked, syncs any user's data into mailchimp's database", 'pcma_ml'),
			),
			'pcma_mc_def_discl' => array(
				'label' => __('Subscribe new users by default?', 'pcma_ml'),
				'type'	=> 'checkbox',
				'hide'	=> (empty($mc_lists)) ? true : false, 
				'note'	=> __("If checked and <strong>no disclaimer is used in registration form</strong>, subscribes new users", 'pcma_ml'),
			),
			'spcr1' => array(
				'type' => 'spacer',
				'hide'	=> (empty($mc_lists)) ? true : false, 
			),
			'pcma_mc_discl_txt' => array(
				'label' 	=> __("Form disclaimer's text", 'pcma_ml'),
				'type'		=> 'text',
				'def'		=> __('I want to receive periodical newsletters', 'pcma_ml'),
				'fullwidth' => true,
				'hide'	=> (empty($mc_lists)) ? true : false, 
			),
			'pcma_mc_unsub_hook' => array(
				'label' 	=> __("Unsubscribe user - Webhook URL", 'pcma_ml') .' (<a href="http://kb.mailchimp.com/integrations/api-integrations/how-to-set-up-webhooks#Set-Up-WebHooks" target="_blank">'. __("How to set it?", 'pcma_ml') .'</a>)',
				'type'		=> 'label_message',
				'content'	=> '<p style="color: #000; cursor: text; margin: 0;">'. trailingslashit( get_home_url()) .'?pcma_mc_unsubscribe</p>',
				'hide'	=> (empty($mc_lists)) ? true : false, 
			),
			
			'spcr2' => array(
				'type' => 'spacer',
			),
			'mc_warn' => array(
				'type' 		=> 'message',
				'content'	=> (empty($mc_lists) || get_option('pcma_mc_list')) ? __("Insert a valid API key and save settings to choose a list. A list must exists on your MailChimp account", 'pcma_ml') : __("Choose a list and save settings to start using sync system", 'pcma_ml'),
				'hide'	=> ($mc->is_ready()) ? true : false, 
			),
			'mc_manual_sync' => array(
				'type' 		=> 'message',
				'content'	=> $manual_sync_text,
				'hide'	=> ($mc->is_ready()) ? false : true, 
			)
		),
	),
);


// PC-FILTER - manipulate settings structure
$GLOBALS['pcma_settings_structure'] = apply_filters('pcma_settings_structure', $structure);
