<?php
////////////////////////////////////////////////////////
// PERFORM PSW RECOVERY ////////////////////////////////
////////////////////////////////////////////////////////

function pcma_do_psw_recovery() {
	if(!is_admin() && isset($_POST['pcma_username']) && isset($_POST['pcma_psw_recovery'])) {
		include_once(PCMA_DIR . '/functions.php');
		global $pc_users;
		
		$username = trim(stripslashes($_POST['pcma_username']));
		
		if(empty($username)) {$error = __('Username not found or disabled', 'pcma_ml');}
		else {
			global $wpdb;
			
			// only username or also e-mail?
			$username_part = (get_option('pcma_pr_with_email')) ? '(username = %s OR email = %s)' : 'username = %s';
			$wpdb_prepare_vars = (get_option('pcma_pr_with_email')) ? array(trim($username), trim($username)) : array(trim($username));
			
			
			$user_data = $wpdb->get_row( 
				$wpdb->prepare(
					"SELECT * FROM  ".PC_USERS_TABLE." WHERE ". $username_part ." AND status = 1 LIMIT 1",
					$wpdb_prepare_vars
				) 
			, ARRAY_A);
			
			if(empty($user_data)) {$error = __('Username not found or disabled', 'pcma_ml');}
			else {
				if(empty($user_data['email'])) {
					$error = __("Your account doesn't have an e-mail", 'pcma_ml');	
				}
				else {
					$mail_txt = get_option('pcma_psw_mail_txt');
					
					// reset password
					///// be sure psw matches with strength params
					include_once(PC_DIR .'/classes/pc_form_framework.php');
					$f_fw = new pc_form();
					$new_psw = wp_generate_password(10, true);
					
					while($f_fw->check_psw_strength($new_psw) !== true) {
						$new_psw = wp_generate_password(10, true);	
					}
					
					// replace placeholder
					$mail_txt = str_replace('%PSW%', $new_psw, $mail_txt);
					
					// update user psw
					$result = $pc_users->update_user($user_data['id'], array('psw' => $new_psw));
					if(!$result) {
						$error = __("Error updating password in database", 'pcma_ml');		
					}
					
					// perform only if there are no errors
					if(!isset($error)) {
						$mail_title = pcma_replace_placeholders($user_data['id'], get_option('pcma_psw_mail_subj'), $user_data);
						$mail_txt = pcma_replace_placeholders($user_data['id'], $mail_txt, $user_data);
						
						// send mail
						$mail_sent = pcma_send_mail($user_data['username'], $user_data['email'], $mail_title, $mail_txt);
						if(!$mail_sent) {
							$error = __("Error sending the e-mail", 'pcma_ml');
						}
					}
				}
			}	
		}
		
		if(isset($error)) {
			$resp = array('resp' => 'error', 'mess' => $error);	
			echo json_encode($resp);
		}
		else {
			
			// PCMA ACTION - USER PASSWORD HAS BEEN RESETTED
			do_action('pcma_resetted_psw', $user_data['id']);
			
			$resp = array('resp' => 'success', 'mess' => __("Password has been sent to your e-mail address", 'pcma_ml'));	
			echo json_encode($resp);	
		}
		
		die();
	}
}
add_action('init', 'pcma_do_psw_recovery');
