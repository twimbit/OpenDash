<?php 
include_once(PC_DIR . '/functions.php'); 
include_once(PCMA_DIR . '/functions.php'); 

global $pc_users;

// check ad-on setup
if(!pcma_is_active()) {
	echo '<p>&nbsp;</p><div class="error"><p>'. __('Add-on must be configured to use this module', 'pcma_ml') .'</p></div>';
	exit;	
}
?>
<style type="text/css">
#post-body-content {
	display: inline-block;
	width: 73%;
}
#poststuff {
	float: right;
	display: inline-block;
	width: 25%;
	min-width: 0;
	padding-top: 0;
	margin-left: 2%;
}
.pc_table input[type=text],
.pc_table select,
.pc_table textarea {
	width: 90%;	
}
.pcma_legend_table tr td {
	padding: 10px 0;
	border-bottom: 1px dashed #eaeaea;	
}
.pcma_legend_table tr:first-child td {
	padding-top: 0;	
}
.pcma_legend_table tr:last-child td {
	border-bottom: none;
	padding-bottom: 0;	
}
.pcma_legend_table tr td:last-child {
	font-style:italic;
	color: #8a8a8a;
}
.chosen-container-multi .chosen-choices,
#pcma_su_to_sel {
	border-color: #ccc;	
}

.ui-autocomplete {
	border-color: #ccc;
    box-shadow: 0 4px 4px rgba(0, 0, 0, 0.15);
    max-height: 200px;
    overflow-x: hidden;
    overflow-y: auto;
}
.ui-autocomplete li {
	border-bottom: 1px solid #ddd;
    padding: 6px;	
}
.ui-autocomplete li:last-child {
	border: none;	
}
input.ui-autocomplete-loading[type="text"] {
	background-image: url('<?php echo PC_URL ?>/img/loader.gif');	
	background-position: 99.5% 3px;
}

#pcma_su_to_list {
	width: 90%;
}
#pcma_su_to_list li {
	border-top: 1px dotted #aaa;
	padding: 6px 10px 8px 5px;	
	background: #fff;
}
#pcma_su_to_list li:first-child {
	margin-top: 15px;
}
#pcma_su_to_list li:last-child {
	border-bottom: 1px dotted #ccc;	
	margin-bottom: 3px;
}
#pcma_su_to_list li:hover {
	background-color: #fefefe;
}
#pcma_su_to_list .pc_del_field {
	margin-right: 15px;	
	display: inline-block;
	position: relative;
	bottom: -3px;
	
	-ms-transform: 		scale(0.85);
	-webkit-transform: 	scale(0.85);
	transform: 			scale(0.85);
}
</style>

<div class="wrap pc_form lcwp_form">  
	<div class="icon32" id="icon-pc_user_manage"><br></div>
    <?php echo '<h2 class="pc_page_title">PrivateContent - Quick Mail</h2>'; ?>  

    <?php
	// HANDLE DATA
	if(isset($_POST['pcma_send_mail'])) { 
		if (!isset($_POST['pc_nonce']) || !wp_verify_nonce($_POST['pc_nonce'], 'lcwp')) {die('<p>Cheating?</p>');};
		include_once(PC_DIR . '/classes/simple_form_validator.php');		

		$validator = new simple_fv;
		$indexes = array();
		
		$indexes[] = array('index'=>'pcma_qm_title', 'label'=>__('E-mail title', 'pcma_ml'), 'required'=>true, 'max_len'=>200);
		$indexes[] = array('index'=>'pcma_qm_txt', 'label'=>__('E-mail text', 'pcma_ml'), 'required'=>true);
		$indexes[] = array('index'=>'pcma_qm_to', 'label'=>'Send to');
		$indexes[] = array('index'=>'pcma_su_to', 'label'=>'Send to - single users');
		$indexes[] = array('index'=>'pcma_attach', 'label'=>__('Attachment', 'pcma_ml'));
		
		$validator->formHandle($indexes);
		$fdata = $validator->form_val;
		
		// check if one category or single user is selected
		if(empty($fdata['pcma_qm_to']) && empty($fdata['pcma_su_to'])) {
			$validator->custom_error[ __('Receivers', 'pcma_ml') ] = __('Please select a user category or a specific user', 'pcma_ml'); 	
		}
		
		$error = $validator->getErrors();
		
		if($error) {echo '<div class="error"><p>'.$error.'</p></div>';}
		else {
			
			//// RECEIVERS
			$user_query = array();
			
			// categories - get user e-mails and check if there is at least one receiver
			if(!empty($fdata['pcma_qm_to'])) {
				$args = array(
					'status' => 1,
					'limit' => -1,
					'to_get' => array('id', 'email', 'psw', 'name', 'surname', 'username', 'tel', 'categories'),
					'search' => array(array('key'=>'email', 'operator'=>'!=', 'val'=>''))
				);
				
				if(!in_array('all', $fdata['pcma_qm_to'])) {
					$args['categories'] = $fdata['pcma_qm_to'];
				}
				$user_query = array_merge($user_query, $pc_users->get_users($args));
			}


			// single useres - get users data
			if(!empty($fdata['pcma_su_to'])) {
				$args = array(
					'limit' => -1,
					'user_id' => $fdata['pcma_su_to'],
					'to_get' => array('id', 'email', 'psw', 'name', 'surname', 'username', 'tel', 'categories'),
				);
				$user_query = array_merge($user_query, $pc_users->get_users($args));
			}
			

			// if no user has got mail
			if(!count($user_query)) {
				echo '
				<div class="pc_warn pcma_warn_box pc_warning">
					<p>'.__('No users with e-mail found', 'pcma_ml').' </p>
				</div>';
			}
			
			// send mail through public API
			else {
				$sent_to = array(); // array of users having already received the mail
				
				foreach($user_query as $ud) {
					if(in_array($ud['id'], $sent_to)) {continue;}
					$sent_to[] = $ud['id'];
					
					$mail_title = pcma_replace_placeholders($ud['id'], stripslashes($fdata['pcma_qm_title']), $ud);
					$mail_txt = pcma_replace_placeholders($ud['id'], stripslashes($fdata['pcma_qm_txt']), $ud); 
					$attach = (isset($_FILES['pcma_attach']) && !empty($_FILES['pcma_attach']['tmp_name'])) ? $_FILES['pcma_attach'] : false; 
					
					pcma_send_mail($ud['username'], $ud['email'], $mail_title, $mail_txt, $from_name = false, $from_mail = false, $reply_to_name = false, $reply_to_mail = false, $attach);	
				}
				
				echo '<div class="updated"><p><strong>'. __('E-mail sent successfully', 'pcma_ml') .'!</strong></p></div>';
				unset($fdata);
			}
		}
	}
	?>
    <form name="pcma_admin" method="post" class="form-wrap" action="<?php echo str_replace( '%7E', '~', $_SERVER['REQUEST_URI']); ?>" enctype="multipart/form-data">
        <br/>
        <div id="poststuff">
            <div class="postbox">
                <h3 class="hndle"><span><?php _e("Allowed Variables for title and text", 'pcma_ml'); ?></span></h3>
                <div class="inside">
                    <table class="pcma_legend_table">  
                      <tr>
                        <td style="width: 160px;">%SITE-TITLE%</td>
                        <td><span class="info"><?php _e("Website title specified in the WP settings", 'pcma_ml'); ?></span></td>
                      </tr>
                      <tr>
                        <td>%NAME%</td>
                        <td><span class="info"><?php _e("User's Name", 'pcma_ml'); ?></span></td>
                      </tr>
                      <tr>
                        <td>%SURNAME%</td>
                        <td><span class="info"><?php _e("User's Surname", 'pcma_ml'); ?></span></td>
                      </tr>
                      <tr>
                        <td>%USERNAME%</td>
                        <td><span class="info"><?php _e("User's Username", 'pcma_ml'); ?></span></td>
                      </tr>
                      <tr>
                        <td>%MAIL%</td>
                        <td><span class="info"><?php _e("User's E-mail", 'pcma_ml'); ?></span></td>
                      </tr>
                      <tr>
                        <td>%TEL%</td>
                        <td><span class="info"><?php _e("User's Telephone", 'pcma_ml'); ?></span></td>
                      </tr>
                      <tr>
                        <td>%CAT%</td>
                        <td><span class="info"><?php _e("User Categories", 'pcma_ml'); ?></span></td>
                      </tr>
                      <tr>
                        <td colspan="2" style="font-style: normal; color: inherit;"><?php _e('Remember you can use <a href="http://www.lcweb.it/privatecontent/user-data-add-on" target="_blank">User Data add-on</a> shortcode to insert custom fields into the mail text', 'pcma_ml') ?></td>
                      </tr>
                    </table>
                </div>
            </div>
		</div>
        
        
        <div id="post-body-content">
            <div id="titlediv">
                <div id="titlewrap">
                <input id="title" type="text" autocomplete="off" value="<?php if(isset($fdata['pcma_qm_title'])) echo $fdata['pcma_qm_title']; ?>" size="30" name="pcma_qm_title" placeholder="<?php _e('E-mail title', 'pcma_ml') ?>" maxlength="200" />
                </div>
            </div>
            <br/><br/>
            
            <div id="postdivrich" class="postarea wp-editor-expand">
                <?php
                $args = array('textarea_rows'=> 10);
                $content = (isset($fdata['pcma_qm_txt'])) ? stripslashes($fdata['pcma_qm_txt']) : '';
                echo wp_editor( $content, 'pcma_qm_txt', $args); 
                ?>
            </div>
            
            <table class="widefat pc_table">
              <tr>
                <td class="pc_label_td"><?php _e('Send to', 'pcma_ml'); ?></td>
                <td>
                    <select name="pcma_qm_to[]" multiple="multiple" class="lcweb-chosen" data-placeholder="<?php _e('Select categories', 'pcma_ml') ?> ..">
                      <option value="all" <?php if(isset($fdata['pcma_qm_to']) && is_array($fdata['pcma_qm_to']) && $fdata['pcma_qm_to'][0] == 'all') echo 'selected="selected"'; ?>>
                        <?php _e('All users', 'pcma_ml') ?>
                      </option>
                      
                      <?php
                      $user_categories = get_terms('pg_user_categories', 'orderby=name&hide_empty=0');
                      foreach ($user_categories as $ucat) {
                          $selected = (isset($fdata['pcma_qm_to']) && is_array($fdata['pcma_qm_to']) && in_array($ucat->term_id, $fdata['pcma_qm_to'])) ? 'selected="selected"' : '';
                          echo '<option value="'.$ucat->term_id.'" '.$selected.'>'.$ucat->name.'</option>';  
                      }
                      ?>
                    </select>    
                </td>
              </tr>
              <tr>
                <td class="pc_label_td"><?php _e('Add single users', 'pcma_ml'); ?></td>
                <td>
                    <input type="text" name="pcma_su_to_sel" id="pcma_su_to_sel" placeholder="<?php _e("search by user's e-mail, username, name, surname", 'pcma_ml') ?>" autocomplete="off" />
                    
                    <ul id="pcma_su_to_list">
						<?php
                        if(isset($fdata) && !empty($fdata['pcma_su_to'])) {
							$args = array(
								'limit' => -1,
								'user_id' => $fdata['pcma_su_to'],
								'to_get' => array('id', 'name', 'surname', 'username', 'email'),
							);
							
							foreach($pc_users->get_users($args) as $ud) {
								$nicename = (!empty($ud['name']) && !empty($ud['surname'])) ? trim($ud['name'].' '.$ud['surname']).' ('.$ud['username'].' - '.$ud['email'].')' : $ud['username'] .' - '.$ud['email'];
								
								echo ' 
								<li rel="'. $ud['id'] .'">
									<input type="hidden" name="pcma_su_to[]" value="'. $ud['id'] .'" />
									<span class="pc_del_field"></span>
									'. $nicename .'
								</li>';
							}
						}
                        ?>
                    </ul>
                </td>
              </tr>
              <tr>
                <td class="pc_label_td"><?php _e('Attachment', 'pcma_ml'); ?></td>
                <td><input type="file" name="pcma_attach" /></td>
              </tr>
        	</table>
            
            <input type="hidden" name="pc_nonce" value="<?php echo wp_create_nonce('lcwp') ?>" /> 
   			<input type="submit" name="pcma_send_mail" value="<?php _e('Send E-mail', 'pcma_ml') ?>" class="button-primary" />         
        </div>
    </form>
</div>  

<?php // SCRIPTS ?>
<?php wp_enqueue_script('jquery-ui-autocomplete'); ?>
<script src="<?php echo PC_URL; ?>/js/chosen/chosen.jquery.min.js" type="text/javascript"></script>

<script type="text/javascript" charset="utf8" >
jQuery(document).ready(function($) {
	
	// single user - autocomplete + ajax search
	jQuery("#pcma_su_to_sel").autocomplete({
		source: function( request, response ) {
			var data = {
				action: 'pcma_qm_users_search',
				pcma_search: request.term,
				pcma_nonce: '<?php echo wp_create_nonce('lcwp_ajax') ?>'
			};
			jQuery.post(ajaxurl, data, function(resp) {
				response( jQuery.parseJSON(resp) );
			});	
		},
		minLength: 3,
		select: function(event, ui) {
			
			// check already selected users
			if(jQuery('#pcma_su_to_list li[rel='+ ui.item.id +']').size()) {
				alert("<?php _e('User already selected', 'pcma_ml'); ?>");	
			}
			else {
				// add block
				jQuery('#pcma_su_to_list').append(
				'<li rel="'+ ui.item.id +'"><input type="hidden" name="pcma_su_to[]" value="'+ ui.item.id +'" /><span class="pc_del_field"></span>'+ ui.item.label +'</li>');
			}
			
			jQuery(this).val(''); 
			return false;
		},
		open: function() {
			jQuery( this ).removeClass( "ui-corner-all" ).addClass( "ui-corner-top" );
		},
		close: function() {
			jQuery( this ).removeClass( "ui-corner-top" ).addClass( "ui-corner-all" );
		}
    });
	
	
	// remove single user
	jQuery(document.body).delegate('#pcma_su_to_list .pc_del_field', 'click', function() {
		if(confirm("<?php _e('Remove user?', 'pcma_ml') ?>")) {
			jQuery(this).parents('li').fadeOut(function() {
				jQuery(this).remove();	
			});
		}
	});
	
	//////////////////////////////////////////////////////////
	
	// chosen
	jQuery('.lcweb-chosen').each(function() {
		var w = jQuery(this).css('width');
		jQuery(this).chosen({width: w}); 
	});
	jQuery(".lcweb-chosen-deselect").chosen({allow_single_deselect:true});
});
</script>


