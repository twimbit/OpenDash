<?php
/* 
Plugin Name: PrivateContent - Mail Actions Add-on 
Plugin URI: http://www.lcweb.it/privatecontent/mail-actions-add-on
Description: Integrates e-mail in privateContent. Check user authenticity, allow users to retrieve their passwords and sync your users with MailChimp. Finally contact users in no time with quick mails 
Author: Luca Montanari
Version: 1.74
Author URI: https://lcweb.it
*/  


/////////////////////////////////////////////
/////// MAIN DEFINES ////////////////////////
/////////////////////////////////////////////

// plugin path
$wp_plugin_dir = substr(plugin_dir_path(__FILE__), 0, -1);
define( 'PCMA_DIR', $wp_plugin_dir );

// plugin url
$wp_plugin_url = substr(plugin_dir_url(__FILE__), 0, -1);
define( 'PCMA_URL', $wp_plugin_url );

// add-on version
define('PCMA_VER', 1.74);


///////////////////////////////////////////////
/////// CHECK IF PRIVATECONTENT IS ACTIVE /////
///////////////////////////////////////////////

include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
if(!is_plugin_active('private-content/private_content.php') && !defined('PC_VERS')) {
	
	function pcma_no_plugin_warning() {
		echo '
		<div class="error">
		   <p>'. __('Please activate PrivateContent plugin to use the "Mail Actions" add-on', 'pcma_ml') .'</p>
		</div>';
	}
	add_action('admin_notices', 'pcma_no_plugin_warning');
}


else {
	/////////////////////////////////////////////
	/////// MULTILANGUAGE SUPPORT ///////////////
	/////////////////////////////////////////////
	
	function pcma_multilanguage() {
		$param_array = explode(DIRECTORY_SEPARATOR, PCMA_DIR);
		$folder_name = end($param_array);
	  	
		if(is_admin()) {
		   load_plugin_textdomain('pcma_ml', false, $folder_name . '/lang_admin');  
		}
		load_plugin_textdomain('pcma_ml', false, $folder_name . '/languages'); 
	}
	add_action('init', 'pcma_multilanguage', 1);
	
	
	
	//////////////////////////////////
	// SCRIPT ENQUEUING
	function pcma_global_scripts() { 
		if (!is_admin()) {
			wp_enqueue_script('pcma_fontend_js', PCMA_URL . '/js/private-content-ma.js', 99, PCMA_VER, true);	
		}	
	}
	add_action('wp_enqueue_scripts', 'pcma_global_scripts');
	
	
	////////////////////////////////////////////////////////
	
	
	// INTEGRATIONS
	include_once(PCMA_DIR . '/integrations.php');
	
	// USER MAIL VERIFICATION SCRIPTS
	include_once(PCMA_DIR . '/user_verification.php');
	
	// MAILCHIMP IMPLEMENTATION THROUGH HOOKS
	include_once(PCMA_DIR . '/mailchimp_hooks.php');
	
	// PUBLIC API
	include_once(PCMA_DIR . '/public_api.php');
	
	// ADMIN AJAX
	include_once(PCMA_DIR . '/admin_ajax.php');
	
	// ADMIN AJAX
	include_once(PCMA_DIR . '/front_ajax.php');

	
	
	
	
	
	
	////////////
	// DOCUMENTATION'S LINK
	if(!isset($GLOBALS['is_pc_bundle'])) {
		
		function pcma_doc_link($links, $file) {
			if($file == plugin_basename(__FILE__)) {	
				$links['lc_doc_link'] = '<a href="https://doc.lcweb.it/pc_mail_actions" target="_blank">'. __('Documentation', 'pcma_ml') .'</a>';
			}
			
			return $links;
		}
		add_filter('plugin_row_meta', 'pcma_doc_link', 50, 2);
	}
	////////////
	
	
	////////////
	// AUTO UPDATE DELIVER
	if(!isset($GLOBALS['is_pc_bundle'])) {
		include_once(PCMA_DIR . '/classes/lc_plugin_auto_updater.php');
		function pcma_auto_updates() {
			if(!get_option('pg_no_auto_upd')) {
				$upd = new lc_wp_autoupdate(__FILE__, 'http://updates.lcweb.it', 'lc_updates');
			}
		}
		add_action('admin_init', 'pcma_auto_updates', 1);
	}
	////////////
}








///////////////////////////////////////////////////////////////////////
// main function to know the add-on existence and check if is active
function pcma_is_active() {
	if(isset($GLOBALS['pcma_is_active'])) {return $GLOBALS['pcma_is_active'];} // cache to avoid redundant checks
	
	if(!get_option('pcma_from_name') || !get_option('pcma_from_mail') || !get_option('pcma_reply_to_name') || !get_option('pcma_reply_to_mail')) {
		$GLOBALS['pcma_is_active'] = false;
		return false;
	}
	else {
		$GLOBALS['pcma_is_active'] = true;
		return true;
	}
}




//////////////////////////////////////////////////
// ACTIONS ON PLUGIN ACTIVATION //////////////////
//////////////////////////////////////////////////

function pcma_on_activation() {
	
	// mailchimp - setup meta for subscription status
	if(!get_option('pcma_v1.5_mc_meta')) {
		global $pc_users, $wpdb;
		
		$result = $pc_users->get_users(
			array(
				'limit' => -1,	
				'to_get' => 'id'
		  	)
		); 
		
		foreach($result as $user) { 
			if(!(int)$user['id']) {continue;}
			
			$wpdb->insert( 
				$wpdb->prefix . "pc_user_meta", 
				array(
					'user_id' 	=> $user['id'],
					'meta_key' 	=> 'pcma_mc_disclaimer',
					'meta_value'=> 1
				)
			);	
		}	
		update_option('pcma_v1.5_mc_meta', 1);
	}
	
	
	// v1.6 - stop using nl2br but update existing settings for retrocompatibility
	if(!get_option('pcma_v1.6_nl2br')) {
		$opts = array('pcma_mv_txt', 'pcma_nnu_txt', 'pcma_nau_txt', 'pcma_wm_txt', 'pcma_niu_txt', 'pcma_psw_mail_txt', 'pcud_sfan_receivers');
		
		foreach($opts as $opt) {
			$val = get_option($opt); 
			if($val) {
				update_option($opt, nl2br($val)); 
			}
		}
	}
}
register_activation_hook(__FILE__, 'pcma_on_activation');



// REQUIRE LATEST PC
function pcma_requirements_check() {
	if(!defined('PC_VERS') || PC_VERS < 7.2) {
		
		deactivate_plugins( plugin_basename( __FILE__ ) );
		wp_die('Mail Actions add-on '. __('requires at least', 'pcma_ml') .' PrivateContent v7.2 installed');	
	}
}
register_activation_hook(__FILE__, 'pcma_requirements_check');





//////////////////////////////////////////////////
// REMOVE WP HELPER FROM PLUGIN PAGES

function pcma_remove_wp_helper() {
	$cs = get_current_screen();
	$hooked = array('privatecontent_page_pcma_settings');
	
	if(is_object($cs) && in_array($cs->base, $hooked)) {
		echo '
		<style type="text/css">
		#screen-meta-links {display: none;}
		</style>';	
	}
	
	//var_dump(get_current_screen()); // debug
}
add_action('admin_head', 'pcma_remove_wp_helper', 999);
