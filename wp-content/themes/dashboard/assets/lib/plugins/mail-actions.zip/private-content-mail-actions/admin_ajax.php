<?php
////////////////////////////////////////////////////////
// SEND A TEST E-MAIL //////////////////////////////////
////////////////////////////////////////////////////////

function pcma_test_mail() {
	require_once(PCMA_DIR . '/functions.php');
	
	if(!isset($_POST['pcma_mail']) || !filter_var($_POST['pcma_mail'], FILTER_VALIDATE_EMAIL)) {die('Insert a valid e-mail');}
	$mail = $_POST['pcma_mail'];
	
	$txt = 'Hello,
this is a demo e-mail sent by PrivateContent.
	
Lorem ipsum dolor sit amet, consectetur adipisici elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquid ex ea commodi consequat. Quis aute iure reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint obcaecat cupiditat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.';
	$result = $mail_sent = pcma_send_mail(get_bloginfo('name'), $mail, 'PrivateContent Mail Actions - demo e-mail', nl2br($txt));
	
	echo ($result) ? __('E-mail sent successfully', 'pcma_ml') : __('An error occurred sending the e-mail', 'pcma_ml');
	die();
}
add_action('wp_ajax_pcma_test_mail', 'pcma_test_mail');



////////////////////////////////////////////////////////
// MANUALLY VALIDATE USER GROUPS ///////////////////////
////////////////////////////////////////////////////////

function pcma_mv_group_manual() {
	global $pc_users;

	if(!isset($_POST['pcma_cat'])) {die('Category is missing');}
	$ucat = addslashes(trim($_POST['pcma_cat']));
	
	$args = array(
		'status' 	=> 1,
		'limit'		=> -1,
		'to_get' 	=> array('page_id', 'email'),
		'search' 	=> array(array('key'=>'email', 'operator'=>'!=', 'val'=>''))
	);
	
	if($ucat != 'all') {
		$args['categories'] = (int)$ucat;
	}
	$users = $pc_users->get_users($args);
	
	// validate
	foreach($users as $data) {
		if(!empty($data['email'])) {
			update_post_meta($data['page_id'], 'pcma_is_verified', 1);
		}
	}
	
	echo 'success';
	die();
}
add_action('wp_ajax_pcma_mv_group_manual', 'pcma_mv_group_manual');



////////////////////////////////////////////////////////
// MANUALLY VALIDATE SINGLE USER ///////////////////////
////////////////////////////////////////////////////////

function pcma_mv_manual() {
	global $pc_users;

	if(!isset($_POST['pcma_uid']) || !filter_var($_POST['pcma_uid'], FILTER_VALIDATE_INT)) {die('ID is missing');}
	$uid = (int)$_POST['pcma_uid'];
	
	// get user page id
	$pag_id = $pc_users->get_user_field($uid, 'page_id');
	
	// validate
	update_post_meta($pag_id, 'pcma_is_verified', 1);
	
	echo 'success';
	die();
}
add_action('wp_ajax_pcma_mv_manual', 'pcma_mv_manual');



////////////////////////////////////////////////////////
// MANUALLY DELETE SINGLE USER VALIDATION //////////////
////////////////////////////////////////////////////////

function pcma_del_mv_manual() {
	global $pc_users;
	
	if(!isset($_POST['pcma_uid']) || !filter_var($_POST['pcma_uid'], FILTER_VALIDATE_INT)) {die('user ID is missing');}
	$uid = (int)$_POST['pcma_uid'];

	// get user page id
	$pag_id = $pc_users->get_user_field($uid, 'page_id');
	
	// validate
	delete_post_meta($pag_id, 'pcma_is_verified');
	
	echo 'success';
	die();
}
add_action('wp_ajax_pcma_del_mv_manual', 'pcma_del_mv_manual');



////////////////////////////////////////////////////////
// SEND MANUALLY SINGLE USER VALIDATION E-MAIL /////////
////////////////////////////////////////////////////////

function pcma_manual_send_vmail() {
	include_once(PCMA_DIR . '/integrations.php');
	global $pc_users;
	
	if(!isset($_POST['pcma_uid']) || !filter_var($_POST['pcma_uid'], FILTER_VALIDATE_INT)) {die('user ID is missing');}
	$uid = (int)$_POST['pcma_uid'];
	
	// send
	$GLOBALS['pcma_force_mail_verif_sending'] = true;
	pcma_send_mail_verif($uid);
	
	echo 'success';
	die();
}
add_action('wp_ajax_pcma_manual_send_vmail', 'pcma_manual_send_vmail');



////////////////////////////////////////////////////////
// SEND MANUALLY GROUP USER VALIDATION E-MAIL /////////
////////////////////////////////////////////////////////

function pcma_group_manual_send_vmail() {
	include_once(PCMA_DIR . '/integrations.php');
	global $pc_users;
	
	if(!isset($_POST['pcma_cat'])) {die('Category is missing');}
	$ucat = addslashes(trim($_POST['pcma_cat']));
	
	$args = array(
		'status' => 1,
		'to_get' => array('id', 'page_id', 'email'),
		'search' => array(array('key'=>'email', 'operator'=>'!=', 'val'=>''))
	);
	
	if($ucat != 'all') {
		$args['categories'] = (int)$ucat;
	}
	$users = $pc_users->get_users($args);
	
	$GLOBALS['pcma_force_mail_verif_sending'] = true;
	
	// validate
	foreach($users as $data) {
		if(!empty($data['email']) && get_post_meta($data['page_id'], 'pcma_is_verified', true) != 1) {
			pcma_send_mail_verif($data['id'], $data['page_id'], $data);
		}
	}
	
	echo 'success';
	die();
}
add_action('wp_ajax_pcma_group_manual_send_vmail', 'pcma_group_manual_send_vmail');



/////////////////////////////////////////////////////
// DYNAMIC USERS SEARCH FOR QUICK MAIL //////////////
/////////////////////////////////////////////////////

function pcma_qm_users_search() {
	if (!isset($_POST['pcma_nonce']) || !wp_verify_nonce($_POST['pcma_nonce'], 'lcwp_ajax')) {die('Cheating?');};
	
	include_once(PCMA_DIR . '/integrations.php');
	global $pc_users;
	
	if(!isset($_POST['pcma_search'])) {
		echo json_encode( array() );
		die();
	}
	$search = trim( $_POST['pcma_search']);
	
	$args = array(
		'limit' => -1,
		'to_get' => array('id', 'username', 'name', 'surname', 'email'),
		'search_operator' 	=> 'OR',
		'search' => array(
			array('key'=>'username', 'operator'=>'LIKE', 'val'=>'%'.$search.'%'),
			array('key'=>'name', 'operator'=>'LIKE', 'val'=>'%'.$search.'%'),
			array('key'=>'surname', 'operator'=>'LIKE', 'val'=>'%'.$search.'%'),
			array('key'=>'email', 'operator'=>'LIKE', 'val'=>'%'.$search.'%')
		),
		'custom_search' => 'AND status = 1 AND email != ""'
	);
	
	$users = $pc_users->get_users($args);
	$to_return = array();
	
	foreach($users as $ud) {
		$nicename = (!empty($ud['name']) && !empty($ud['surname'])) ? trim($ud['name'].' '.$ud['surname']).' ('.$ud['username'].' - '.$ud['email'].')' : $ud['username'] .' - '.$ud['email'];
		$to_return[] = array('id'=>$ud['id'], 'value'=>'', 'label'=>$nicename);	
	}
	
	echo json_encode($to_return);
	die();
}
add_action('wp_ajax_pcma_qm_users_search', 'pcma_qm_users_search');



//////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////
// MANUAL GLOBAL MAILCHIMP SYNC ////////////////////////
////////////////////////////////////////////////////////

function pcma_mc_ajax_sync() {
	include_once(PCMA_DIR .'/classes/mailchimp_integration.php');
	$mc = new pcma_mailchimp();
	
	if(!$mc->is_ready()) {
		die( __('Error connecting to Mailchimp - check API key and list', 'pcma_ml') );	
	}
	
	// sync also fields
	if(!$mc->sync_fields()) {
		echo json_encode(array(
			'status' 	=> 0,
			'mess'		=> __('Error syncing custom fields', 'pcma_ml')
		));	
	}
	
	
	// perform
	if($mc->subscribe_members('any', true)) {
		echo json_encode(array(
			'status' 	=> 1,
			'mess'		=> $mc->synced_num.' '. __('users synced!', 'pcma_ml')
		));	
	}
	else {
		echo json_encode(array(
			'status' 	=> 0,
			'mess'		=> __('Error syncing users', 'pcma_ml')
		));	
	}
	
	die();
}
add_action('wp_ajax_pcma_mc_ajax_sync', 'pcma_mc_ajax_sync');




////////////////////////////////////////////////////////
// MAILCHIMP DISCLAIMER MANAG IN "ADD USER"  PAGE //////
////////////////////////////////////////////////////////

function pcma_mc_add_user_discl_cmd() {
	include_once(PCMA_DIR .'/classes/mailchimp_integration.php');
	$mc = new pcma_mailchimp();
	global $pc_meta;
	
	if(!$mc->is_ready()) {
		die( __('Error connecting to Mailchimp - check API key and list', 'pcma_ml') );	
	}
	
	$uid = (int)$_POST['uid'];
	if(empty($uid)) {
		die( __('User ID missing', 'pcma_ml') );		
	}
	
	
	if($_POST['cmd'] == 'unsub') {
		$mc->remove_members(array((int)$_POST['uid']));
		$pc_meta->update_meta($uid, 'pcma_mc_disclaimer', '');
	}
	
	else {
		$pc_meta->update_meta($uid, 'pcma_mc_disclaimer', 1);	
		$mc->subscribe_members(array((int)$_POST['uid']));
	}

	die('success');
}
add_action('wp_ajax_pcma_mc_add_user_discl_cmd', 'pcma_mc_add_user_discl_cmd');
