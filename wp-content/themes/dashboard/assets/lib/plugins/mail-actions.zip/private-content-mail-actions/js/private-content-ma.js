/*****************************
   MANAGE PASSWORD RECOVERY
******************************/	

jQuery(document).ready(function(){
	var pcma_psw_is_acting = false; // security var to avoid multiple calls
	
	// show recovery form
	jQuery(document).delegate('.pcma_psw_recovery_trigger', 'click', function() {
		var $pcma_form = jQuery(this).parents('form');
		
		$pcma_form.children().hide();
		$pcma_form.find('.pcma_psw_recovery_wrap').fadeIn();
	});
	
	
	// hide recovery form
	jQuery(document).delegate('.pcma_del_recovery', 'click', function() {
		var $pcma_form = jQuery(this).parents('form');
		
		$pcma_form.children().fadeIn();
		$pcma_form.find('.pcma_psw_recovery_wrap').hide();
	});
	
	
	// handle recovery request
	jQuery(document).delegate('.pcma_do_recovery', 'click', function(e) {
		e.preventDefault();
		
		$target_div = jQuery(this).parents('form');
		var pcma_username = $target_div.find('.pcma_psw_username').val();

		if(!pcma_psw_is_acting && jQuery.trim(pcma_username) != '') {
			pcma_psw_is_acting = true;
			
			$target_div.find('.pcma_do_recovery').addClass('pc_loading_btn');
			$target_div.find('.pcma_del_recovery').fadeOut('fast');
			
			var cur_url = jQuery(location).attr('href');
			jQuery.ajax({
				type: "POST",
				url: cur_url,
				dataType: "json",
				data: "pcma_psw_recovery=1&pcma_username=" + pcma_username,
				success: function(pcma_data){
					pcma_psw_is_acting = false;

					if(pcma_data.resp == 'success') {
						$target_div.find('.pcma_psw_recovery_message').empty().append('<span class="pc_success_mess">' + pcma_data.mess + '</span>');
						jQuery('.pcma_do_recovery').fadeOut(function() {
							jQuery(this).remove();
						});
					}
					else {
						$target_div.find('.pcma_psw_recovery_message').empty().append('<span class="pc_error_mess">' + pcma_data.mess + '</span>');	
					}
					
					// a bit of delay to display the loader
					setTimeout(function() {
						$target_div.find('.pcma_do_recovery').removeClass('pc_loading_btn');
					}, 370);

					$target_div.find('.pcma_del_recovery').fadeIn('fast');
				}
			});
		}
	});	
	
});
	