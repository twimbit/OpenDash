<?php
///////////////////////////////////////////////////
//// MAILCHIMP IMPLEMENTATION THROUGH HOOKS ///////
///////////////////////////////////////////////////

function pcma_mc_hooks_wrap() {
	include_once(PCMA_DIR .'/classes/mailchimp_integration.php');
	
	// check if is ready to operate
	$GLOBALS['pcma_mc_instance'] = $mc = new pcma_mailchimp();
	if(!$mc->is_ready()) {return false;}
	
	
	
	
	#############################################
	## HANDLE MAILCHIMP WEBHOOK TO UNSUBSCRIBE ##
	#############################################
	
	if(isset($_GET['pcma_mc_unsubscribe']) && isset($_REQUEST['type'])) {
		#error_log("Error message1 - ".json_encode($_REQUEST), 3, PCMA_DIR."/log.txt"); // DEBUG
		
		if($_REQUEST['type'] != 'unsubscribe') {return false;}
		if(!isset($_REQUEST['data'])) {return false;}
		
		global $pc_users, $pc_meta;
		$data = (array)$_REQUEST['data'];
		
		$user = $pc_users->get_users(array(
			'limit' => 1,
			'to_get' => array('id'),
			'search' => array(
				array('key'=>'email', 'operator'=>'=', 'val'=>$data['email'])
			)
		));
		
		if(count($user)) {
			$pc_meta->update_meta($user[0]['id'], 'pcma_mc_disclaimer', '');	
		}
	}
	////////////////////////
	
	
	

	#############################################
	##### SUBSCRIPTION STATUS MANAG #############
	#############################################
	
	
	// add disclaimer field
	function pcma_mc_disclaimer($fields) {
		
		$fields['pcma_mc_disclaimer'] = array(
			'label' 	=> __("Mailchimp disclaimer", 'pcma_ml'),
			'type' 		=> 'single_checkbox',
			'subtype' 	=> '',
			'maxlen' 	=> 1,
			'opt'		=> '1',
			'check_txt'	=> strip_tags((string)get_option('pcma_mc_discl_txt', __('I want to receive periodical newsletters', 'pcma_ml')), '<br><a><strong><em>'),
			'disclaimer'=> true,
			'note' 		=> __("Mailchimp disclaimer", 'pcma_ml'),
		);
		
		return $fields;
	}
	add_filter('pc_form_fields_filter', 'pcma_mc_disclaimer');
	
	
	
	
	
	
	
	// admin user dashboard - add switch to set it as subscribed
	function pcma_mc_user_dashboard_discl($sections, $user_id) {
		if(!pcma_is_active() || !$user_id) {
			return $sections;	
		}

		// check mandatory data
		global $pc_users;
		$user_data = $pc_users->get_user($user_id, array(
			'to_get' => array('email', 'status')
		));
		
		if(!$user_data['email'] || (int)$user_data['status'] != 1) {
			return $sections;	
		}
			
		return 
		$sections + array(
			'pcma_mc' => array(
				'name'		=> 'Mail Actions add-on - Mailchimp '. __('Sync', 'pcma_ml'),
				'classes'	=> 'pc_ud_onehalf_w lor',
				'callback' 	=> 'pcma_mc_user_dashboard_discl_cb'
			)
		);	
	}
	add_filter('pc_user_dashboard_main_tab_sections', 'pcma_mc_user_dashboard_discl', 21, 2);
	
	
	
	function pcma_mc_user_dashboard_discl_cb($user_id) {
		
		// get agreement via meta manag - $user_data is ok for form fields
		global $pc_meta;
		$user_agrees = $pc_meta->get_meta($user_id, 'pcma_mc_disclaimer');
		
		if($user_agrees) {
			echo '
			<div class="pc_warn pc_wps_warn pc_success">
				'.__("User agreed to be synced in Mailchimp", 'pcma_ml');
				
				if($GLOBALS['pc_cuc_edit']) {
					echo '
					<button class="button-secondary" id="pcma_mc_unsub">'. __("Revoke Agreement", 'pcma_ml') .'</button>';
				}
			
			echo '	
			</div>';
		}
		else {
			echo '
			<div class="pc_warn pc_wps_warn pc_warning">
				'.__("User didn't agree to be synced in Mailchimp", 'pcma_ml'); 
				
				if($GLOBALS['pc_cuc_edit']) {
					echo '
					<button class="button-secondary" id="pcma_mc_sub">'. __("Force Agreement", 'pcma_ml') .'</button>';	
				}
				
			echo '	
			</div>';	
		}
		
		
		// javascript to subscribe and un-subscribe - only if CUC
		if($GLOBALS['pc_cuc_edit']) :
		?>
		<script type="text/javascript">
		jQuery(document).ready(function($) {
			var pcma_mc_is_acting = false;
			
			// ajax call's function
			var pcma_mc_discl = function(action) {
				
				var $btn = $('#pcma_mc_unsub, #pcma_mc_sub');
				$btn.fadeTo(200, 0.7);
				pcma_mc_is_acting = true;
						
				var data = {
					action: 'pcma_mc_add_user_discl_cmd',
					uid: <?php echo $user_id ?>,
					cmd: action
				};
				$.post(ajaxurl, data, function(response) {
					if($.trim(response) == 'success') {
						pc_toast_message('success', "<?php echo __("Operation successfully performed!", 'pcma_ml') ?>");
						
						setTimeout(function() {
							location.reload(); 
						}, 1800);
					}
					else {
						pc_toast_message('error', response);
						
						$btn.fadeTo(200, 1);
						pcma_mc_is_acting = false;
					}
					
					
				});
			}
			
			
			// unsubscribe
			$(document).delegate('#pcma_mc_unsub', 'click', function(e) {
				if(pcma_mc_is_acting) {return false;}
				e.preventDefault();
				
				if(confirm("<?php _e("User won't be synced anymore. Cotinue?") ?>")) {	
					pcma_mc_discl('unsub');
				}
			});
				
			// subscribe
			$(document).delegate('#pcma_mc_sub', 'click', function(e) {
				if(pcma_mc_is_acting) {return false;}
				e.preventDefault();
			
				if(confirm("<?php _e("You might override user's will. Cotinue?") ?>")) {	
					pcma_mc_discl('sub');
				}
			});
		});
		</script>
		<?php
		endif;
	}
	
	
	
	
	
	// subscription management if registration field is not used 
	function pcma_mc_def_discl_val($user_id) {
		global $pc_meta;
		if($pc_meta->has_meta($user_id, 'pcma_mc_disclaimer') !== false) {return false;}
		
		$val = (get_option('pcma_mc_def_discl')) ? 1 : '';
		$pc_meta->add_meta($user_id, 'pcma_mc_disclaimer', $val);
	}
	add_action('pc_user_added', 'pcma_mc_def_discl_val', 15);
	
	
	
	
	
	#############################################
	## MAILCHIMP SUBSCRIPTION BADGE #############
	#############################################	
	
	
	function pcma_mc_badge($badges, $user_id) {
		global $pc_meta;
		
		if($pc_meta->get_meta($user_id, 'pcma_mc_disclaimer')) {
			$badges .= '<img src="'.PCMA_URL.'/img/mc_badge.png" title="'. esc_attr( __('allow mailchimp subscription', 'pcma_ml')) .'" />';
		}
		
		return $badges;
	}
	add_filter('pc_users_list_badges', 'pcma_mc_badge', 40, 2);

	
	
	
	
	
	#############################################
	##### AUTO - SYNC ###########################
	#############################################
	
	if(!get_option('pcma_mc_auto_sync')) {return false;}
	
	
	// single user addition / update
	function pcma_mc_user_put($subj) {
		if(isset($GLOBALS['pcma_mc_already_changed'])) {
			return false;	
		}
		
		global $pcma_mc_instance, $pc_meta;
		
		// multiple users - just update
		if(is_array($subj)) {
			$pcma_mc_instance->subscribe_members($subj);			
		}
		
		// single user - check whether to subscribe or not
		else {
			($pc_meta->get_meta($subj, 'pcma_mc_disclaimer')) ? $pcma_mc_instance->subscribe_members((array)$subj) : $pcma_mc_instance->remove_members((array)$subj);	
		}
	}
	add_action('pc_user_added', 'pcma_mc_user_put', 200); // after subscription management hook
	add_action('pc_user_updated', 'pcma_mc_user_put', 200);
	add_action('pc_bulk_cat_assign_done', 'pcma_mc_user_put');



	// bulk user addition
	function pcma_mc_bulk_add() {
		global $pcma_mc_instance;
		$pcma_mc_instance->subscribe_members();		
	}
	add_action('pc_imported_users', 'pcma_mc_bulk_add');	
	
	
	
	// single/bulk user removal
	function pcma_mc_bulk_del($subj) {
		global $pcma_mc_instance;
		$pcma_mc_instance->remove_members($subj);		
	}
	add_action('pc_pre_user_delete', 'pcma_mc_bulk_del');	
	
	
	
	// status change detection - remove or add
	function pcma_mc_status_change($subj, $new_status) {
		global $pcma_mc_instance;
		$GLOBALS['pcma_mc_already_changed'] = true; // flag to avoid doubled operations
		
		if($new_status == 2 || $new_status == 3) {
			$pcma_mc_instance->remove_members($subj);
		}
		elseif ($new_status == 1) {
			$pcma_mc_instance->subscribe_members((array)$subj);		
		}
	}
	add_action('pc_user_staus_changed', 'pcma_mc_status_change', 10, 2);
	
		
	
	
	
	////////////////////////////////////////////////////////////////////////////////	
		
		
		
		
	// categories sync on addition/update/deletion	
	function pcma_mc_on_cats_change() {
		global $pcma_mc_instance;
		$pcma_mc_instance->sync_cats();
	}
	add_action('created_pg_user_categories', 'pcma_mc_on_cats_change');
	add_action('edited_pg_user_categories', 'pcma_mc_on_cats_change');
	add_action('delete_pg_user_categories', 'pcma_mc_on_cats_change');	
}

add_action('init', 'pcma_mc_hooks_wrap', 2); // wrapper to safely use options - use priority 2 to let PC constants to setup
