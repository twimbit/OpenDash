<?php
// MANAGE USER VERIFICATION PAGE

// check data and prepare messages
add_action('template_redirect', 'pcma_mv_page_check');
function pcma_mv_page_check() {
	global $wpdb, $post, $current_user, $pc_users;
	
	include_once(PC_DIR .'/functions.php');
	$target_pag = pc_wpml_translated_pag_id(get_option('pcma_mv_pag'));

	if(is_page() && $post->ID == $target_pag) {
		include_once(PCMA_DIR . '/functions.php');
	
		if(pcma_is_active() && get_option('pcma_mv_enable')) {
			$table_name = $wpdb->prefix . "pc_users";
			$is_admin = current_user_can('install_plugins');
			
			// get parameters
			$user_id 	= (isset($_REQUEST['pcma_user'])) ? (int)$_REQUEST['pcma_user'] : 0; 
			$key 		= (isset($_REQUEST['pcma_key'])) ? $_REQUEST['pcma_key'] : 0; 
			$admin_mode = (isset($_REQUEST['pcma-test'])) ? $_REQUEST['pcma-test'] : false;
			
			// check user id existence	
			$pag_id = $pc_users->get_user_field($user_id, 'page_id');
			
			// if parameters are missing and is not an admin test redirect to homepage
			if( 
				(empty($pag_id) || !isset($_REQUEST['pcma_key'])) && 
				(!$is_admin || !isset($_REQUEST['pcma-test']))
			) {
				header("Location: ".get_home_url());	
			}
			
			// check validation key (1=>ok, 2=>already validated, 0=>wrong)
			if(!empty($pag_id)) {
				$user_key = get_post_meta($pag_id, 'pcma_verif_id', true);
				
				if($user_key['id'] == $key) {
					$valid_key = (!$user_key['validated']) ? 1 : 2;
				}
				else {$valid_key = 0;}
			}
			

			// error message
			if(empty($pag_id) || $valid_key == 0 || ($is_admin && $admin_mode == 'error')) {
				$mess = get_option('pcma_mv_bad_mess');
				if(trim(strip_tags($mess)) == '') {$mess = __('Sorry, your request is invalid or your account has been deleted', 'pc_ml');}
			}
			
			// already verified message
			if($valid_key == 2 || ($is_admin && $admin_mode == 'validated')) {
				$mess = get_option('pcma_mv_act_mess');	
				if(trim(strip_tags($mess)) == '') {$mess =  __('Your account has been already activated!', 'pc_ml');}
			}
			
			// validated succesfully
			if($valid_key == 1 || ($is_admin && $admin_mode == 'success')) {
				$mess = get_option('pcma_mv_ok_mess');
				if(trim(strip_tags($mess)) == '') {$mess = __('Your account has been activated succesfully!', 'pc_ml');}

				if($user_id != 0 && $key != 0) {
					
					// enable user
					$pc_users->change_status($user_id, 1);
					
					// validate user e-mail
					update_post_meta($pag_id, 'pcma_is_verified', 1);
					
					// update user validation id
					$user_key = array('id'=>$key, 'validated'=>1);
					update_post_meta($pag_id, 'pcma_verif_id', $user_key, true);
				}
			}

			// store message and throw content changer
			$GLOBALS['pcma_mv_mess'] = $mess;
			add_filter('the_content', 'pcma_mv_page_content', 999);
			
			// hide page comments
			add_filter('comments_template', 'pc_comments_template', 999);
		}
	}
}


// manage content
function pcma_mv_page_content($content) {
	$new_content = do_shortcode( $GLOBALS['pcma_mv_mess'] );
	return wpautop($new_content);
}

