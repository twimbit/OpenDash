<?php
// DEFAULT MAIL TEXTS FOR THE FIRST USAGE

$mail_texts = array(
	
	// USERS VERIFICATION
	'pcma_mv_subj' => __('%SITE-TITLE% - Welcome!', 'pcma_ml'),
	'pcma_mv_txt' => 
	__('Hello %USERNAME%,
thanks for registering on %SITE-TITLE%. 

To activate your account, click the following link:
%VER-URL%

Best Regards,
%SITE-TITLE% Staff', 'pcma_ml'),

	
	// ADMIN NOTIFIER - new registered
	'pcma_nnu_subj' => __('%SITE-TITLE% - New registered user', 'pcma_ml'),
	'pcma_nnu_txt' => 
	__('Hello,
A new user has registered.

Fullname: %NAME% %SURNAME%
Username: %USERNAME%
E-mail: %MAIL%
Telephone: %TEL%', 'pcma_ml'),


	// ADMIN NOTIFIER - self-deleted user
	'pcma_dun_subj' => __('%SITE-TITLE% - Deleted user', 'pcma_ml'),
	'pcma_dun_txt' => 
	__('Hello,
%USERNAME% just deleted itself from %SITE-TITLE%', 'pcma_ml'),



	// ACTIVATED USERS NOTIFIER
	'pcma_nau_subj' => __('%SITE-TITLE% - Account activated!', 'pcma_ml'),
	'pcma_nau_txt' => 
	__('Hello %USERNAME%,
your account has been activated, now you can login into our website!

Best Regards,
%SITE-TITLE% Staff', 'pcma_ml'),



	// WELCOME MESSAGE
	'pcma_wm_subj' => __('%SITE-TITLE% - Welcome!', 'pcma_ml'),
	'pcma_wm_txt' => 
	__("Hello %USERNAME%,
Congratulations! You have successfully signed up on %SITE-TITLE% and are ready to start browsing our private areas.

Best Regards,
%SITE-TITLE% Staff", 'pcma_ml'),



	// IMPORTED USERS NOTIFIER
	'pcma_niu_subj' => __('%SITE-TITLE% - Account created!', 'pcma_ml'),
	'pcma_niu_txt' => 
	__('Hello %USERNAME%,
now you can login at %SITE-URL%

Best Regards,
%SITE-TITLE% Staff', 'pcma_ml'),



	// PSW RECOVERY
	'pcma_psw_mail_subj' => __('%SITE-TITLE% - Password recovery', 'pcma_ml'),
	'pcma_psw_mail_txt' => 
	__('Hello %USERNAME%,
a password recovery has been requested for your account.

This is your password: %PSW%

Best Regards,
%SITE-TITLE% Staff', 'pcma_ml'),

);

