<?php
// public utilities

/** 
 * SEND AN E-MAIL
 * @param to_name 			= Name of the receiver
 * @param to_mail			= E-mail of the receiver
 * @param subj 				= Subject of the e-mail
 * @param txt 				= Content of the e-mail
 * @param from_name 		= Name of the sender (false to use the one specified in the settings)
 * @param from_mail 		= E-mail of the sender (false to use the one specified in the settings)
 * @param reply_to_name 	= Name for the "to reply" function (false to use the one specified in the settings)
 * @param reply_to_mail 	= E-mail for the "to reply" function (false to use the one specified in the settings)
 * @param attach 			= E-mail attachment (must be the absolute path of the file)
 *
 * @return (bool)
 */
function pcma_send_mail($to_name, $to_mail, $subj, $txt, $from_name = false, $from_mail = false, $reply_to_name = false, $reply_to_mail = false, $attach = false) {
	include_once(PCMA_DIR . '/functions.php');
	
	
	// get basic data to send mail
	if(!$from_name) {$from_name = get_option('pcma_from_name');}
	if(!$from_mail) {$from_mail = get_option('pcma_from_mail');}
	if(!$reply_to_name) {$reply_to_name = get_option('pcma_reply_to_name');}
	if(!$reply_to_mail) {$reply_to_mail = get_option('pcma_reply_to_mail');}
	
	// check basic data
	if(!$from_name || !$from_mail || !$reply_to_name || !$reply_to_mail) {
		return 'One or more basic data are missing';	
	}
	
	
	$txt = (strpos(strtolower($txt), '<html') !== false) ? $txt : '<html><body>'. wpautop($txt) .'</body></html>';	
	$txt = do_shortcode($txt);
	
	$GLOBALS['pcma_send_mail'] = array(
		'to_name'	=> $to_name,
		'to_mail'	=> $to_mail,
		'txt'		=> $txt,
		'from_name'	=> $from_name,
		'from_mail'	=> $from_mail,
		'reply_to_name'	=> $reply_to_name,
		'reply_to_mail'	=> $reply_to_mail,
		'attach'		=> $attach	
	);
	
	
	
	add_filter('wp_mail_content_type', 'pcma_html_mail_content_type', 9999);
	add_action('phpmailer_init', 'pcma_setup_phpmailer', 9999);
	
	$headers = array('Content-Type: text/html; charset=UTF-8');
	$mail_tester = wp_mail($to_mail, $subj, $txt, $headers);
	
	remove_filter('wp_mail_content_type', 'pcma_html_mail_content_type');
	remove_action('phpmailer_init', 'pcma_setup_phpmailer');
	
	return $mail_tester;
}



// force mail to be in HTML
function pcma_html_mail_content_type() {
    return 'text/html';
}


// Mail Actions custom WP PHPMailer setup
function pcma_setup_phpmailer($phpmailer){
	include_once(PCMA_DIR . '/functions.php');
	$mdata = $GLOBALS['pcma_send_mail'];
	
	// from
	$phpmailer->SetFrom($mdata['from_mail'], $mdata['from_name']);
	
	// to
	if(!is_array($mdata['to_mail']) && strpos($mdata['to_mail'], ',') !== false) {
		$mdata['to_mail'] = explode(',', $mdata['to_mail']);	
	}
	
	if(is_array($mdata['to_mail'])) {
		foreach($mdata['to_mail'] as $single_mail) {
			$phpmailer->AddAddress( trim($single_mail) );
		}
	} else {
		$phpmailer->AddAddress($mdata['to_mail'], $mdata['to_name']);
	}
	
	// reply to
	$phpmailer->AddReplyTo($mdata['reply_to_mail'], $mdata['reply_to_name']);
	
	// mail charset
	$phpmailer->CharSet = "utf-8";
	
	// attachment
	if($mdata['attach']) {
		$phpmailer->AddAttachment($mdata['attach']['tmp_name'], $mdata['attach']['name']);
	}
			
	
	// SMTP
	$use_smtp = pcma_use_smtp();
	if($use_smtp) {
		$phpmailer->Host = $use_smtp['host'];
		$phpmailer->Port = get_option('pcma_smtp_port'); 
		$phpmailer->Username = $use_smtp['user'];
		$phpmailer->Password = $use_smtp['psw'];
		
		if((int)get_option('pcma_smtp_port') != 0) {$phpmailer->Port = get_option('pcma_smtp_port');}
		if(get_option('pcma_use_smtp_auth')) {$phpmailer->SMTPAuth = true;}
	}
}

