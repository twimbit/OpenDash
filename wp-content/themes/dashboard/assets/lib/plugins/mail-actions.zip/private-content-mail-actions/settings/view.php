<?php 
include_once(PC_DIR . '/classes/simple_form_validator.php');
include_once(PC_DIR . '/settings/settings_engine.php');
 
include_once(PCMA_DIR . '/settings/custom_fields.php');
include_once(PCMA_DIR . '/settings/structure.php'); 
?>

<div class="wrap lcwp_settings_wrap">  
	<div class="icon32" id="icon-pc_user_manage"><br></div>
    <h2 class="pc_page_title"><?php _e( 'PrivateContent - Mail Actions', 'pcma_ml') ?></h2>  
    
	<?php
    $engine = new pc_settings_engine('pcma_settings', $GLOBALS['pcma_settings_tabs'], $GLOBALS['pcma_settings_structure']);
    
    // get fetched data and allow customizations
    if($engine->form_submitted()) {
       
		// encrypt password
		if(isset($_POST['pcma_smtp_psw'])) {	
			$_POST['pcma_smtp_psw'] = base64_encode($_POST['pcma_smtp_psw']);
		}
	   
	   
	    $fdata = $engine->form_data;
        $errors = (!empty($engine->errors)) ? $engine->errors : array();
        

		//////////
		

		// custom validation for users validation
		if($fdata['pcma_mv_enable']) {
			if(strpos($fdata['pcma_mv_txt'], '%VER-URL%') === false) { 
				 $errors[ __('E-mail verification', 'pcma_ml') ] = __('"%VER-URL%" variable is not present in the e-mail text', 'pcma_ml'); 
			}
			if(empty($fdata['pcma_mv_subj']) || empty($fdata['pcma_mv_txt'])) {
				$errors[ __('E-mail verification', 'pcma_ml') ] = __("E-mail builder's fields must be filled to enable it", 'pcma_ml'); 	
			}
		}
		
		// custom validation for SMTP
		if($fdata['pcma_use_smtp']) {
			if(empty($fdata['pcma_smtp_host']) || empty($fdata['pcma_smtp_user']) || empty($fdata['pcma_smtp_psw'])) {
				$errors['SMTP'] = __('All fields must be filled to enable it', 'pcma_ml'); 	
			}
		}
		
		// custom validation for new user notification
		if($fdata['pcma_nnu_enable']) {
			if(trim($fdata['pcma_nnu_mail_multi'][0]) == '' || trim($fdata['pcma_nnu_subj']) == '' || trim($fdata['pcma_nnu_txt']) == '') {
				$errors[ __('Admin notifier', 'pcma_ml') ] = __('All fields must be filled to enable it', 'pcma_ml'); 	
			}
		}
		if($fdata['pcma_dun_enable']) {
			if(trim($fdata['pcma_nnu_mail_multi'][0]) == '' || trim($fdata['pcma_dun_subj']) == '' || trim($fdata['pcma_dun_txt']) == '') {
				$errors[ __('Admin notifier', 'pcma_ml') ] = __('All fields must be filled to enable it', 'pcma_ml'); 	
			}
		}
		
		// custom validation for activated users by adins
		if($fdata['pcma_nau_enable']) {
			if(empty($fdata['pcma_nau_subj']) || empty($fdata['pcma_nau_txt'])) {
				$errors[ __('User notifier', 'pcma_ml') ] = __('All fields must be filled to enable it', 'pcma_ml'); 	
			}
		}
		
		// custom validation for imported users
		if($fdata['pcma_wm_enable']) {
			if(empty($fdata['pcma_wm_subj']) || empty($fdata['pcma_wm_txt'])) {
				$errors[ __('Welcome message', 'pcma_ml') ] = __('All fields must be filled to enable it', 'pcma_ml'); 	
			}
		}
		
		// custom validation for imported users
		if($fdata['pcma_niu_enable']) {
			if(empty($fdata['pcma_niu_subj']) || empty($fdata['pcma_niu_txt'])) {
				$errors[ __('Imported users notifier', 'pcma_ml') ] = __('All fields must be filled to enable it', 'pcma_ml'); 	
			}
		}
		
		// custom validation for psw recovery
		if($fdata['pcma_psw_recovery']) { 
			if(strpos($fdata['pcma_psw_mail_txt'], '%PSW%') === false) { 
				$errors[ __('Password recovery', 'pcma_ml')] = __('The "%PSW%" variable is not present in the e-mail text', 'pcma_ml'); 
			}
			if(empty($fdata['pcma_psw_mail_subj']) || empty($fdata['pcma_psw_mail_txt'])) {
				$errors[ __('Password recovery', 'pcma_ml') ] = __('All fields must be filled to enable it', 'pcma_ml'); 
			}
		}
		
		
		// password recovery also with e-mail - check database on first activation
		if($fdata['pcma_pr_with_email'] && !get_option('pcma_pr_with_email')) { 
			global $pc_users;
			
			$checked = array();
			$users = $pc_users->get_users(array('to_get' => array('email'), 'limit' => -1));
			
			foreach($users as $user) {
				if(empty($user['email'])) {
					$errors[ __('Password Recovery with e-mail', 'pcma_ml') ] = __("One or more users don't have an e-mail", 'pcma_ml'); 
					break;	
				}
				
				if(in_array($user['email'], $checked)) {
					$errors[ __('Password Recovery with e-mail', 'pcma_ml') ] = __("One or more users have the same e-mail", 'pcma_ml'); 	
					break;
				}
				
				$checked[] = $user['email'];	
			}
		}
		

		//////////


        // PCMA-FILTER - manipulate setting errors - passes errors array and form values - error subject as index + error text as val
        $errors = apply_filters('pcma_setting_errors', $errors, $fdata);	
        
        
        // save or print error
        if(empty($errors)) {
			
			
			//////////
			
			// if e-mail verification is enabled, force registration user status to be pending
			if($fdata['pcma_mv_enable']) {
				update_option('pg_registered_pending', 1);	
			}
			
			// mailchimp sync - no list selected - erase categories sync
			if(!$fdata['pcma_mc_list']) {
				delete_option('pcma_interests');	
			}
			
			// admin notifier - split e-mails
			if(!empty($fdata['pcma_nnu_mail_multi_field'])) {
				$fdata['pcma_nnu_mail_multi_field'] = explode(',', $fdata['pcma_nnu_mail_multi_field']);	
			}
			
			// password recovery also with e-mail - force pvtContent settings
			if($fdata['pcma_pr_with_email']) {
				delete_option('pg_allow_duplicated_mails');
			}
			
			//////////
			
			
			// PCMA-FILTER - allow data manipulation (or custom actions) before settings save - passes form values
            $engine->form_data = apply_filters('pcma_before_save_settings', $fdata); 
			
            // save
            $engine->save_data();
		
		
			// refresh to allow saved values to be spread in structure
			wp_redirect( str_replace( '%7E', '~', $_SERVER['REQUEST_URI']) . '&lcwp_sf_success');
  			exit;
        }
        
        // compose and return errors
        else {
            $err_elems = array();
            foreach($errors as $i => $v) {
                if(is_numeric($i)) {
                    $err_elems[] = $v;	
                }
                else {
                    $err_elems[] = $i .' - '. $v;	
                }
            }
            
            echo '<div class="error lcwp_settings_result"><p>'. implode(' <br/> ', $err_elems) .'</p></div>';	
        }
    }
	
	
	// if successdully saved
	if(isset($_GET['lcwp_sf_success'])) {
		echo '<div class="updated lcwp_settings_result" style="display: none;"><p><strong>'. __('Options saved', 'pcma_ml') .'</strong></p></div>';	
	}
	
	// print form code
    echo $engine->get_code();
    ?>
</div>




<?php // CUSTOM CSS ?>
<style type="text/css">
.pcma_placholders_legend td {
	border: none !important;
	padding-bottom: 5px;
    padding-top: 4px;	
}
.pcma_placholders_legend td p {
	margin: 0 !important;	
}
.pcma_placholders_legend td p small {
	padding-left: 5px;
}
</style>




<?php // SCRIPTS ?>
<script src="<?php echo PC_URL; ?>/js/lc-switch/lc_switch.min.js" type="text/javascript"></script>
<script src="<?php echo PC_URL; ?>/js/chosen/chosen.jquery.min.js" type="text/javascript"></script>

<script type="text/javascript" charset="utf8">
jQuery(document).ready(function($) {
	var mv_is_acting 	= false;
	var mailc_is_acting = false;
	
	
	// test e-mail sending
	jQuery(document).delegate('#pcma_test_btn', 'click', function() {
		var test_mail = jQuery.trim( jQuery('.pc_pcma_test_mail input').val() );
		var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
		 
		if(test_mail != '' && emailReg.test(test_mail)) {
			if(confirm('<?php _e("A test e-mail will be sent to", 'pcma_ml') ?> '+test_mail+', <?php _e("continue?", 'pcma_ml') ?>')) {
				jQuery('#pcma_test_result').html('<div class="pc_loading"></div>');
				
				var data = {
					action: 'pcma_test_mail',
					pcma_mail: test_mail
				};
				jQuery.post(ajaxurl, data, function(response) {
					jQuery('#pcma_test_result').html(response);
				});	
			}
		}
		else { jQuery('#pcma_test_result').html('<?php _e("Insert a valid e-mail", 'pcma_ml') ?>'); }
		
	});
	
	
	////////
	
	
	// verify manually users
	jQuery(document).delegate('.pcma_mv_manual_btn', 'click', function() {
		var user_cat = jQuery(this).attr('rel');
		$mv_result = jQuery(this).parents('tr').find('.pcma_mv_manual_result');
		
		if(user_cat == 'all') {var mess = '<?php _e("All active users with an e-mail will be verified. Continue?", 'pcma_ml') ?>';}
		else {var mess = '<?php _e("Active users with an e-mail in this category will be verified. Continue?", 'pcma_ml') ?>';}
		
		if(!mv_is_acting && confirm(mess)) {
			mv_is_acting = true;
			$mv_result.html('<div class="pc_loading" style="margin-bottom: -3px;"></div>');
	
			var data = {
				action: 'pcma_mv_group_manual',
				pcma_cat: user_cat
			};
			jQuery.post(ajaxurl, data, function(response) {
				var resp = jQuery.trim(response);
				mv_is_acting = false;
				
				if(resp == 'success') {$mv_result.html('<?php _e("Users verified successfully", 'pcma_ml') ?>');}
				else {$mv_result.html(resp);}
			});
		}
	});
	
	
	// send verification e-mails
	jQuery(document).delegate('.pcma_send_vmail_btn', 'click', function() {
		var user_cat = jQuery(this).attr('rel');
		$mv_result = jQuery(this).parents('tr').find('.pcma_mv_manual_result');
		
		if(user_cat == 'all') {var mess = '<?php _e("E-mail will be sent to any active user with an e-mail. Continue?", 'pcma_ml') ?>';}
		else {var mess = '<?php _e("E-mail will be sent to active users in this category. Continue?", 'pcma_ml') ?>';}
		
		if(!mv_is_acting && confirm(mess)) {
			mv_is_acting = true;
			$mv_result.html('<div class="pc_loading" style="margin-bottom: -3px;"></div>');
	
			var data = {
				action: 'pcma_group_manual_send_vmail',
				pcma_cat: user_cat
			};
			jQuery.post(ajaxurl, data, function(response) {
				var resp = jQuery.trim(response);
				mv_is_acting = false;
				
				if(resp == 'success') {$mv_result.html('<?php _e("E-mails sent successfully", 'pcma_ml') ?>');}
				else {$mv_result.html(resp);}
			});
		}
	});
		
	
	// mailchimp - sync manually
	jQuery(document).delegate('#pcma_mc_sync', 'click', function() {
		if(!mailc_is_acting) {
			mailc_is_acting = true;
			jQuery('#pcma_mc_sync_result').html('<div class="pc_loading"></div>');
			
			var data = {
				action: 'pcma_mc_ajax_sync'
			};
			jQuery.post(ajaxurl, data, function(response) {
				var resp = jQuery.parseJSON(jQuery.trim(response));
				
				if(resp.status == 1) {
					jQuery('#pcma_mc_sync_required').remove();	
				}
				
				jQuery('#pcma_mc_sync_result').html('<strong>'+ resp.mess +'</strong>');
				mailc_is_acting = false;
			});
		}
	});



	//////////////////////////////////////////////////
	
	
	// replacing jQuery UI tabs 
	jQuery('.lcwp_settings_tabs').each(function() {
    	var sel = '';
		var hash = window.location.hash;
		
		var $form = jQuery(".lcwp_settings_form");
		var form_act = $form.attr('action');
		
		// track URL on opening
		if(hash && jQuery(this).find('.nav-tab[href='+ hash +']').length) {
			jQuery(this).find('.nav-tab').removeClass('nav-tab-active');
			jQuery(this).find('.nav-tab[href='+ hash +']').addClass('nav-tab-active');	
			
			$form.attr('action', form_act + hash);
		}
		
		// if no active - set first as active
		if(!jQuery(this).find('.nav-tab-active').length) {
			jQuery(this).find('.nav-tab').first().addClass('nav-tab-active');	
		}
		
		// hide unselected
		jQuery(this).find('.nav-tab').each(function() {
            var id = jQuery(this).attr('href');
			
			if(jQuery(this).hasClass('nav-tab-active')) {
				sel = id
			}
			else {
				jQuery(id).hide();
			}
        });
		
		// scroll to top by default
		jQuery("html, body").animate({scrollTop: 0}, 0);
		
		// track clicks
		if(sel) {
			jQuery(this).find('.nav-tab').click(function(e) {
				e.preventDefault();
				if(jQuery(this).hasClass('nav-tab-active')) {return false;}
				
				var sel_id = jQuery(this).attr('href');
				window.location.hash = sel_id.replace('#', '');
				
				$form.attr('action', form_act + sel_id);
				
				// show selected and hide others
				jQuery(this).parents('.lcwp_settings_tabs').find('.nav-tab').each(function() {
                    var id = jQuery(this).attr('href');
					
					if(sel_id == id) {
						jQuery(this).addClass('nav-tab-active');
						jQuery(id).show();		
					}
					else {
						jQuery(this).removeClass('nav-tab-active');
						jQuery(id).hide();	
					}
                });
			});
		}
   });
   
  
   // lc switch
	var pcma_live_checks = function() { 
		jQuery('.lcwp_sf_check').lc_switch('YES', 'NO');
	}
	pcma_live_checks();
	
	
	
	// chosen
	var pcma_live_chosen = function() { 
		jQuery('.lcwp_sf_chosen').each(function() {
			var w = jQuery(this).css('width');
			jQuery(this).chosen({width: w}); 
		});
		jQuery(".lcweb-chosen-deselect").chosen({allow_single_deselect:true});
	}
	pcma_live_chosen();
	
	
	
	//////////////////////////////////////////////////
	
	
	// fixed submit position
	var pcma_fixed_submit = function(btn_selector) {
		var $subj = jQuery(btn_selector);
		if(!$subj.length) {return false;}
		
		var clone = $subj.clone().wrap("<div />").parent().html();

		setInterval(function() {
			
			// if page has scrollers or scroll is far from bottom
			if((jQuery(document).height() > jQuery(window).height()) && (jQuery(document).height() - jQuery(window).height() - jQuery(window).scrollTop()) > 130) {
				if(!jQuery('.lcwp_settings_fixed_submit').length) {	
					$subj.after('<div class="lcwp_settings_fixed_submit">'+ clone +'</div>');
				}
			}
			else {
				if(jQuery('.lcwp_settings_fixed_submit').length) {	
					jQuery('.lcwp_settings_fixed_submit').remove();
				}
			}
		}, 50);
	};
	pcma_fixed_submit('.lcwp_settings_submit');
	
	
	//////////////////////////////////////////////////
	
	
	
	// toast message for better visibility
	if(jQuery('.lcwp_settings_result').length) {
		jQuery('body').append('<div id="lc_toast_mess"></div>');
		
		var $subj = jQuery('.lcwp_settings_result');
		var subj_txt = $subj.find('p').html();
		
		jQuery('head').append(
		'<style type="text/css">' +
		'#lc_toast_mess,#lc_toast_mess *{-moz-box-sizing:border-box;box-sizing:border-box}#lc_toast_mess{background:rgba(20,20,20,.2);position:fixed;top:0;right:-9999px;width:100%;height:100%;margin:auto;z-index:99999;opacity:0;filter:alpha(opacity=0);-webkit-transition:opacity .15s ease-in-out .05s,right 0s linear .5s;-ms-transition:opacity .15s ease-in-out .05s,right 0s linear .5s;transition:opacity .15s ease-in-out .05s,right 0s linear .5s}#lc_toast_mess.lc_tm_shown{opacity:1;filter:alpha(opacity=100);right:0;-webkit-transition:opacity .3s ease-in-out 0s,right 0s linear 0s;-ms-transition:opacity .3s ease-in-out 0s,right 0s linear 0s;transition:opacity .3s ease-in-out 0s,right 0s linear 0s}#lc_toast_mess:before{content:"";display:inline-block;height:100%;vertical-align:middle}#lc_toast_mess>div{position:relative;padding:13px 16px!important;border-radius:2px;box-shadow:0 2px 17px rgba(20,20,20,.25);display:inline-block;width:310px;margin:0 0 0 50%!important;left:-155px;top:-13px;-webkit-transition:top .2s linear 0s;-ms-transition:top .2s linear 0s;transition:top .2s linear 0s}#lc_toast_mess.lc_tm_shown>div{top:0;-webkit-transition:top .15s linear .1s;-ms-transition:top .15s linear .1s;transition:top .15s linear .1s}#lc_toast_mess>div>span:after{font-family:dashicons;background:#fff;border-radius:50%;color:#d1d1d1;content:"";cursor:pointer;font-size:23px;height:15px;padding:5px 9px 7px 2px;position:absolute;right:-7px;top:-7px;width:15px}#lc_toast_mess>div:hover>span:after{color:#bbb}#lc_toast_mess .lc_error{background:#fff;border-left:4px solid #dd3d36}#lc_toast_mess .lc_success{background:#fff;border-left:4px solid #7ad03a}' +
		'</style>');	
		
		// close toast message
		jQuery(document.body).off('click tap', '#lc_toast_mess');
		jQuery(document.body).on('click tap', '#lc_toast_mess', function() {
			jQuery('#lc_toast_mess').removeClass('lc_tm_shown');
		});
		
		
		// if success - simply hide main one
		if($subj.hasClass('updated')) {
			jQuery('#lc_toast_mess').empty().html('<div class="lc_success"><p>'+ subj_txt +'</p><span></span></div>');	
			$subj.remove();	
			
			// remove &lcwp_sf_success
			history.replaceState(null, null, window.location.href.replace('&lcwp_sf_success', ''));
		}
		
		// show errors but keep them visible on top
		else {
			jQuery('#lc_toast_mess').empty().html('<div class="lc_error"><p><?php _e('One or more errors occurred', 'pcma_ml') ?></p><span></span></div>');
			jQuery("html, body").animate({scrollTop: 0}, 0);		
		}
		
		// use a micro delay to let CSS animations act
		setTimeout(function() {
			jQuery('#lc_toast_mess').addClass('lc_tm_shown');
		}, 30);
		
		// auto-close after a while
		setTimeout(function() {
			jQuery('#lc_toast_mess.lc_tm_shown span').trigger('click');
		}, 2300);	
	}
		
});
</script>


<?php
// PC-ACTION - allow extra code printing in settings (for javascript/css)
do_action('pcma_settings_extra_code');
?>
