<?php 

// Manual e-mail verification
function pcma_manual_mv_field($field_id, $field, $value, $all_vals) {
	include_once(PC_DIR . '/functions.php'); 
	
	// user categories
	$user_cats = get_terms('pg_user_categories', 'orderby=name&hide_empty=0'); 
	?>
    <table class="widefat lcwp_settings_table pc_settings_block">
      <thead>
        <tr><th colspan="4"><?php _e("Verify manually all / specific categories users e-mail or send them validation e-mails", 'pcma_ml'); ?></th></tr>
      </thead>
      
      <tr>
        <td class"lcwp_sf_label" style="width: 300px;"><?php _e("Every user", 'pcma_ml'); ?></td>
        <td style="width: 110px;">
            <input type="button" value="<?php _e("Verify", 'pcma_ml'); ?>" rel="all" class="button-secondary pcma_mv_manual_btn" style="width: 90px;" />
        </td>
        <td style="width: 160px;">
            <input type="button" value="<?php _e("Send validation e-mail", 'pcma_ml'); ?>" rel="all" class="button-secondary pcma_send_vmail_btn" />
        </td>
        <td>
        	<span class="info pcma_mv_manual_result"></span>
        </td>
      </tr>
      
      <?php foreach($user_cats as $cat) : ?>
        <tr>
          <td class"lcwp_sf_label"><?php echo $cat->name ?></td>
          <td>
            <input type="button" value="<?php _e("Verify", 'pcma_ml'); ?>" rel="<?php echo $cat->term_id ?>" class="button-secondary pcma_mv_manual_btn" style="width: 90px;" />
          </td>
          <td>
            <input type="button" value="<?php _e("Send validation e-mail", 'pcma_ml'); ?>" rel="<?php echo $cat->term_id ?>" class="button-secondary pcma_send_vmail_btn" />
          </td>
          <td>
          	<span class="info pcma_mv_manual_result"></span>
          </td>
        </tr>
      <?php endforeach; ?>
    </table>   
    <?php	
}



// Admin notifier - receiver email address
function pcma_nnu_mail_multi_field($field_id, $field, $value, $all_vals) {
	?>
    <tr class="pcma_<?php echo $field_id ?>">
		<td class="lcwp_sf_label"><label><?php _e("Receiver's e-mail address", 'pcma_ml') ?></label></td>
		<td class="lcwp_sf_field" colspan="2">
			
            <?php $val = (is_array($value)) ? implode(',', $value) : $value; ?>
            <input type="text" name="<?php echo $field_id ?>" value="<?php echo $val ?>" autocomplete="off" />
			
            <p class="lcwp_sf_note"><?php _e('E-mail receiving the notification - multiple addresses supported, <strong>comma split</strong>', 'pcma_ml') ?></p> 
		</td>
	</tr>
    <?php
}


