<?php
// THIS FILE USES ALSO PRIVATECONTENT FUNCTIONS


// replace the placeholders in the mail texts
function pcma_replace_placeholders($user_id, $txt, $user_data = false) {
	global $pc_users;
	
	
	// has to backup user session?
	//// setup a fake global var to allow shortcodes execution seamlessly - then restore the original value
	$us_to_backup = (isset($GLOBALS['pc_user_id'])) ? $GLOBALS['pc_user_id'] : false;
	$GLOBALS['pc_user_id'] = $user_id;
	
	
	// retrieve the user data
	if(!$user_data) {
		global $pc_users;
		$data = $pc_users->get_user($user_id, array('to_get' => array('name', 'surname', 'username', 'email', 'tel', 'categories')));
	}
	else {$data = $user_data;}
	
	$site_url_link = '<a href="'.get_site_url().'">'.get_site_url().'</a>';
	
	// replace categories
	$cats = (strpos($txt, '%CAT%') !== false) ? $pc_users->data_to_human('categories', $data['categories']) : '';

	$txt = str_replace(
		array('%SITE-URL%', '%SITE-TITLE%', '%NAME%', '%SURNAME%', '%USERNAME%', '%MAIL%', '%TEL%', '%CAT%'),
		array($site_url_link, get_bloginfo('name'), $data['name'], $data['surname'], $data['username'], $data['email'], $data['tel'], $cats),
		$txt
	);
	
	
	// execute eventual shortcodes
	$txt = do_shortcode($txt);
	
	// restore user session
	if($us_to_backup) {
		$GLOBALS['pc_user_id'] = $us_to_backup;	
	} else {
		unset($GLOBALS['pc_user_id']);	
	}
	
	return $txt;	
}



// check if use SMTP for sending mails
function pcma_use_smtp() {
	$host = get_option('pcma_smtp_host');
	$user = get_option('pcma_smtp_user');
	$psw = base64_decode(get_option('pcma_smtp_psw')); 
	
	if(
		get_option('pcma_use_smtp') && 
		$host && trim($host) != '' &&
		$user && trim($user) != '' &&
		$psw && trim($psw) != ''
	) {
		return array(
			'host' => $host,
			'user' => $user,
			'psw' => $psw
		);
	}
	else {
		return false;	
	}
}
	


// check if a user is certified via e-mail
function pcma_user_is_verified($id, $subj = 'user_id') {
	if($subj == 'user_id') {
		global $pc_users;
		$id = $pc_users->get_user_field($id, 'page_id');
	}
		
	return (get_post_meta($id, 'pcma_is_verified', true)) ? true : false;
}
