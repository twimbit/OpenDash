<?php

///////////////////////////////////////////
/// ADD-ON MENU ///////////////////////////
///////////////////////////////////////////

add_action('pc_addons_menu_ready', 'pcma_in_pc_menu', 50);

function pcma_in_pc_menu($slug) {
	add_submenu_page($slug, 'Mail Actions', 'Mail Actions', 'install_plugins', 'pcma_settings', 'pcma_settings');
	
	if(pcma_is_active()) {
		add_submenu_page($slug, 'Quick Mail', 'Quick Mail', get_option('pc_min_role_tmu', 'upload_files'), 'pcma_quick_mail', 'pcma_quick_mail');
	}
}
function pcma_settings() { include_once(PCMA_DIR . '/settings/view.php'); }
function pcma_quick_mail() { include_once(PCMA_DIR . '/quick_mail.php'); }





//////////////////////////////////////////////////
// ADD RECOVERY PSW FIELD DETAILS into settings //
//////////////////////////////////////////////////

function pcma_rp_field_details_field($field_id, $field, $value, $all_vals) {
	$icon 	= get_option('pcma_rp_field_icon');
	?>
    <tr class="pc_<?php echo $field_id ?>_tr">
		<td class="lcwp_sf_label">
        	<label>Mail Actions add-on - <?php _e("Password recovery's icon", 'pcma_ml') ?></label>
        </td>
		<td class="lcwp_sf_field">
			
            <div class="pc_field_icon_trigger">
            	<i class="fa <?php echo $icon ?>" title="set icon" style="display: inline-block;"></i>
                <input type="hidden" name="pcma_rp_field_icon" value="<?php echo $icon ?>" maxlength="40" /> 
            </div>
		</td>
	</tr>
    <?php
}
function pcma_rp_field_details($structure) {
	$structure['styling']['fix_field_details']['fields']['pcma_rp_field_details'] = array(
		'type'		=> 'custom',
		'callback'	=> 'pcma_rp_field_details_field',
		'validation'=> array(
			array('index' => 'pcma_rp_field_icon', 'label' => "Mail Actions add-on - Psw recovery icon"),
		)
	);
	return $structure;
}
add_filter('pc_settings_structure', 'pcma_rp_field_details');





//////////////////////////////////////////////////
// ADD RECOVERY PSW BUTTON'S ICON into settings //
//////////////////////////////////////////////////

function pcma_rp_btn_icon_field($field_id, $field, $value, $all_vals) {
	$icon = get_option($field_id);
	?>
    <tr class="pc_<?php echo $field_id ?>_tr">
		<td class="lcwp_sf_label">
        	<label>Mail Actions add-on - <?php _e("Password recovery button's icon", 'pcma_ml') ?></label>
        </td>
		<td class="lcwp_sf_field">
			
            <div class="pc_field_icon_trigger">
            	<i class="fa <?php echo $icon ?>" title="set icon" style="display: inline-block;"></i>
                <input type="hidden" name="<?php echo $field_id ?>" value="<?php echo $icon ?>" maxlength="40" /> 
            </div>
		</td>
	</tr>
    <?php
}
function pcma_rp_btn_opt($structure) {
	$structure['styling']['button_icons']['fields']['pcma_rp_btn_icon'] = array(
		'type'		=> 'custom',
		'callback'	=> 'pcma_rp_btn_icon_field',
		'validation'=> array(
			array('index' => 'pcma_rp_btn_icon', 'label' => "Mail Actions add-on - Psw recovery button's icon"),
		)
	);
	return $structure;
}
add_filter('pc_settings_structure', 'pcma_rp_btn_opt');





/////////////////////////////////////////////////////////////////////





// declare forbidden field indexes
function pcma_forbidden_field_indexes($fields) {
	return array_merge($fields, array('pcma_mc_disclaimer', 'pcma_psw_username'));
}
add_filter('pc_forbidden_field_indexes', 'pcma_forbidden_field_indexes');





/////////////////////////////////////////////////////////////////////





///////////////////////////////////////////
/// MAIL IMPORTED USERS ///////////////////
///////////////////////////////////////////

function pcma_mail_imported($imported_list) {
	if(pcma_is_active() && get_option('pcma_niu_enable')) {
		include_once(PCMA_DIR . '/functions.php');
		global $pc_users;
		
		$raw_txt = get_option('pcma_niu_txt');
		
		foreach($imported_list as $user_id => $arr_data) {
			if(isset($arr_data['email']) && !empty($arr_data['email'])) {
				
				// encrypt to be used in placeholder replacement
				//$arr_data['psw'] = $pc_users->encrypt_psw($arr_data['psw']); 
				
				$txt = pcma_replace_placeholders($user_id, $raw_txt, $arr_data);
				$txt = str_replace('%PSW%', $arr_data['psw'], $txt);

				$title = pcma_replace_placeholders($user_id, get_option('pcma_niu_subj'), $arr_data);
				$mail_sent = pcma_send_mail($arr_data['username'], $arr_data['email'], $title, $txt);
			}
		}
	}
}
add_action('pc_imported_users', 'pcma_mail_imported');





///////////////////////////////////////////
/// ADMIN NOTIFIER - NEW USER /////////////
///////////////////////////////////////////

// send e-mail when new user registers
function pcma_admin_notifier_nu($user_id) {
	if(pcma_is_active() && get_option('pcma_nnu_enable')) {
		include_once(PCMA_DIR . '/functions.php');
		
		$txt = get_option('pcma_nnu_txt');
		$txt = pcma_replace_placeholders($user_id, $txt);
		$title = pcma_replace_placeholders($user_id, get_option('pcma_nnu_subj'));
		
		$to_mail = (get_option('pcma_nnu_mail_multi')) ? get_option('pcma_nnu_mail_multi') : get_option('pcma_nnu_mail');
		
		
		// get user data to set ReplyTo
		global $pc_users;
		$replyto_name  = $pc_users->get_user_field($user_id, 'username');
		$replyto_email = $pc_users->get_user_field($user_id, 'email');
		
		$mail_sent = pcma_send_mail(get_bloginfo('name'), $to_mail, $title, $txt, false, false, $replyto_name, $replyto_email);
		return true;
	}
	else {return false;}
}
add_action('pc_registered_user', 'pcma_admin_notifier_nu');





///////////////////////////////////////////
/// ADMIN NOTIFIER - SELF-DELETED USER ////
///////////////////////////////////////////

// send e-mail when new user registers
function pcma_admin_notifier_du($user_id) {
	if(pcma_is_active() && get_option('pcma_dun_enable')) {
		include_once(PCMA_DIR . '/functions.php');
		
		$txt = get_option('pcma_dun_txt');
		$txt = pcma_replace_placeholders($user_id, $txt);
		$title = pcma_replace_placeholders($user_id, get_option('pcma_dun_subj'));
		
		$to_mail = get_option('pcma_nnu_mail_multi');
		$mail_sent = pcma_send_mail(get_bloginfo('name'), $to_mail, $title, $txt);
		return true;
	}
	else {return false;}
}
add_action('pc_pre_self_user_del', 'pcma_admin_notifier_du');





///////////////////////////////////////////
/// USER NOTIFIER - FOR ACTIVATED USERS ///
///////////////////////////////////////////

// send e-mail if admin enables them
function pcma_activ_user_notifier($user_id) {
	if(pcma_is_active() && get_option('pcma_nau_enable')) {
		include_once(PCMA_DIR . '/functions.php');
				
		$title = get_option('pcma_nau_subj');
		$txt = get_option('pcma_nau_txt');
		
		global $pc_users;
		$u_data = $pc_users->get_user($user_id, array('to_get' => array('id', 'email', 'name', 'surname', 'username', 'tel', 'psw', 'categories')));
		
		if(!empty($u_data) && !empty($u_data['email'])) {
			$user_title = pcma_replace_placeholders($u_data['id'], $title, $u_data);
			$user_txt = pcma_replace_placeholders($u_data['id'], $txt, $u_data);
			
			// send
			$mail_sent = pcma_send_mail($u_data['username'], $u_data['email'], $user_title, $user_txt);	
		}
	}
}
add_action('pc_user_activated', 'pcma_activ_user_notifier');





///////////////////////////////////////////
/// PASSWORD RECOVERY FUNCTIONS ///////////
///////////////////////////////////////////


// password recovery trigger
function pcma_psw_recovery_trigger($form) {
	if(pcma_is_active() && get_option('pcma_psw_recovery')) {
		$code = '<small class="pcma_psw_recovery_trigger">'. __('forgot password?', 'pcma_ml') .'</small>';
		return $form . $code;
	}
	else {return $form;}
}
add_filter('pcma_psw_recovery_trigger', 'pcma_psw_recovery_trigger');


// password recovery code
function pcma_psw_recovery_code($form) {
	if(pcma_is_active() && get_option('pcma_psw_recovery')) {
		
		$label = (get_option('pcma_pr_with_email')) ? __('Insert your username or e-mail', 'pcma_ml') : __('Insert your username', 'pcma_ml'); 
		
		// fields icon
		$pr_icon_class 	= (get_option('pcma_rp_field_icon')) ? 'pc_field_w_icon' : '';
		$pr_icon 		= ($pr_icon_class) ? '<span class="pc_field_icon" title="'. esc_attr($label) .'"><i class="fa '.get_option('pcma_rp_field_icon').'"></i></span>' : '';
		
		// button's icon
		$icon = (get_option('pcma_rp_btn_icon')) ? '<i class="fa '. get_option('pcma_rp_btn_icon') .'"></i>' : '';
		
		// placeholders only if no-label is active
		$placeh = (get_option('pg_nolabel')) ? 'placeholder="'. esc_attr($label) .'"' : ''; 
		
		$code = '
		<div class="pcma_psw_recovery_wrap" style="display: none;">
			<div class="pc_login_row '.$pr_icon_class.'">
				<label>'. $label .'</label>
				
				<div class="pc_field_container">
					'. $pr_icon .'
					<input type="text" name="pcma_psw_username" class="pcma_psw_username" value="" '. $placeh .' autocomplete="off" />
				</div>
			</div>
			<div class="pcma_psw_recovery_message"></div>
	
			<div class="pc_login_smalls">
				<small class="pcma_del_recovery">'. __('Back to login form', 'pcma_ml') .'</small>
			</div>
			<button class="pcma_do_recovery"><span class="pc_inner_btn">'.$icon. __('Recover', 'pcma_ml') .'</span></button>
		</div>';
		
		return $form . $code;
	}
	else {return $form;}
}
add_filter('pcma_psw_recovery_code', 'pcma_psw_recovery_code');



// custom CSS for recovery psw form part
function pcma_psw_recovery_css() {
	if(!pcma_is_active() || !get_option('pcma_psw_recovery') || get_option('pg_disable_front_css')) {return true;}
	?>
    <style type="text/css">
	.pcma_psw_recovery_wrap label,
	.pcma_psw_recovery_wrap input {
		display: inline-block;
		width: 100%;	
		padding: 0 0 3px;
	}
	.pcma_psw_recovery_message {
		margin-bottom: 18px;
    	min-height: 6px;
	}
	.pcma_psw_recovery_trigger,
	.pcma_del_recovery {
		font-size: 11px;
		line-height: 15px;
		cursor: pointer;
	}
	.pc_rm_login .pcma_psw_recovery_trigger {
		margin-left: 6px;	
		padding-left: 6px;
		border-left-style: solid;
		border-left-width: 1px;
		position: relative;
		top: -4px;
	}
	.pc_login_form .pcma_do_recovery {
		float: left;
		margin-top: -18px;	
	}
	
	/* if smalls are too large and for widget */
	.PrivateContentLogin .pcma_psw_recovery_message,
	.pc_mobile_login .pcma_psw_recovery_message {
		margin-bottom: 10px !important;	
	}
	.PrivateContentLogin .pcma_do_recovery,
	.pc_mobile_login .pcma_do_recovery {
		float: none;
		margin-top: 10px;	
	}
	</style>
    <?php
}
add_action('pc_inline_css', 'pcma_psw_recovery_css');



// set e-mail field as required if psw recovery with mail is active
function pcma_set_mail_sys_req($bool) {

	if(pcma_is_active()) {
		if(get_option('pcma_psw_recovery') && get_option('pcma_pr_with_email')) {
			return true;
		}
	}
	
	return $bool;
}
add_filter('pc_set_mail_required', 'pcma_set_mail_sys_req', 999, 2);





///////////////////////////////////////////////////
/// WELCOME MESSAGE ///////////////////////////////
///////////////////////////////////////////////////


// send mail on registation or
function pcma_registration_welcome_mess($user_id, $status) {
	if(pcma_is_active()) { 
		$switch = get_option('pcma_wm_receiver', 'active_users');
		
		if(get_option('pcma_wm_enable') && ($switch == 'any_user' || $status == 1)) {
			include_once(PCMA_DIR . '/functions.php');
	
			$title = get_option('pcma_wm_subj');
			$txt = get_option('pcma_wm_txt');
			
			global $pc_users;
			$u_data = $pc_users->get_user($user_id, array('to_get' => array('id', 'email', 'name', 'surname', 'username', 'tel', 'psw', 'categories')));
			
			if(!empty($u_data) && !empty($u_data['email'])) {
				$user_title = pcma_replace_placeholders($u_data['id'], $title, $u_data);
				$user_txt = pcma_replace_placeholders($u_data['id'], $txt, $u_data);
				
				// send
				$mail_sent = pcma_send_mail($u_data['username'], $u_data['email'], $user_title, $user_txt);	
			}
		}
	}
}
add_action('pc_registered_user', 'pcma_registration_welcome_mess', 10, 2);


// send mail if WP user allowed it inserting via admin panel
function pcma_add_user_welcome_mess($user_id) {
	if(isset($_POST['pcma_au_send_welcome']) && $_POST['pcma_au_send_welcome']) {
		pcma_registration_welcome_mess($user_id, 1);	
	}
}
add_action('pc_user_added_by_admin', 'pcma_add_user_welcome_mess');


// "Add user" page - add switch for welcome message
function pcma_add_user_block($fdata, $user_id) {
	if(!empty($user_id) || !get_option('pcma_wm_enable')) {return false;}	
	?>
    <h3 style="border: none !important;">Mail Actions add-on - <?php _e('Welcome message', 'pcma_ml') ?></h3>
    <table class="widefat pc_table pc_add_user" style="margin-bottom: 25px;">
      <tbody>
        <tr>
            <td class="pc_label_td"><?php _e("Send welcome message to user?", 'pcma_ml') ?></td>
            <td class="pc_field_td">
                <input type="checkbox" name="pcma_au_send_welcome" value="1" <?php if(isset($_POST['pcma_au_send_welcome']) && $_POST['pcma_au_send_welcome']) echo 'checked="checked"' ?> class="ip_checks" />
            </td>
        </tr>
      </tbody>
    </table>
<?php
}
add_action('pc_add_user_body', 'pcma_add_user_block', 25, 2);





//////////////////////////////////////////////
/// E-MAIL VERIFICATION FUNCTIONS ////////////
//////////////////////////////////////////////

// users list e-mail flag
function pcma_user_list_flag($badges, $user_id) {
	include_once(PCMA_DIR . '/functions.php');
	
	if(get_option('pcma_mv_enable') && pcma_is_active() && pcma_user_is_verified($user_id)) {
		$badges .= '<img src="'.PCMA_URL.'/img/mail_verified.png" title="'. esc_attr( __('e-mail verified', 'pcma_ml')) .'" />';
	}
	
	return $badges;
}
add_filter('pc_users_list_badges', 'pcma_user_list_flag', 10, 2);



// flag and manual validation for admin user dashboard
function pcma_user_dashboard_mail_verif($sections, $user_id) {
	
	if(!get_option('pcma_mv_enable') || !pcma_is_active() || !$user_id) {
		return $sections;	
	}

	return 
	$sections + array(
		'pcma_mv' => array(
			'name'		=> 'Mail Actions add-on - '. __('E-mail Verification', 'pcma_ml'),
			'classes'	=> 'pc_ud_onehalf_w',
			'callback' 	=> 'pcma_user_dashboard_mail_verif_cb'
		)
	);	
}
add_filter('pc_user_dashboard_main_tab_sections', 'pcma_user_dashboard_mail_verif', 20, 2);


function pcma_user_dashboard_mail_verif_cb($user_id) {
	include_once(PCMA_DIR . '/functions.php');
	
	// if is verified
	if(pcma_user_is_verified($user_id)) {
		echo '
		<div class="pc_warn pc_wps_warn pc_success">
			'.__("Account succesfully verified via e-mail", 'pcma_ml'); 
			
			if($GLOBALS['pc_cuc_edit']) {
				echo '
				<button class="button-secondary" id="pcma_mv_del_validate">'. __("Dismiss Verification", 'pcma_ml') .'</button>';
			}
			
		echo '	
		</div>';
	}
	
	// if not
	else {
		global $pc_users;
		$user_email = $pc_users->get_user_field($user_id, 'email');
		
		
		// if there is not mail
		if(empty($user_email)) {
			echo '
			<div class="pc_warn pc_wps_warn pc_error">
				'.__("Verification Impossible - User has no e-mail", 'pcma_ml').'
			</div>';
		}
		
		else {
			echo '
			<div class="pc_warn pc_wps_warn pc_warning">
				'.__('Account not verified yet', 'pcma_ml'); 
				
				if($GLOBALS['pc_cuc_edit']) {
					echo '
					<button class="button-secondary" id="pcma_mv_validate">'. __("Verify Manually", 'pcma_ml') .'</button>
					<button class="button-secondary" id="pcma_send_vmail">'. __("Send Validation E-mail", 'pcma_ml') .'</button>';
				}
				
			echo '	
			</div>';	
		}
	}
		
		
	// javascript to validate and un-validate - only if CUC
	if($GLOBALS['pc_cuc_edit']) :
	?>
	<script type="text/javascript">
	jQuery(document).ready(function($) {
		var is_acting = false;
		
		// send validation mail
		$(document).delegate('#pcma_send_vmail', 'click', function(e) {
			e.preventDefault();
			
			if(confirm("<?php _e('Send account validation e-mail to user?', 'pcma_ml') ?>")) {
				
				var $btn = $(this);
				$btn.fadeTo(200, 0.7);
				is_acting = true;
				
				var data = {
					action: 'pcma_manual_send_vmail',
					pcma_uid: <?php echo $user_id; ?>
				};
				$.post(ajaxurl, data, function(response) {
					if($.trim(response) == 'success') {
						pc_toast_message('success', "<?php echo __("Verification e-mail succesfully sent", 'pcma_ml') ?>");
					}
					else {
						pc_toast_message('error', response);
					}
					
					$btn.fadeTo(200, 1);
					is_acting = false;
				});
			}	
		});
		
		
		// validate manually
		$(document).delegate('#pcma_mv_validate', 'click', function(e) {
			e.preventDefault();
			
			if(confirm("<?php _e('Confirm account validation?', 'pcma_ml') ?>")) {
				
				var $btn = $(this);
				$btn.fadeTo(200, 0.7);
				is_acting = true;
				
				var data = {
					action: 'pcma_mv_manual',
					pcma_uid: <?php echo $user_id; ?>
				};
				$.post(ajaxurl, data, function(response) {
					
					if($.trim(response) == 'success') {
						$btn.parents('.pc_warn').removeClass('pc_warning').addClass('pc_success');
						
						$btn.parents('.pc_warn').html(
							"<?php _e("Account succesfully verified via e-mail", 'pcma_ml') ?>" +
							"<button class='button-secondary' id='pcma_mv_del_validate'>" +
								"<?php _e("Dismiss Verification", 'pcma_ml') ?>" +
							"</button>"
						);
					}
					else {
						pc_toast_message('error', response);
					}
					
					$btn.fadeTo(200, 1);
					is_acting = false;
				});
			}	
		});
		
		
		// cancel validation
		$(document).delegate('#pcma_mv_del_validate', 'click', function(e) {
			e.preventDefault();

			if(confirm("<?php _e('Dismiss e-mail validation?', 'pcma_ml') ?>")) {
				
				var $btn = $(this);
				$btn.fadeTo(200, 0.7);
				is_acting = true;
				
				var data = {
					action: 'pcma_del_mv_manual',
					pcma_uid: <?php echo $user_id; ?>
				};
				$.post(ajaxurl, data, function(response) {
					if($.trim(response) == 'success') {
						pc_toast_message('success', "<?php echo __("Verification succesfully dismissed!", 'pcma_ml') ?>");
						
						setTimeout(function() {
							window.location.reload();
						}, 1800);
					}
					else {
						pc_toast_message('error', response);
	
						$btn.fadeTo(200, 1);
						is_acting = false;
					}
				});
			}	
		});
	});
	</script>
	<?php
	endif;
}



// force e-mail use in registration forms if Users Verification or psw recovery with mail are active
function pcma_set_mail_required($form_structure, $form_id) {
	
	if(pcma_is_active()) {
		if(get_option('pcma_mv_enable') || (get_option('pcma_psw_recovery') && get_option('pcma_pr_with_email')) ) {
			if(!in_array('email', $form_structure['include'])) {$form_structure['include'][] = 'email';}
			if(!in_array('email', $form_structure['require'])) {$form_structure['require'][] = 'email';}
		}
	}
	
	return $form_structure;
}
add_filter('pc_registration_form', 'pcma_set_mail_required', 999, 2);



// send verification e-mail to user - after successfull registration
function pcma_send_mail_verif($user_id, $user_page_id = false, $user_data = array()) {
	include_once(PCMA_DIR . '/functions.php');
	
	if(pcma_is_active() && get_option('pcma_mv_enable') && get_option('pcma_mv_pag')) {
		global $pc_users;
		
		// get user data
		$user_data = $pc_users->get_user($user_id, array('to_get' => array('name', 'surname', 'username', 'email', 'tel', 'psw', 'categories', 'status', 'page_id')));
		
		// only if user is pending or if forcing sending
		if(!empty($user_data['email']) && (isset($GLOBALS['pcma_force_mail_verif_sending']) || $user_data['status'] == 3)) {
			include_once(PC_DIR .'/functions.php');
			
			// if page id is not specified
			if(!$user_page_id) {$user_page_id = $user_data['page_id'];}
			
			// create an unique id and store it for the user
			$valid_id = uniqid();
			$structure = array('id' => $valid_id, 'validated' => 0);
			update_post_meta($user_page_id, 'pcma_verif_id', $structure);
			
			// validation url
			$redir = pc_wpml_translated_pag_id(get_option('pcma_mv_pag'));
			$baselink = get_permalink($redir);
			$sign = (strpos($baselink, '?') === false) ? '?' : '&';
			
			$full_link = $baselink . $sign . 'pcma_user='.$user_id.'&pcma_key='.$valid_id;
			$full_link = '<a href="'. $full_link .'">'. $full_link .'</a>';
	
			$mail_title = pcma_replace_placeholders($user_id, get_option('pcma_mv_subj'));
			
			$mail_txt = str_replace('%VER-URL%', $full_link, get_option('pcma_mv_txt'));
			$mail_txt = pcma_replace_placeholders($user_id, $mail_txt, $user_data);
			
			// send mail
			return pcma_send_mail($user_data['username'], $user_data['email'], $mail_title, $mail_txt);
		}
	}
}
add_action('pc_registered_user', 'pcma_send_mail_verif');



// exclude landing page from PvtContent site lock
function pcma_mail_verif_landing_csl_exception($excluded_pages) {
	if(pcma_is_active() && get_option('pcma_mv_enable') && get_option('pcma_mv_pag')) {
		include_once(PC_DIR .'/functions.php');
		
		$excluded_pages[] = pc_wpml_translated_pag_id(get_option('pcma_mv_pag'));
	}
	return $excluded_pages;
}
add_filter('pc_complete_lock_exceptions', 'pcma_mail_verif_landing_csl_exception', 10);

