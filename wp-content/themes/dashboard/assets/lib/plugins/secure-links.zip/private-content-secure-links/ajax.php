<?php
////////////////////////////////////////////////
////// ADD LINK TERM ///////////////////////////
////////////////////////////////////////////////

function pcsl_add_link() {
	if (!isset($_POST['pcsl_nonce']) || !wp_verify_nonce($_POST['pcsl_nonce'], 'lcwp_ajax')) {die('Cheating?');};
	
	// links
	if(!isset($_POST['pcsl_orig_link'])) {
		die( __('Original links are wrong or missing', 'pcsl_ml') );
	}
	$orig_links = str_replace('~', '&sim;', trim(addslashes($_POST['pcsl_orig_link'])));
	
	// subject
	if(!isset($_POST['pcsl_subj']) || !in_array($_POST['pcsl_subj'], array('user', 'cat')) ) {
		die( __('Subject is missing', 'pcsl_ml') );
	}
	$subj = trim($_POST['pcsl_subj']);
	
	// subject allow
	if(!isset($_POST['pcsl_allow']) || empty($_POST['pcsl_allow'])) {
		die( __('Subject ID is missing', 'pcsl_ml') );
	}
	$allow = (array)$_POST['pcsl_allow'];
	
	// subject block
	$block = (!isset($_POST['pcsl_block']) || empty($_POST['pcsl_block'])) ? array() : (array)$_POST['pcsl_block'];
	
	// note
	$note = (!isset($_POST['pcsl_note'])) ? '' : str_replace('~', '&sim;', trim($_POST['pcsl_note']));
	
	
	// allow multi-links submission
	$orig_links = (array)preg_split('/\r\n|[\r\n]/', $orig_links);
	$validated_links = array();
	
	$a = 1;
	foreach($orig_links as $link) {
		if(empty($link)) {continue;}
		
		if(!filter_var(trim($link), FILTER_VALIDATE_URL)) {
			die( __('Please use a valid URL at line', 'pcsl_ml') .' '.$a);	
		}
		
		$validated_links[] = trim($link);
		$a++;
	}
	
	if(empty($validated_links)) {
		die( __('No valid URLs', 'pcsl_ml') );		
	}


	/* TERMS STRUCTURE
	 * name = original link
	 * slug = new link id
	 * description = imploded array of (subj, allow, block, link_note) - old v1 was (subj, subj_id, link_note)
	 				 array imploded with ~
					 use this system to allow rapid searches
					 
					 allow/block vars are imploded with comma and "a"/"b" is prepended to allow fast searches since v2
	 */
	include_once(PCSL_DIR . '/functions.php'); 

	$validated_links = array_unique($validated_links);
	foreach($validated_links as $link) {
		
		$allows_val = 'a_'.implode(',a_', $allow);
		$blocks_val = (empty($block)) ? '' : 'b_'.implode(',b_', $block);
		
		$resp = wp_insert_term( 
			$link, 
			'pcsl_links', array( 
				'slug' 		  => pcsl_uniqid(),
				'description' => implode('~', array($subj, $allows_val, $blocks_val, $note) )
			)
		);
	}
	
	if(is_array($resp)) {die('success');}
	else {
		$err_mes = $resp->errors['term_exists'][0];
		die($err_mes);
	}
}
add_action('wp_ajax_pcsl_add_link', 'pcsl_add_link');





////////////////////////////////////////////////
////// DELETE LINK TERM ////////////////////////
////////////////////////////////////////////////

function pcsl_del_link() {
	if (!isset($_POST['pcsl_nonce']) || !wp_verify_nonce($_POST['pcsl_nonce'], 'lcwp_ajax')) {die('Cheating?');};
	
	if(!isset($_POST['link_id'])) {die('data is missing');}
	$id = (int)$_POST['link_id'];
	
	$resp = wp_delete_term( $id, 'pcsl_links');

	if($resp == '1') {die('success');}
	else { die( __('Error during the link deletion', 'pcsl_ml')); }
}
add_action('wp_ajax_pcsl_del_link', 'pcsl_del_link');






////////////////////////////////////////////////
////// SEARCH LINKS ////////////////////////////
////////////////////////////////////////////////

function pcsl_search_links($search_val = false) {
	
	// ajax mode
	if(empty($search_val)) {
		if (!isset($_POST['pcsl_nonce']) || !wp_verify_nonce($_POST['pcsl_nonce'], 'lcwp_ajax')) {die('Cheating?');};
		$subj = (!isset($_POST['pcsl_src_subj'])) ? 'note' : $_POST['pcsl_src_subj'];
		
		if(!isset($_POST['pcsl_src_val']) || trim($_POST['pcsl_src_val']) == '') { pcsl_links_list(false); }
		else {$val = trim($_POST['pcsl_src_val']);}
	}
	
	// direct call
	else {
		$subj = 'note';
		$val = $search_val;
	}

	/////////

	// search by ID
	if($subj == 'id') {
		$term = get_term((int)$val, 'pcsl_links');	
		
		if(!is_object($term)) {$links = array();}
		else {$links = array($term);}
	}

	// search by secure link - only one result
	elseif($subj == 'secure') {
		$url_array = explode('?', $val);
		$slug = str_replace('pcsl=', '', end($url_array));	
		
		$term = get_term_by('slug', $slug, 'pcsl_links');
		
		if(!is_object($term)) {$links = array();}
		else {$links = array($term);}
	}
	
	// search by original link - starting with the given string
	elseif($subj == 'orig') {
		$args = array(
			'orderby'       => 'id', 
			'order'         => 'DESC',
			'hide_empty'    => 0,
			'search'		=> $val 
		);
		$links = get_terms('pcsl_links', $args);
	}
	
	// search by note - custom query
	else {
		global $wpdb;
		$val = addslashes($val);

		// metabox links filter - compose the search query caring retrocompatibility
		if(strpos($val, '~') !== false) {
			$s_vals = explode('~', $val);
			
			$where  = " AND description LIKE '". $s_vals[0] ."~%' AND";
			$where .= " (description LIKE '". $val ."~%' OR description LIKE '%a_". $s_vals[1] ."~%' OR description LIKE '%a_". $s_vals[1] .",%')"; 
		}
		
		// normal search
		else {
			$where = " AND description LIKE '%". $val ."%'";
		}
		
		// query
		$results = $wpdb->get_results("SELECT term_id FROM ".$wpdb->prefix."term_taxonomy WHERE taxonomy = 'pcsl_links' ". $where ." ORDER BY term_id LIMIT 9999");
		//echo $wpdb->last_query; // debug
		
		// once have IDs, get full terms structure
		$to_get = array();
		foreach($results as $term_obj) {
			$to_get[] = $term_obj->term_id;	
		}

		if(empty($to_get)) {
			$links = array();	
		}
		else {
			$args = array(
				'orderby'       => 'id', 
				'order'         => 'DESC',
				'hide_empty'    => 0,
				'include'		=> $to_get 
			);
			$links = get_terms('pcsl_links', $args);
		}
	}
	
	// is direct search? just return links
	if(!empty($search_val)) {
		return $links;	
	}
	else {
		pcsl_links_list($links);
	}
}
add_action('wp_ajax_pcsl_search_links', 'pcsl_search_links');





////////////////////////////////////////////////
////// LOAD LINKS LIST /////////////////////////
////////////////////////////////////////////////

function pcsl_links_list($direct_links_list = false) {
	include_once(PCSL_DIR . '/functions.php');
	
	if(empty($direct_links_list)) {
		if (!isset($_POST['pcsl_nonce']) || !wp_verify_nonce($_POST['pcsl_nonce'], 'lcwp_ajax')) {die('Cheating?');};
	}
	
	// ajax call
	if(!is_array($direct_links_list)) {
		if(!isset($_POST['links_page']) || !filter_var($_POST['links_page'], FILTER_VALIDATE_INT)) {$pag = 1;}
		$pag = (int)$_POST['links_page'];
		
		$per_pag = 15;
		$links = pcsl_get_links($per_pag, $pag); 
		$tot = wp_count_terms('pcsl_links', array('hide_empty' => false));
	}
	
	// direct search call
	else {
		$links = $direct_links_list;
		$tot = count($links);
		
		$pag = 1;
		$per_pag = 999;
	}
	
	// process links
	if(!is_array($links) || count($links) == 0) {die('<p>'.__('No existing links', 'pcsl_ml').' ..</p>');}
	
	// download counter
	$download_count = get_option('pcsl_download_counter', array());
	if(!is_array($download_count)) {$download_count = array();}
	
	// print
	echo '
	<table class="widefat pc_table">
      <thead>
        <tr>
          <th style="width: 15px; padding-right: 0px;"></th>
		  <th style="width: 35px; text-align: center;">'.__('ID', 'pcsl_ml').'</th>
          <th>'.__('Original link', 'pcsl_ml').'</th>
          <th style="width: 90px;">'.__('Type', 'pcsl_ml').'</th>
          <th>'.__('Secure link', 'pcsl_ml').'</th>
          <th>'.__('Allows', 'pcsl_ml').'</th>
		  <th>'.__('Blocks', 'pcsl_ml').'</th>
          <th>'.__('Notes', 'pcsl_ml').'</th>
		  <th style="width:50px;">'.__('Clicked', 'pcsl_ml').'</th>
        </tr>
      </thead>
	  <tbody>';
	
	foreach($links as $link) {
		$sl = pcsl_secure_link($link->slug);
		$data = explode('~', $link->description);
		
		$clicked = (isset($download_count[ $link->term_id ])) ? (int)$download_count[ $link->term_id ] : 0;
		$note = (count($data) == 3) ? $data[2] : $data[3]; // retrocompatibility
		
		echo '
		<tr>
			<td style="padding-right: 0px;"><span class="pcsl_del_field" rel="'.$link->term_id.'"></span></td>
			<td style="text-align: center;">'.$link->term_id.'</td>
			<td><a href="'.$link->name.'" target="_blank" title="'.$link->name.'">'.pcsl_minimize_link($link->name).'</a></td>
			<td>'. pcsl_link_type($link->name) .'</td>
			<td>
				<span class="pcsl_secure_link">'.$sl.'</span>
				<a href="'.$sl.'" target="_blank" title="'. __('test link', 'pcsl_ml') .'"><img src="'.PCSL_URL.'/img/link_icon.png" class="pcls_test_secure" /></a>
			</td>
			<td>'. pcsl_who_can_see($data) .'</td>
			<td>'. pcsl_who_cant_see($data) .'</td>
			<td>'. stripslashes($note) .'</td>
			<td>'. $clicked .' <small>'. __('times', 'pcsl_ml') .'</small></td>
		</tr>
		';	
	}
	
	echo '</tbody></table>';
	
	if($links !== false) {
		echo pcsl_link_paginator($tot, $pag, $per_pag);
	}
	
	die();
}
add_action('wp_ajax_pcsl_links_list', 'pcsl_links_list');





//////////////////////////////////////////////////////////////////////





////////////////////////////////////////////////////////////////
////// SELECT WITH LIST OF CATEGORIES OR ACTIVE USERS //////////
////////////////////////////////////////////////////////////////

function pcsl_subj_list() {
	if (!isset($_POST['pcsl_nonce']) || !wp_verify_nonce($_POST['pcsl_nonce'], 'lcwp_ajax')) {die('Cheating?');};
	include_once(PCSL_DIR . '/functions.php');
	
	if(!isset($_POST['pcsl_subj'])) {die('data is missing');}
	$subj = $_POST['pcsl_subj'];
	$block_vis = ($subj == 'user') ? 'style="display: none;"' : '';

	// who to allow
	$code = '<div class="pcsl_restr_subj_wrap">
		<label>'. __('Allow', 'pcsl_ml') .'</label>';
	
		if($subj == 'user') {
			$code .= '
			<input type="text" id="pcsl_user_search" name="pcsl_user_search" value="" autocomplete="off" placeholder="'. __("search by user's e-mail, username, name, surname", 'pcsl_ml') .'" />
			<input type="hidden" id="pcsl_allow" name="pcsl_allow[]" value="" autocomplete="off" />';	
		}
		else {
			$code .= '
			<select name="pcsl_allow[]" id="pcsl_allow" class="lcweb-chosen" multiple="multiple" autocomplete="off" data-placeholder="'. __('Select an option', 'pcsl_ml') .' ..">
				'. pc_user_cat_dd_opts(array(), true, true, array('unlogged')) .'
			</select>';
		}


	// who to block (if subject is user - just hide the block)
	$code .= '</div><div class="pcsl_restr_subj_wrap" '.$block_vis.'>
		<label>'. __('Block', 'pcsl_ml') .'</label>';
		
		if($subj == 'user') {
			$code .= '<input type="hidden" id="pcsl_block" name="pcsl_block[]" value="" autocomplete="off" />';	
		}
		else {
			$code .= '
			<select name="pcsl_block[]" id="pcsl_block" class="lcweb-chosen" multiple="multiple" autocomplete="off" data-placeholder="'. __('Select an option', 'pcsl_ml') .' ..">
				'. pc_user_cat_dd_opts(array(), false) .'
			</select>';
		}
	
	die($code .'</div>');	
}
add_action('wp_ajax_pcsl_subj_list', 'pcsl_subj_list');





/////////////////////////////////////////////////////
// DYNAMIC USERS SEARCH FOR QUICK MAIL //////////////
/////////////////////////////////////////////////////

function pcsl_users_search() {
	if (!isset($_POST['pcsl_nonce']) || !wp_verify_nonce($_POST['pcsl_nonce'], 'lcwp_ajax')) {die('Cheating?');};;
	global $pc_users;
	
	if(!isset($_POST['pcma_search'])) {
		echo json_encode( array() );
		die();
	}
	$search = trim( $_POST['pcma_search']);
	
	$args = array(
		'limit' => -1,
		'to_get' => array('id', 'username', 'name', 'surname', 'email'),
		'search_operator' 	=> 'OR',
		'search' => array(
			array('key'=>'username', 'operator'=>'LIKE', 'val'=>'%'.$search.'%'),
			array('key'=>'name', 'operator'=>'LIKE', 'val'=>'%'.$search.'%'),
			array('key'=>'surname', 'operator'=>'LIKE', 'val'=>'%'.$search.'%'),
			array('key'=>'email', 'operator'=>'LIKE', 'val'=>'%'.$search.'%')
		),
		'custom_search' => 'AND status = 1 AND email != ""'
	);
	
	$users = $pc_users->get_users($args);
	$to_return = array();
	
	foreach($users as $ud) {
		$nicename = (!empty($ud['name']) && !empty($ud['surname'])) ? trim($ud['name'].' '.$ud['surname']).' ('.$ud['username'].' - '.$ud['email'].')' : $ud['username'] .' - '.$ud['email'];
		$to_return[] = array('id'=>$ud['id'], 'value'=>'', 'label'=>$nicename);	
	}
	
	echo json_encode($to_return);
	die();
}
add_action('wp_ajax_pcsl_users_search', 'pcsl_users_search');




///////////////////////////////////////////////////////////////////////




////////////////////////////////////////////////
////// SHOW LINKS IN THE METABOX ///////////////
////////////////////////////////////////////////

function pcsl_mb_links() {
	if (!isset($_POST['pcsl_nonce']) || !wp_verify_nonce($_POST['pcsl_nonce'], 'lcwp_ajax')) {die('Cheating?');};
	include_once(PCSL_DIR . '/functions.php');
	
	if(!isset($_POST['pcsl_subj'])) {die('data is missing');}
	$links = pcsl_search_links($_POST['pcsl_subj']);
	
	// process links
	if(!is_array($links) || count($links) == 0) {die('<p style="padding-left: 10px;">'.__('No existing links', 'pcsl_ml').' ..</p>');}
	
	echo '
	<table class="widefat pc_table">
      <thead>
        <tr>
		  <th style="width: 15px; padding-right: 0;"></th>
		  <th style="width: 35px; text-align: center;">'.__('ID', 'pcsl_ml').'</th>
		  <th>'.__('Original link', 'pcsl_ml').'</th>
		  <th style="width: 90px;">'.__('Type', 'pcsl_ml').'</th>
		  <th>'.__('Secure link', 'pcsl_ml').'</th>
		  <th>'.__('Blocks', 'pcsl_ml').'</th>
		  <th>'.__('Notes', 'pcsl_ml').'</th>
        </tr>
      </thead>
	  <tbody>';
	
	foreach($links as $link) {
		$sl = pcsl_secure_link($link->slug);
		$data = explode('~', $link->description );

		$note = (count($data) == 3) ? $data[2] : $data[3]; // retrocompatibility
		
		echo '
		<tr>
			<td style="padding-left: 10px; padding-right: 0;"><span class="pcsl_mb_use_link" rel="'.$sl.'" title="'.__('add link to the editor', 'pcsl_ml').'"></span></td>
			<td style="text-align: center;">'.$link->term_id.'</td>
			<td>
				<a href="'.$link->name.'" target="_blank" title="'.$link->name.'">'.pcsl_minimize_link($link->name, 90).'</a>
			</td>
			<td>'. pcsl_link_type($link->name) .'</td>
			<td class="pcsl_secure_link">'. $sl .'</td>
			<td>'. pcsl_who_cant_see($data) .'</td>
			<td>'. stripslashes($note) .'</td>
		</tr>
		';	
	}
	
	echo '</tbody></table>';
	
	die();
}
add_action('wp_ajax_pcsl_mb_links', 'pcsl_mb_links');
