<?php 
include_once(PCSL_DIR . '/functions.php'); 

wp_enqueue_media();
global $pc_users;


// calling from lightbox iframe - hide most elements
if(isset($_GET['pcsl_lb_mode'])) :
?>
<style type="text/css">
#wpadminbar,
#adminmenumain,
#wpfooter,
#pcsl_search_form,
#links_list_wrap,
.pc_page_title,
.wrap > h3 {
	display: none !important;	
}
#wpcontent {
	margin: 0 !important; 	
}
html.wp-toolbar {
	padding-top: 0 !important;	
}
#warning_wrap > * {
	margin-top: 20px !important;	
}
</style>
<?php 
endif;
?>


<style type="text/css">
.ui-autocomplete {
	border-color: #ccc;
    box-shadow: 0 4px 4px rgba(0, 0, 0, 0.15);
    max-height: 200px;
    overflow-x: hidden;
    overflow-y: auto;
}
.ui-autocomplete li {
	border-bottom: 1px solid #ddd;
    padding: 6px;	
}
.ui-autocomplete li:last-child {
	border: none;	
}
input.ui-autocomplete-loading[type="text"] {
	background-image: url('<?php echo PC_URL ?>/img/loader.gif');	
	background-position: 99.5% 3px;
}
</style>


<div class="wrap lcwp_form" style="clear: both;">  
	<div class="icon32" id="icon-pc_user_manage"><br></div>
	<?php echo '<h2 class="pc_page_title">' . __( 'PrivateContent - Secure Links Manager', 'pcsl_ml') . "</h2>"; ?>  

    <div id="warning_wrap"></div>
    
    <form name="pcsl_form" id="pcsl_form" method="post" class="form-wrap" action="<?php echo str_replace( '%7E', '~', $_SERVER['REQUEST_URI']); ?>">  
    
    	<h3 style="margin: 0;"><?php _e('Add new link', 'pcsl_ml') ?></h3>
        <table class="widefat lcwp_table pc_table" style="margin-bottom: 10px;">
          <tr>
            <td class="pc_label_td"><?php _e("Links to encrypt", 'pcsl_ml'); ?><br/>
            <small style="font-size: 12px; font-style: italic;">(<?php _e("one per row, with http prefix", 'pcsl_ml'); ?>)</small>
            </td>
            <td class="pc_field_td">
                <textarea name="pcsl_orig_link" id="pcsl_orig_link" autocomplete="off" style="height:48px;"></textarea>
                
                <button id="pcsl_media_library" type="button" class="button-secondary" title="<?php echo addslashes(__('pick from media library', 'pcsl_ml')) ?>">
                	<span class="dashicons dashicons-admin-media"></span>
                </button>
            </td> 
         </tr>
         <tr class="pcsl_allowance_tr">
            <td class="pc_label_td">
				<label><?php _e("Usable by", 'pcsl_ml'); ?></label>
               
                <select data-placeholder="<?php _e('Select an option', 'pcsl_ml') ?> .." name="pcsl_subj" class="pcsl_subj lcweb-chosen" autocomplete="off" style="max-width: 100%;">
                  <option value="cat"><?php _e('User categories', 'pcsl_ml') ?></option>
                  <option value="user"><?php _e('Single user', 'pcsl_ml') ?></option>
                </select>    
            </td>
            <td class="pcsl_subj_id_wrap"></td> 
         </tr>
         <tr>
            <td class="pc_label_td"><?php _e("Notes <small style='font-size: 12px; font-style: italic;'>(optional)</small>", 'pcsl_ml'); ?></td>
            <td class="pc_field_td">
            	<input type="text" name="pcsl_note" value="" maxlength="150" autocomplete="off" />
            </td> 
         </tr>
        </table> 
        <input type="button" name="pcsl_add_field" id="pcsl_add_link" value="<?php _e('Create Link', 'pcsl_ml') ?>" class="button-primary" style="margin-bottom: 15px;" />
    </form>    
    
          
    <h3><?php _e('Links list', 'pcsl_ml') ?></h3>  
    <form name="pcsl_search_form" id="pcsl_search_form" style="display: none;">
    <table><tr>
    	<td style="width: 100px;"><?php _e('Search links for', 'pcsl_ml') ?></td>
        <td style="width: 220px;">
          <select data-placeholder="<?php _e('Select an option', 'pcsl_ml') ?> .." name="pcsl_src_subj" class="pcsl_subj lcweb-chosen" tabindex="2" style="width: 180px;">
        	<option value="note"><?php _e('Note', 'pcsl_ml') ?></option>
            <option value="orig"><?php _e('Original Link', 'pcsl_ml') ?></option>
            <option value="secure"><?php _e('Secure Link', 'pcsl_ml') ?></option>
        	<option value="id"><?php _e('ID', 'pcsl_ml') ?></option>
          </select>
        </td>
        <td><input type="text" value="" name="pcsl_src_val" id="pcsl_src_val" style="width: 100%;" autocomplete="off" /></td>
        <td style="width: 60px;"><input type="button" value="<?php _e('search', 'pcsl_ml') ?>" class="button-secondary" id="pcsl_src_btn" style="margin: 0 2px 0 4px;" /></td>
        <td style="width: 55px;"><input type="button" value="<?php _e('clear', 'pcsl_ml') ?>" class="button-secondary" id="pcsl_sclear_src" /></td>
        <td id="pcsl_src_result" style="width: 105px;"></td>
    </tr></table>
    </form>
	<div id="links_list_wrap"></div>
</div> 




<?php // SCRIPTS ?>
<?php wp_enqueue_script('jquery-ui-autocomplete'); ?>
<script src="<?php echo PC_URL; ?>/js/chosen/chosen.jquery.min.js" type="text/javascript"></script>

<script type="text/javascript">
jQuery(document).ready(function($) {
	var pcsl_pag = 1; 
	var pcsl_is_adding = 0;
	var pcsl_is_searching = false;
	var pcsl_nonce = '<?php echo wp_create_nonce('lcwp_ajax') ?>';
	
	
	// single user - autocomplete + ajax search
	var user_search_setup = function() {
		jQuery("#pcsl_user_search").autocomplete({
			source: function( request, response ) {
				var data = {
					action: 'pcsl_users_search',
					pcma_search: request.term,
					pcsl_nonce: pcsl_nonce
				};
				jQuery.post(ajaxurl, data, function(resp) {
					response( jQuery.parseJSON(resp) );
				});	
			},
			minLength: 3,
			select: function(event, ui) {
				
				jQuery('#pcsl_allow').val( ui.item.id );
				jQuery(this).val('').hide(); 
				
				
				jQuery(this).before(
					'<h3 style="margin: 0; border: none; padding: 0;">'+
					'<i class="fa fa-times-circle pcsl_del_sel_user" aria-hidden="true" title="<?php echo addslashes(__('cancel selection', 'pcsl_ml')) ?>"></i>'+
					 ui.item.label +'</h3>'
				);
					
					
				return false;
			},
			open: function() {
				jQuery( this ).removeClass( "ui-corner-all" ).addClass( "ui-corner-top" );
			},
			close: function() {
				jQuery( this ).removeClass( "ui-corner-top" ).addClass( "ui-corner-all" );
			}
		});
	};
	
	// remove single user
	jQuery(document.body).delegate('.pcsl_del_sel_user', 'click', function() {
		jQuery(this).parents('h3').remove();
		jQuery("#pcsl_user_search").show();
	});
	
	
	// restriction subject switch
	function pcsl_subj_change(subj) {
		$pcsl_target.html('<div style="height: 20px;" class="lcwp_loading"></div>');
		var data = {
			action: 'pcsl_subj_list',
			pcsl_subj: subj,
			pcsl_nonce: pcsl_nonce
		};
		
		jQuery.post(ajaxurl, data, function(response) {
			$pcsl_target.html(response);	
			
			do_chosen();
			user_search_setup();
		});
	}
	
	// on change
	jQuery('body').delegate('.pcsl_subj', 'change', function() {
		$pcsl_target = jQuery(this).parents('tr').find('.pcsl_subj_id_wrap');
		var pcsl_subj = jQuery(this).val();
		pcsl_subj_change(pcsl_subj);
	});
	
	// on init
	$pcsl_target = jQuery('#pcsl_form .pcsl_subj').parents('tr').find('.pcsl_subj_id_wrap');
	var pcsl_subj = jQuery('#pcsl_form .pcsl_subj').val();
	pcsl_subj_change(pcsl_subj);
	
	
	// all toggles
	jQuery('body').delegate('select#pcsl_allow', 'change', function() {
		var sel = jQuery(this).val();
		if(!sel) {sel = [];}
		
		// if ALL is selected, discard the rest
		if(jQuery.inArray("all", sel) >= 0) {
			jQuery(this).find('option').prop('selected', false);
			jQuery(this).find('.pc_all_field').prop('selected', true);
			
			jQuery(this).trigger("chosen:updated");
		}	
	});
	
	
	///////////////////////////////////////////////////
	
	// add links
	jQuery('body').delegate('#pcsl_add_link', 'click', function() {
		if( jQuery.trim( jQuery('#pcsl_orig_link').val()) != '' && pcsl_is_adding == 0) {
			pcsl_is_adding = 1;
			var fdata = 'action=pcsl_add_link&pcsl_nonce='+ pcsl_nonce +'&' + jQuery('#pcsl_form').serialize();

			jQuery.post(ajaxurl, fdata, function(response) {
				var resp = jQuery.trim(response); 
				pcsl_is_adding = 0;
				
				if(resp == 'success') {
					jQuery('#warning_wrap').empty().append('<div class="updated"><p><strong><?php _e('Link added succesfully!', 'pcsl_ml') ?></strong></p></div>');	
					
					// reset form
					jQuery('#pcsl_form input[type=text], #pcsl_form textarea').val('');
					pcsl_subj_change( jQuery('#pcsl_form .pcsl_subj').val() );
										
					pcsl_pag = 1;
					pcsl_load_links();
					pcsl_hide_wp_alert();
					
					jQuery('#pcsl_src_result').empty();
					jQuery('#pcsl_src_val').text(''); 
				}
				else {
					jQuery('#warning_wrap').empty().append('<div class="error"><p>'+resp+'</p></div>');
				}
			});
		}
	});
	
	
	// delete link
	jQuery('body').delegate('.pcsl_del_field', 'click', function() {
		if(confirm('Delete the link?')) {
			var link_id = jQuery(this).attr('rel');
			$sel_link_wrap = jQuery(this).parents('tr');
			
			var data = {
				action: 'pcsl_del_link',
				link_id: link_id,
				pcsl_nonce: pcsl_nonce
			};
			jQuery.post(ajaxurl, data, function(response) {
				var resp = jQuery.trim(response);
				
				if(resp == 'success') {
					$sel_link_wrap.fadeOut(function() {
						jQuery(this).remove();
					});
				} else {
					alert(response);
				}
			});			
		}
	});
	
	
	//////////////////////////////////////
	
	
	/* links picker from WP media library */
	var pcsl_file_frame = false;
	jQuery(document).delegate('#pcsl_media_library', 'click', function(e) {
		
		// If the media frame already exists, reopen it.
		if(pcsl_file_frame){
		  pcsl_file_frame.open();
		  return;
		}
	
		// Create the media frame
		pcsl_file_frame = wp.media.frames.file_frame = wp.media({
		  title: "Seure Links add-on - <?php echo addslashes(__('link picker', 'gg_ml')) ?>",
		  button: {
			text: "<?php _e('Select', 'pcsl_ml') ?>",
		  },
		  multiple: true
		});
	
		// When an image is selected, run a callback.
		pcsl_file_frame.on('select', function() {
			var data = pcsl_file_frame.state().get('selection').toJSON();
			
			jQuery.each(data, function(i, v) {
				var links = jQuery('#pcsl_orig_link').val();
				var n = (jQuery.trim(links)) ? '\n' : '';
				jQuery('#pcsl_orig_link').val( links + n + v.url);
			});
		});

		pcsl_file_frame.open();
	});
	
	
	
	//////////////////////////////////////
	
	
	// display links list
	function pcsl_load_links() {
		jQuery('#links_list_wrap').html('<div style="height: 35px;" class="lcwp_loading"></div>');
		
		var data = {
			action: 'pcsl_links_list',
			links_page: pcsl_pag,
			pcsl_nonce: pcsl_nonce
		};
		jQuery.post(ajaxurl, data, function(response) {
			jQuery('#links_list_wrap').html(response);
			
			if(jQuery('#links_list_wrap').size() > 0) {
				jQuery('#pcsl_search_form').fadeIn('fast');	
			} else {
				jQuery('#pcsl_search_form').fadeOut('fast');	
			}
		});	
	}
	pcsl_load_links();
	
	
	// change page
	jQuery('body').delegate('.pcsl_navigator a', 'click', function() {
		pcsl_pag = jQuery(this).attr('rel');	
		pcsl_load_links();
	});

	
	// search links
	jQuery('body').delegate('#pcsl_src_btn', 'click', function() {
		var src_val = jQuery('#pcsl_src_val').val();  

		if( jQuery.trim(src_val) && !pcsl_is_searching) {
			jQuery('#links_list_wrap').html('<div style="height: 35px;" class="lcwp_loading"></div>');
			jQuery('#pcsl_src_result').empty();
			pcsl_is_searching = true;
			
			var fdata = 'action=pcsl_search_links&pcsl_nonce='+ pcsl_nonce +'&' + jQuery('#pcsl_search_form').serialize();
			jQuery.post(ajaxurl, fdata, function(response) {
				jQuery('#links_list_wrap').html(response);
				pcsl_is_searching = false;

				var tot_res = jQuery('#links_list_wrap tbody tr').size();
				if(tot_res > 0) {
					jQuery('#pcsl_src_result').html('<strong style="padding-left: 10px;">'+tot_res+' links found</strong>');	
				}
			});
		}
	});
	
	// search with enter submit
	jQuery('#pcsl_src_val').keydown(function(e){
		if(e.keyCode == 13) {
			e.preventDefault();
			jQuery('#pcsl_src_btn').trigger('click');
		}
	});
	
	
	// clear search
	jQuery('body').delegate('#pcsl_sclear_src', 'click', function() {
		var pcsl_pag = 1;
		jQuery('#pcsl_src_val').val(''); 
		jQuery('#pcsl_src_result').val('');
		pcsl_load_links();
	});

	
	//////////////////////////////////////
	
	// auto select secure links
	jQuery('body').delegate('.pcsl_secure_link', 'click', function() {
		if (jQuery('#pcsl_sel_tmp').length) {
			jQuery('#pcsl_sel_tmp').remove();
		}
		var clickText = jQuery(this).text();
		jQuery('<textarea id="pcsl_sel_tmp" />')
			.appendTo(jQuery(this))
			.val(clickText)
			.focus()
			.select();
        return false;
    });
	jQuery(':not(.pcsl_secure_link)').click(function(){
		jQuery('#pcsl_sel_tmp').remove();
	});
	
	// chosen
	function do_chosen() {
		jQuery('.lcweb-chosen').each(function() {
			var w = jQuery(this).css('width');
			jQuery(this).chosen({width: w}); 
		});
		jQuery(".lcweb-chosen-deselect").chosen({allow_single_deselect:true});
	}
	do_chosen();
	
	
	// hide message after 3 sec
	function pcsl_hide_wp_alert() {
		setTimeout(function() {
		 jQuery('#warning_wrap').empty();
		}, 3500);	
	}
});
</script>