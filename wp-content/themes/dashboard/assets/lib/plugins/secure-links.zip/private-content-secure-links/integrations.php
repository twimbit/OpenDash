<?php
// PRIVATECONTENT INTEGRATIONS


///////////////////////////////////////////
/// ADD-ON MENU ///////////////////////////
///////////////////////////////////////////

add_action('pc_addons_menu_ready', 'pcsl_in_pc_menu', 60);

function pcsl_in_pc_menu($slug) {
	add_submenu_page($slug, __('Secure Links Manager', 'pcsl_ml'), __('Secure Links Manager', 'pcsl_ml'), get_option('pg_min_role', 'install_plugins'), 'pcsl_links_manager', 'pcsl_links_manager');	
}
function pcsl_links_manager() { include_once(PCSL_DIR . '/links_manager.php'); }





////////////////////////////////////////////////////
// ADMIN USER DASHBOARD - USER-RELATED LINKS LIST //
////////////////////////////////////////////////////


// new dashboard tab
function pcsl_user_dashboard_tabs($tabs, $user_id) {
	if(!$user_id) {return $tabs;}
	
	return $tabs + array(
		'pcsl' => 'Secure Links add-on'
	);	
}
add_filter('pc_user_dashboard_tabs', 'pcsl_user_dashboard_tabs', 100, 2);



// tab contents
function pcsl_user_dashboard_tab_sections($sections, $user_id) {
	if(!$user_id) {return $sections;}
	
	
	// manage links button
	$btn = '
	<button class="button-secondary pcsl_lightbox_btn" type="button" style="top: -3px;">
		<i class="dashicons dashicons-plus-alt"></i> '. __('Create links', 'pcsl_ml') .'
	</button>';
	
	
	return 
	$sections + array(
		'pcsl_user_links' => array(
			'name'		=> __('User Links') . $btn,
			'classes'	=> '',
			'callback' 	=> 'pcsl_user_dashboard_links'
		)
	);	
}
add_filter('pc_user_dashboard_pcsl_tab_sections', 'pcsl_user_dashboard_tab_sections', 1, 2);



// code (take advantage of the ajax implementation to search links)
function pcsl_user_dashboard_links($user_id) {
	global $wpdb;
	include_once(PCSL_DIR .'/ajax.php');
	include_once(PCSL_DIR . '/functions.php');
	
	// get user links
	$links = pcsl_search_links('user~'.$user_id);
	
	if(empty($links)) {
		echo '<p style="padding: 20px;">'. __('User has no associated links actually', 'pcsl_ml') .' ..</p>';	
	}
	else {
		
		echo '
		<table class="widefat pc_table" style="border: none; margin: 0;">
          <thead>
            <tr>
              <th style="width: 35px; text-align: center;">'.__('ID', 'pcsl_ml').'</th>
              <th>'.__('Original link', 'pcsl_ml').'</th>
              <th style="width: 90px;">'.__('Type', 'pcsl_ml').'</th>
              <th>'.__('Secure link', 'pcsl_ml').'</th>
              <th>'.__('Notes', 'pcsl_ml').'</th>
              <th style="width:50px;">'.__('Clicked', 'pcsl_ml').'</th>
            </tr>
          </thead>
          <tbody>';
        
        
			foreach($links as $link) {
				$sl = pcsl_secure_link($link->slug);
				$data = explode('~', $link->description);
				
				$clicked = (isset($download_count[ $link->term_id ])) ? (int)$download_count[ $link->term_id ] : 0;
				$note = (count($data) == 3) ? $data[2] : $data[3]; // retrocompatibility
				
				echo '
				<tr>
					<td style="text-align: center;">'.$link->term_id.'</td>
					<td><a href="'.$link->name.'" target="_blank" title="'.$link->name.'">'.pcsl_minimize_link($link->name).'</a></td>
					<td>'. pcsl_link_type($link->name) .'</td>
					<td>
						<span class="pcsl_secure_link">'.$sl.'</span>
						<a href="'.$sl.'" target="_blank" title="'. __('test link', 'pcsl_ml') .'">
							<img src="'.PCSL_URL.'/img/link_icon.png" class="pcls_test_secure" />
						</a>
					</td>
					<td>'. stripslashes($note) .'</td>
					<td>'. $clicked .' <small>'. __('times', 'pcsl_ml') .'</small></td>
				</tr>
				';	
			}
		
		echo '
		  </tbody>
		</table>';
		
		
		?>
        <script type="text/javascript">
		jQuery(document).ready(function($) {
			
			// lightbox iframe to manage links
			if(typeof($.magnificPopup) != 'undefined') {
				
				var code = '<div id="pcsl_create_links_iframe" style="display: none;"><div></div>';
					code += '<iframe src="<?php echo admin_url() ?>admin.php?page=pcsl_links_manager&pcsl_lb_mode" />';
				$('body').append(code +'</div>');
				
				$(document).delegate('.pcsl_lightbox_btn', 'click', function() {
					$.magnificPopup.open({
						items : {
							src: '#pcsl_create_links_iframe > *',
							type: 'inline'
						},
						mainClass	: 'pcsl_create_links_lb',
						closeOnContentClick	: false,
						closeOnBgClick		: false, 
						preloader	: false,
						callbacks	: {
						  beforeOpen: function() {
							if($(window).width() < 800) {
							  this.st.focus = false;
							}
						  },
						  close: function() {
							window.location.reload(); 
						  }
						},
					});
					$(document).delegate('.mfp-wrap.pcsl_create_links_lb', 'click', function(e) {
						if($(e.target).hasClass('mfp-container')) {
							$.magnificPopup.close();
						}
					});
				});
				
			}
			else {
				$('.pcsl_lightbox_btn').remove();
			}
		});
		</script>
        <?php
	}
}