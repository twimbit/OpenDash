<?php
////////////////////////////////////////////////
////// LINK TO EDITOR METABOX //////////////////
////////////////////////////////////////////////

add_action('admin_init','pcsl_metabox_init', 100); 
function pcsl_metabox_init() {
	include_once(PC_DIR . '/functions.php');
	
	$types = pc_affected_pt();
	$types[] = 'pg_user_page';
	
	// add a meta box for affected post types
    foreach($types as $type){
		add_meta_box('pcsl_pvtpag_mb', __('PrivateContent - Secure Links', 'pcsl_ml'), 'pcsl_metabox_setup', $type, 'normal', 'high', array('pt' => $type));
	}
}



// create metabox
function pcsl_metabox_setup($post, $metabox) {
	include_once(PC_DIR . '/functions.php');
	include_once(PCSL_DIR . '/functions.php');
	global $post, $pc_users;
	
	// if pvtpage type  - show only user categories
	if($metabox['args']['pt'] == 'pg_user_page') {
		
		$args = array(
			'limit'	=> 1,
			'to_get'=> array('id', 'categories'),
			'search'=> array(
				array('key' => 'page_id', 'operator'=>'=', 'val'=>$post->ID)
			)
		);
		
		$user_data = $pc_users->get_users($args);
		$user_categories = array();

		foreach($user_categories as $cat) {
			if(in_array($cat->term_id, $user_data[0]['categories'])) {
				$user_categories[] = $cat;	
			}
		}
	}
	?>
    
    <div class="lcwp_mainbox_meta pcsl_metabox_wrap">
    	<div>
        	<span class="pcsl_metabox_legend"><?php _e('Show links usable by', 'pcsl_ml') ?></span></td>
        
        	<select data-placeholder="<?php _e('Select a type', 'pcsl_ml') ?> .." name="pcsl_mb_type" id="pcsl_mb_type" class="lcweb-chosen" autocomplete="off">
				<?php 
                if($metabox['args']['pt'] == 'pg_user_page') {
                    echo '<option value="user~'.$user_data[0]['id'].'">'. __('Current PrivateContent user', 'pcsl_ml') .'</option>';	
                }
                
				
				$restr_opts = pc_restr_opts_arr(true, true, array('unlogged'));

				foreach($restr_opts as $name => $opts) {
					foreach($opts['opts'] as $key => $val) {
						if($key != 'all' && is_numeric($key) && isset($user_categories) && !in_array($key, $user_categories)) {continue;}
						echo '<option value="cat~'. $key .'">'. $val .'</option>';					
					}
				}
                ?>
            </select>

			<div class="pcsl_mb_search_btn">
            	<input type="text" name="pcsl_mb_search" id="pcsl_mb_search" placeholder="<?php echo esc_attr( __('search among links data', 'pcsl_ml') ) ?>" autocomplete="off" />
                
                <button class="button-secondary" type="button">
                    <i class="dashicons dashicons-search"></i>
                </button>
			</div>
    
			<button class="button-secondary pcsl_lightbox_btn" type="button">
            	<i class="dashicons dashicons-plus-alt"></i> <?php _e('Create links', 'pcsl_ml') ?>
            </button>
        </div>
        
        <div id="pcsl_mb_links_wrap"></div>
    </div>   
    
    
    <script type="text/javascript">
	jQuery(document).ready(function($) {
		var pcsl_nonce = '<?php echo wp_create_nonce('lcwp_ajax') ?>';
		
		// add link to the editor
		$('body').delegate('.pcsl_mb_use_link', 'click', function() {
			var sec_link = $(this).attr('rel');
			var pcsl_code = '<a href="'+sec_link+'">'+sec_link+'</a>';	
			
			if($('#wp-content-wrap textarea.wp-editor-area').is(':visible')) {
				var pcsl_new_txt  = $('#wp-content-wrap textarea.wp-editor-area').val() + pcsl_code;
				$('#wp-content-wrap textarea.wp-editor-area').val(pcsl_new_txt);	
			} 
			else {
				<?php if( (float)substr(get_bloginfo('version'), 0, 3) < 3.9) : ?>
					tinyMCE.activeEditor.execCommand('mceInsertContent', 0, sc + '][/pc-pvt-content]'); // old WP
				<?php else : ?>
					tinyMCE.activeEditor.execCommand('mceInsertContent', 0, pcsl_code);
				<?php endif; ?>
			}
		});
		
		
		////////////////////////////////
		
		
		// auto select secure links
		$('body').delegate('.pcsl_secure_link', 'click', function() {
			if ($('#pcsl_sel_tmp').length) {
				$('#pcsl_sel_tmp').remove();
			}
			var clickText = $(this).text();
			$('<textarea id="pcsl_sel_tmp" />')
				.appendTo($(this))
				.val(clickText)
				.focus()
				.select();
			return false;
		});
		$(':not(.pcsl_secure_link)').click(function(){
			$('#pcsl_sel_tmp').remove();
		});
		
		
		////////////////////////////////
		
		
		// links search
		$(document).delegate('#pcsl_mb_search', 'keyup', function(e) {
			e.preventDefault();
			
			if($('#pcsl_mb_links_wrap tbody tr').length < 2) {
				return false;	
			}
			
			if(typeof(pcsl_mb_search_keyup) != 'undefined') {clearTimeout(pcsl_mb_search_keyup);}
			pcsl_mb_search_keyup = setTimeout(function() {
				var val = $('#pcsl_mb_search').val();
				var $btn = $('.pcsl_mb_search_btn i');
				
				// reset
				if(!val || val.length < 3) {
					$btn.removeClass('dashicons-no').addClass('dashicons-search');
					
					$('#pcsl_mb_links_wrap tr').show();
					$('#pcsl_mb_no_result').remove();	
				}
				
				// search
				else {
					$btn.removeClass('dashicons-search').addClass('dashicons-no');	
					
					var src_arr = val.toLowerCase().split(' ');
					var matched = 0;
					
					// cyle and check each searched term 
					$('#pcsl_mb_links_wrap tbody tr').each(function() {
						var src_attr = '';
							src_attr += $(this).find('td a').text();
							src_attr += ' '+ $(this).find('td:last-child').text();
							
						var matching = false;
						
						$.each(src_arr, function(i, word) {						
							if( src_attr.toLowerCase().indexOf(word) !== -1 ) {
								matching = true;
								matched++;
								return false;	
							}
						});
						
						if(matching) {
							$(this).show();
						} else {
							$(this).hide();	
						}
					});
					
					if(matched) {
						$('#pcsl_mb_no_result').remove();	
					} else {
						if(!$('#pcsl_mb_no_result').length) {
							$('#pcsl_mb_links_wrap tbody').append("<tr id='pcsl_mb_no_result'><td colspan='6'><?php _e('no links found', 'pcsl_ml') ?> ..</td></tr>");
						}
					}
				}
			}, 150);
		});
		
		// reset search
		$(document).delegate('.pcsl_mb_search_btn button', 'click', function(e) {
			
			if($(this).find('.dashicons-no').length) {
				e.preventDefault();
				$('#pcsl_mb_search').val('');
				$('#pcsl_mb_search').trigger('keyup');
			}
		});
		
		// disable enter submit
		$('#pcsl_mb_search').keydown(function(e){
			if(e.keyCode == 13) {
				e.preventDefault();
				$(this).trigger('keyup');
			}
		});
		

		////////////////////////////////
		
		
		// show secured links
		function pcsl_mb_show_links() {
			$('#pcsl_mb_search').val('');
			
			var pcsl_sel = $('#pcsl_mb_type').val();
			$('#pcsl_mb_links_wrap').html('<div style="height: 30px; margin-left: 20px; margin-bottom: 7px;" class="lcwp_loading"></div>');
			
			var data = {
				action: 'pcsl_mb_links',
				pcsl_subj: pcsl_sel,
				pcsl_nonce: pcsl_nonce
			};
			$.post(ajaxurl, data, function(response) {
				$('#pcsl_mb_links_wrap').html(response);
			}); 
		}
		
		if($('#pcsl_mb_type').length) {
			pcsl_mb_show_links();
		}
		$('body').delegate('#pcsl_mb_type', 'change', function() {
			pcsl_mb_show_links();
		});
		
		
		//////////////////////////////
		
		
		// lightbox iframe to create links
		if(typeof($.magnificPopup) != 'undefined') {
			
			var code = '<div id="pcsl_create_links_iframe" style="display: none;"><div></div>';
				code += '<iframe src="<?php echo admin_url() ?>admin.php?page=pcsl_links_manager&pcsl_lb_mode" />';
			$('body').append(code +'</div>');
			
			$(document).delegate('.pcsl_lightbox_btn', 'click', function() {
				$.magnificPopup.open({
					items : {
						src: '#pcsl_create_links_iframe > *',
						type: 'inline'
					},
					mainClass	: 'pcsl_create_links_lb',
					closeOnContentClick	: false,
					closeOnBgClick		: false, 
					preloader	: false,
					callbacks	: {
					  beforeOpen: function() {
						if($(window).width() < 800) {
						  this.st.focus = false;
						}
					  },
					  close: function() {
						 pcsl_mb_show_links(); 
					  }
					},
				});
				$(document).delegate('.mfp-wrap.pcsl_create_links_lb', 'click', function(e) {
					if($(e.target).hasClass('mfp-container')) {
						$.magnificPopup.close();
					}
				});
			});
			
		}
		else {
			$('.pcsl_lightbox_btn').remove();
		}

		
		//////////////////////////////
		
		
		// live chosen init
		if(typeof($.fn.chosen) != 'undefined') {
			function pcsl_live_chosen() {
				$('.lcweb-chosen').each(function() {
					var w = $(this).css('width');
					$(this).chosen({width: w}); 
				});
				$(".lcweb-chosen-deselect").chosen({allow_single_deselect:true});
			}
			pcsl_live_chosen();
		}
	});
	</script>
    
	<?php
}
