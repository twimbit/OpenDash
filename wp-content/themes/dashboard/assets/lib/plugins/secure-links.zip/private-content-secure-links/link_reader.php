<?php
if(isset($_REQUEST['pcsl'])) {	

	// check permissions
	function pcsl_read_link() {
		$file_id = trim(addslashes($_REQUEST['pcsl']));

		// check the term existance
		$link_data = get_term_by('slug', $file_id, 'pcsl_links');
		if(empty($link_data)) {return false;}
		
		$GLOBALS['pcsl_link_obj'] = $link_data;

		// check for logged users
		if(!pc_user_logged(false)) {
			// check for admin
			return (is_user_logged_in() && PC_WP_USER_PASS) ? $link_data->name : false;
		}
		
		
		// match against allow/block
		$link_arr = explode('~', $link_data->description);
		
		$subj = $link_arr[0];
		$allow = array();
		$block = array();
		
		if(count($link_arr) == 3) { // old structure - only one allowed (retrocompatibility)
			$allow[] = $link_arr[1];
		}
		else {
			$allow = explode(',', str_replace('a_', '', $link_arr[1]));
			$block = explode(',', str_replace('b_', '', $link_arr[2]));		
		}
		

		// check against single user
		if($subj == 'user') {
			return ((int)$allow[0] == $GLOBALS['pc_user_id']) ? $link_data->name : false;
		}
		
		// restriction engine matching
		else {
			return (pc_user_check($allow, $block) === 1) ? $link_data->name : false;
		}
	}
	
	
	// use cURL or standard methods to get the target contents
	function pcsl_get_contents($url) {
		if(in_array('curl', get_loaded_extensions())) {
			 $timeout = 5;
			 $ch = curl_init();
			 curl_setopt($ch, CURLOPT_URL, $url);
			  
			 curl_setopt($ch, CURLOPT_HEADER, false);
			 curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
			 curl_setopt($ch, CURLOPT_RANGE,"0-10000000000");
			  
			 curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			 curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
			 
			 $type = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
			 $data = curl_exec($ch);
			 curl_close($ch); 
			 
			 return $data;
		 }
		 else {
			 $request = wp_remote_get($url);
			 
			 if(wp_remote_retrieve_response_code($request) === 200) {
				return wp_remote_retrieve_body($request);	 
			 }
			 else {die('cannot retrieve file');}
		 }
	}
	
	
	
	// download counter
	function pcsl_download_counter($user_id, $link_object) {
		$link_id = $link_object->term_id;
		
		$data = get_option('pcsl_download_counter', array());
		if(!is_array($data)) {$data = array();}
		
		if(!isset($data[ $link_id ])) {
			$data[$link_id]	= 1;
		}
		else {
			$data[$link_id]	= (int)$data[$link_id] + 1;	
		}
		
		update_option('pcsl_download_counter', $data);
	}
	add_action('pcsl_served_link', 'pcsl_download_counter', 100, 2);
	
	
	
	// Google Analytics event
	function pcsl_analyitics_event($user_id, $link_object) {
		if(isset($GLOBALS['pc_google_analytics'])) {
			$params = array(
				't'		=> 'event',
				'ec'	=> 'Secure Links add-on',
				'ea'	=> 'used_link',
				'el'	=> 'Link #'. $link_object->term_id .' used',
				'ni'	=> 0,
			);
			$GLOBALS['pc_google_analytics']->call($params, $GLOBALS['pc_user_id']);
		}
	}
	add_action('pcsl_served_link', 'pcsl_analyitics_event', 110, 2);
	

	
	// download file or stream image or redirect
	function pcsl_redirect_users() {
		if(is_admin()) {return false;}
		
		include_once(PC_DIR . '/functions.php');
		require_once(PCSL_DIR . '/functions.php');

		$target = pcsl_read_link(); // check permissions
		$home_url = pc_man_redirects('pc_redirect_page');
		if(!$home_url) {$home_url = get_home_url();}

		if($target) {
			if(!isset($type)) {
				$type = pcsl_link_type($target);
			}
			
			// PCSL-ACTION - secured link/contents are gived to a user - passes user ID and link object
			if(pc_user_logged(false)) {
				do_action('pcsl_served_link', $GLOBALS['pc_user_id'], $GLOBALS['pcsl_link_obj']);	
			}
			
			// if is not a permalink or a web page - force download
			if($type != 'web page' && $type != 'permalink')  {
				
				// debug mode
				if(isset($_GET['debug'])) {
					ini_set('display_startup_errors', 1);
					ini_set('display_errors', 1);
					error_reporting(-1);	
				}
				
				
				$link_arr = explode('/', $target);
				$filename = end($link_arr);
				$contents = pcsl_get_contents($target);
				
				
				// headers if not debugging
				if(!isset($_GET['debug'])) {
					header("Cache-Control: public");
					header('Connection: Keep-Alive');
					header("Content-Description: File Transfer");
					header('Content-Type: '.$type );
					header("Content-Length: ". strlen($contents));
					header("Content-Transfer-Encoding: binary");
					header('Accept-Ranges: bytes');
	
					
					// try to stream images - videos - pdf
					if($type == 'application/pdf' || strpos($type, 'image/') !== false || strpos($type, 'video/') !== false) {
						header('Content-Disposition: inline; filename=' . $filename);
					}
					else {
						header("Content-Disposition: attachment; filename=" . $filename);	
					}
				}

				ob_end_clean();
				die($contents);	
			}

			// simple redirect
			else {
				header('location: '.$target);
				die();
			}
		}
		else {
			/*if(get_option('pg_redirect_back_after_login') && pc_curr_url() != '') {
				$_SESSION['pg_last_restricted'] = pc_curr_url();
			}*/
			
			header('location: '.$home_url); 
			die();
		}
	}
	add_action('wp_loaded', 'pcsl_redirect_users', 50);
		
}

