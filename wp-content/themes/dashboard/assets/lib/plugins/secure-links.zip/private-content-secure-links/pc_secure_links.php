<?php
/* 
Plugin Name: PrivateContent - Secure Links Add-on 
Plugin URI: https://lcweb.it/privatecontent/secure-links-add-on
Description: Protect your links taking advantage of the PrivateContent systems. Create secure links accessible by a category or a single user
Author: Luca Montanari
Version: 2.03
Author URI: https://lcweb.it
*/  


/////////////////////////////////////////////
/////// MAIN DEFINES ////////////////////////
/////////////////////////////////////////////

// plugin path
$wp_plugin_dir = substr(plugin_dir_path(__FILE__), 0, -1);
define( 'PCSL_DIR', $wp_plugin_dir );

// plugin url
$wp_plugin_url = substr(plugin_dir_url(__FILE__), 0, -1);
define( 'PCSL_URL', $wp_plugin_url );


// plugin version
define('PCSL_VER', 2.03);



///////////////////////////////////////////////
/////// CHECK IF PRIVATECONTENT IS ACTIVE /////
///////////////////////////////////////////////


include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
if(!is_plugin_active('private-content/private_content.php') && !defined('PC_VERS')) {
	function pcsl_no_plugin_warning() {
		echo '
		<div class="error">
		   <p>'. __('Please activate PrivateContent plugin to use the "Secure Links" add-on', 'pcsl_ml') .'</p>
		</div>';
	}
	add_action('admin_notices', 'pcsl_no_plugin_warning');
}


else {
	
	/////////////////////////////////////////////
	/////// MULTILANGUAGE SUPPORT ///////////////
	/////////////////////////////////////////////
	
	function pcsl_multilanguage() {
	  $param_array = explode(DIRECTORY_SEPARATOR, PCSL_DIR);
	  $folder_name = end($param_array);
	  
	  if(is_admin()) {
		 load_plugin_textdomain( 'pcsl_ml', false, $folder_name . '/languages');  
	  }
	}
	add_action('init', 'pcsl_multilanguage', 1);
	
	
	
	//////////////////////
	
	
	// CUSTOM FORMS TAXONOMY
	add_action( 'init', 'register_taxonomy_pcsl_links' );
	function register_taxonomy_pcsl_links() {
		$labels = array( 
			'name' => __('Links', 'pcsl_ml'),
			'singular_name' => __('Link', 'pcsl_ml'),
			'search_items' => __('Search Links', 'pcsl_ml'),
			'popular_items' => __('Popular Links', 'pcsl_ml'),
			'all_items' => __('All Links', 'pcsl_ml'),
			'parent_item' => __('Parent Link', 'pcsl_ml'),
			'parent_item_colon' => __('Parent Link:', 'pcsl_ml'),
			'edit_item' => __('Edit Link', 'pcsl_ml'),
			'update_item' => __('Update Link', 'pcsl_ml'),
			'add_new_item' => __('Add New Link', 'pcsl_ml'),
			'new_item_name' => __('New Link', 'pcsl_ml'),
			'separate_items_with_commas' => __('Separate grids with commas', 'pcsl_ml'),
			'add_or_remove_items' => __('Add or remove Links', 'pcsl_ml'),
			'choose_from_most_used' => __('Choose from most used Links', 'pcsl_ml'),
			'menu_name' => __('Links', 'pcsl_ml'),
		);
	
		$args = array( 
			'labels' => $labels,
			'public' => false,
			'show_in_nav_menus' => false,
			'show_ui' => false,
			'show_tagcloud' => false,
			'hierarchical' => false,
			'rewrite' => false,
			'query_var' => true
		);
		register_taxonomy('pcsl_links', null, $args);
	}
	
	
	
	////////////////////////////////////////////////////////
	
	
	
	////////////////////////////////////////////////
	// ENQUEUE PCSL STYLE
	function pcsl_style() {
		wp_enqueue_style('pcsl-admin', PCSL_URL .'/css/admin.css');
	}
	add_action('admin_enqueue_scripts', 'pcsl_style');
	
	
	
	////////////////////////////////////////////////////////



	// INTEGRATIONS
	include_once(PCSL_DIR . '/integrations.php');

	// AJAX
	include_once(PCSL_DIR . '/ajax.php');
	
	// SECURE LINK READER
	include_once(PCSL_DIR . '/link_reader.php');
	
	// METABOXES
	include_once(PCSL_DIR . '/metaboxes.php');








	////////////
	// DOCUMENTATION'S LINK
	if(!isset($GLOBALS['is_pc_bundle'])) {
		
		function pcsl_doc_link($links, $file) {
			if($file == plugin_basename(__FILE__)) {	
				$links['lc_doc_link'] = '<a href="https://doc.lcweb.it/pc_secure_links" target="_blank">'. __('Documentation', 'pcsl_ml') .'</a>';
			}
			
			return $links;
		}
		add_filter('plugin_row_meta', 'pcsl_doc_link', 50, 2);
	}
	////////////
	
	


	////////////
	// AUTO UPDATE DELIVER
	if(!isset($GLOBALS['is_pc_bundle'])) {
		include_once(PCSL_DIR . '/classes/lc_plugin_auto_updater.php');
		function pcsl_auto_updates() {
			if(!get_option('pg_no_auto_upd')) {
				$upd = new lc_wp_autoupdate(__FILE__, 'http://updates.lcweb.it', 'lc_updates');
			}
		}
		add_action('admin_init', 'pcsl_auto_updates', 1);
	}
	////////////
}






// REQUIRE LATEST PC
function pcsl_requirements_check() {
	if(!defined('PC_VERS') || PC_VERS < 7.2) {
		
		deactivate_plugins( plugin_basename( __FILE__ ) );
		wp_die('Secure Links add-on '. __('requires at least', 'pcsl_ml') .' PrivateContent v7.2 installed');	
	}
}
register_activation_hook(__FILE__, 'pcsl_requirements_check');
