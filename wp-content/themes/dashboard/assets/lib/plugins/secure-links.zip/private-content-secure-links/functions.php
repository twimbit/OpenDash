<?php
// unique id creator - is the attribute value shown in secured link 
function pcsl_uniqid() {
	return substr(md5( uniqid()), 0, 5) . substr(md5( uniqid()), -5);	
}


// get the final encrypted link
function pcsl_secure_link($link_id) {
	$base = get_home_url();
	if(substr($base, -1) != '/') {$base = $base . '/';} 
	
	return $base . '?pcsl=' . $link_id;
}


// clean the link from http prefix and control the lenght
function pcsl_minimize_link($link, $max_len = 80) {
	$search = array('http://www.', 'https://www.', 'http://', 'https://', 'HTTP://', 'HTTPS://');
	$link = str_replace($search, '', $link);
	
	if(strlen($link) > $max_len) {
		$link = substr($link, 0, $max_len -3) . ' ..';	
	}
	
	return $link;
}


// array of recognized file types
function pcsl_mime_types($prefix = false) {
	$mime_types = array(
		"acx" => "application/internet-property-stream",
		"ai" => "application/postscript",
		"aif" => "audio/x-aiff",
		"aifc" => "audio/x-aiff",
		"aiff" => "audio/x-aiff",
		"asf" => "video/x-ms-asf",
		"asr" => "video/x-ms-asf",
		"asx" => "video/x-ms-asf",
		"au" => "audio/basic",
		"avi" => "video/x-msvideo",
		"axs" => "application/olescript",
		"bas" => "text/plain",
		"bcpio" => "application/x-bcpio",
		"bin" => "application/octet-stream",
		"bmp" => "image/bmp",
		"c" => "text/plain",
		"cat" => "application/vnd.ms-pkiseccat",
		"cdf" => "application/x-cdf",
		"cer" => "application/x-x509-ca-cert",
		"class" => "application/octet-stream",
		"clp" => "application/x-msclip",
		"cmx" => "image/x-cmx",
		"cod" => "image/cis-cod",
		"cpio" => "application/x-cpio",
		"crd" => "application/x-mscardfile",
		"crl" => "application/pkix-crl",
		"crt" => "application/x-x509-ca-cert",
		"csh" => "application/x-csh",
		"css" => "text/css",
		"dcr" => "application/x-director",
		"der" => "application/x-x509-ca-cert",
		"dir" => "application/x-director",
		"dll" => "application/x-msdownload",
		"dms" => "application/octet-stream",
		"doc" => "application/msword",
		"dot" => "application/msword",
		"dvi" => "application/x-dvi",
		"dxr" => "application/x-director",
		"eps" => "application/postscript",
		"etx" => "text/x-setext",
		"evy" => "application/envoy",
		"exe" => "application/octet-stream",
		"fif" => "application/fractals",
		"flr" => "x-world/x-vrml",
		"gif" => "image/gif",
		"gtar" => "application/x-gtar",
		"gz" => "application/x-gzip",
		"h" => "text/plain",
		"hdf" => "application/x-hdf",
		"hlp" => "application/winhlp",
		"hqx" => "application/mac-binhex40",
		"hta" => "application/hta",
		"htc" => "text/x-component",
		"htt" => "text/webviewhtml",
		"ico" => "image/x-icon",
		"ief" => "image/ief",
		"iii" => "application/x-iphone",
		"ins" => "application/x-internet-signup",
		"isp" => "application/x-internet-signup",
		"jfif" => "image/pipeg",
		"jpe" => "image/jpeg",
		"jpeg" => "image/jpeg",
		"jpg" => "image/jpeg",
		"js" => "application/x-javascript",
		"latex" => "application/x-latex",
		"lha" => "application/octet-stream",
		"lsf" => "video/x-la-asf",
		"lsx" => "video/x-la-asf",
		"lzh" => "application/octet-stream",
		"m13" => "application/x-msmediaview",
		"m14" => "application/x-msmediaview",
		"m3u" => "audio/x-mpegurl",
		"man" => "application/x-troff-man",
		"mdb" => "application/x-msaccess",
		"me" => "application/x-troff-me",
		"mht" => "message/rfc822",
		"mhtml" => "message/rfc822",
		"mid" => "audio/mid",
		"mny" => "application/x-msmoney",
		"mov" => "video/quicktime",
		"movie" => "video/x-sgi-movie",
		"mp2" => "video/mpeg",
		"mp3" => "audio/mpeg",
		"mp4" => "video/mp4",
		"mpa" => "video/mpeg",
		"mpe" => "video/mpeg",
		"mpeg" => "video/mpeg",
		"mpg" => "video/mpeg",
		"mpp" => "application/vnd.ms-project",
		"mpv2" => "video/mpeg",
		"ms" => "application/x-troff-ms",
		"mvb" => "application/x-msmediaview",
		"nws" => "message/rfc822",
		"oda" => "application/oda",
		"p10" => "application/pkcs10",
		"p12" => "application/x-pkcs12",
		"p7b" => "application/x-pkcs7-certificates",
		"p7c" => "application/x-pkcs7-mime",
		"p7m" => "application/x-pkcs7-mime",
		"p7r" => "application/x-pkcs7-certreqresp",
		"p7s" => "application/x-pkcs7-signature",
		"pbm" => "image/x-portable-bitmap",
		"pdf" => "application/pdf",
		"pfx" => "application/x-pkcs12",
		"pgm" => "image/x-portable-graymap",
		"pko" => "application/ynd.ms-pkipko",
		"pma" => "application/x-perfmon",
		"pmc" => "application/x-perfmon",
		"pml" => "application/x-perfmon",
		"pmr" => "application/x-perfmon",
		"pmw" => "application/x-perfmon",
		"png" => "image/png",
		"pnm" => "image/x-portable-anymap",
		"pot" => "application/vnd.ms-powerpoint",
		"ppm" => "image/x-portable-pixmap",
		"pps" => "application/vnd.ms-powerpoint",
		"ppt" => "application/vnd.ms-powerpoint",
		"prf" => "application/pics-rules",
		"ps" => "application/postscript",
		"pub" => "application/x-mspublisher",
		"qt" => "video/quicktime",
		"ra" => "audio/x-pn-realaudio",
		"ram" => "audio/x-pn-realaudio",
		"ras" => "image/x-cmu-raster",
		"rgb" => "image/x-rgb",
		"rmi" => "audio/mid",
		"roff" => "application/x-troff",
		"rtf" => "application/rtf",
		"rtx" => "text/richtext",
		"scd" => "application/x-msschedule",
		"sct" => "text/scriptlet",
		"setpay" => "application/set-payment-initiation",
		"setreg" => "application/set-registration-initiation",
		"sh" => "application/x-sh",
		"shar" => "application/x-shar",
		"sit" => "application/x-stuffit",
		"snd" => "audio/basic",
		"spc" => "application/x-pkcs7-certificates",
		"spl" => "application/futuresplash",
		"src" => "application/x-wais-source",
		"sst" => "application/vnd.ms-pkicertstore",
		"stl" => "application/vnd.ms-pkistl",
		"stm" => "text/html",
		"svg" => "image/svg+xml",
		"t" => "application/x-troff",
		"tar" => "application/x-tar",
		"tcl" => "application/x-tcl",
		"tex" => "application/x-tex",
		"texi" => "application/x-texinfo",
		"texinfo" => "application/x-texinfo",
		"tgz" => "application/x-compressed",
		"tif" => "image/tiff",
		"tiff" => "image/tiff",
		"tr" => "application/x-troff",
		"trm" => "application/x-msterminal",
		"tsv" => "text/tab-separated-values",
		"txt" => "text/plain",
		"uls" => "text/iuls",
		"ustar" => "application/x-ustar",
		"vcf" => "text/x-vcard",
		"vrml" => "x-world/x-vrml",
		"wav" => "audio/x-wav",
		"wcm" => "application/vnd.ms-works",
		"wdb" => "application/vnd.ms-works",
		"wks" => "application/vnd.ms-works",
		"wmf" => "application/x-msmetafile",
		"wps" => "application/vnd.ms-works",
		"wri" => "application/x-mswrite",
		"wrl" => "x-world/x-vrml",
		"wrz" => "x-world/x-vrml",
		"xaf" => "x-world/x-vrml",
		"xbm" => "image/x-xbitmap",
		"xla" => "application/vnd.ms-excel",
		"xlc" => "application/vnd.ms-excel",
		"xlm" => "application/vnd.ms-excel",
		"xls" => "application/vnd.ms-excel",
		"xlt" => "application/vnd.ms-excel",
		"xlw" => "application/vnd.ms-excel",
		"xof" => "x-world/x-vrml",
		"xpm" => "image/x-xpixmap",
		"xwd" => "image/x-xwindowdump",
		"z" => "application/x-compress",
		"zip" => "application/zip"
	);
	
	if($prefix !== false) {	
		(isset($mime_types[$prefix])) ? $mime = $mime_types[$prefix] : $mime = false;
		return $mime; 
	}
	else {return $mime_types;}	
}


// get the link type
function pcsl_link_type($link) {
	$link = strtolower($link);
	
	if(strrpos($link, ".") === false) {return 'permalink';} 
	else {

		if(strpos($link, '#') !== false) {
			$arr = explode('#', $link);
			$link = $arr[0];				
		}
		
		if(strpos($link, '?') !== false) {
			$arr = explode('?', $link);
			$link = $arr[0];				
		}
		
		//////
		
		$arr = explode('.', $link);
		$extension = end($arr);
		$extensions = pcsl_mime_types();
		
		return (isset($extensions[ $extension ])) ? $extensions[ $extension ] : 'web page';
	}
}


// links list
function pcsl_get_links($per_page, $page = 1) {
	if($per_page != 'all') {$offset = $per_page * ($page - 1);}
	else {$offset = 0;}
	
	$args = array(
		'orderby'       => 'id', 
		'order'         => 'DESC',
		'hide_empty'    => false, 
		'number'        => $per_page, 
		'offset'        => $offset
	); 
	
	return get_terms('pcsl_links', $args);
}


//////////////////////////////////////////////////////


// return a string of allowed user categories or allowed username
function pcsl_who_can_see($data) {
	$allowed = array();

	// normalize caring to retrocompatibility
	$to_allow = explode(',', $data[1]);
	foreach($to_allow as $ta) {
		$allowed[] = (substr($ta, 0, 2) == 'a_') ? substr($ta, 2) : $ta;	
	}
	
	if($data[0] == 'user') {
		global $wpdb, $pc_users;
		$wcs = 'User - ';
		
		$username = $pc_users->get_user_field($allowed[0], 'username');	
		$wcs .= (empty($username)) ? '('.__('user not found', 'pcsl_ml').')' : $username;   
	}
	else {
		global $pc_restr_wizard;
		$wcs = $pc_restr_wizard->restr_arr_to_string($allowed);
	}
	
	return $wcs;
}


// return a string of blocked user categories
function pcsl_who_cant_see($data) {
	$to_block = (count($data) == 4) ? $data[2] : array(); // retrocompatibility
	if(empty($to_block)) {return '';}
	
	$to_block = explode(',', $to_block);
	$blocked = array();
	
	// normalize
	foreach($to_block as $tb) {
		$blocked[] = substr($tb, 2);	
	}
	
	global $pc_restr_wizard;	
	return $pc_restr_wizard->restr_arr_to_string($blocked);
}


//////////////////////////////////////////////////////



// link paginator
function pcsl_link_paginator($tot, $curr_pag, $per_pag = 20) {
	$wp_style_class = 'tablenav-pages-navspan button';
	
	$num_pags = ceil($tot / $per_pag);
	if($curr_pag > $num_pags) {$curr_pag = $num_pags;}
	
	$from_link_num = $per_pag * ($curr_pag - 1);
	$to_link_from = $from_link_num + $per_pag;
	
	if($tot < $to_link_from) {$to_link_from = $tot;}
	
	// display the current starting link num
	$from_link_num = $from_link_num + 1;
	
	$pc_list = ' 
	<div class="tablenav pcsl_navigator">
		<div style="padding-right: 20px;">'.__('links', 'pcsl_ml').' '.$from_link_num.'-'.$to_link_from.' '.__('out of', 'pcsl_ml').' '.$tot.'</div>
		<div class="tablenav-pages tablenav-pages pagination-links">';
		
			/////////////////////////////////////////////////////
			// if in the first 10 pages
			if($curr_pag <= 6) {
				for($a=1; $a < 10; $a++) {
					if($a > $num_pags) {break;}
					
					if($curr_pag == $a) {$pc_list .='<a id="curr_pag" class="'. $wp_style_class .'" rel="'.$a.'">'.$a.'</a>';}
					else {$pc_list .='<a rel="'.$a.'" class="'. $wp_style_class .'">'.$a.'</a>';}
				}
				
				// if more than 10, print the last page
				if($num_pags > 10) {$pc_list .=' .. <a rel="'.$tot.'" class="'. $wp_style_class .'">'.$tot.'</a>';}
			}
			
			/////////////////////////////////////////////////////////
			// in is in the last 10 pages
			elseif($num_pags > 10 && $curr_pag <= $num_pags && $curr_pag >= ($num_pags - 6)) {
				$lp_start = $num_pags - 8;
				
				// first page link
				$pc_list .='<a rel="1" class="'. $wp_style_class .'">1</a> .. ';
				
				for($a=$lp_start; $a <= $num_pags; $a++) {
					if($curr_pag == $a) {$pc_list .='<a id="curr_pag" class="'. $wp_style_class .'" rel="'.$a.'">'.$a.'</a>';}
					else {$pc_list .='<a class="'. $wp_style_class .'" rel="'.$a.'">'.$a.'</a>';}
				}
			}
				
			/////////////////////////////////////////////////////////
			// otherwise, the 6 pages around the current one 
			else {	
				$lp_start = $curr_pag - 3;
				$lp_end = $curr_pag + 8;
				
				// first page link
				$pc_list .='<a rel="1" class="'. $wp_style_class .'">1</a> .. ';
				
				for($a=$lp_start; $a <= $lp_end; $a++) {
					if($curr_pag == $a) {$pc_list .='<a id="curr_pag" class="'. $wp_style_class .'" rel="'.$a.'">'.$a.'</a>';}
					else {$pc_list .='<a rel="'.$a.'" class="'. $wp_style_class .'">'.$a.'</a>';}
				}
				
				// stampo l'ultimo link che porta all'ultima pagina se le pagine son più di 10
				$pc_list .=' .. <a rel="'.$num_pags.'" class="'. $wp_style_class .'">'.$num_pags.'</a>';
			}

			return $pc_list . '
		</div>
	</div>';	
}
