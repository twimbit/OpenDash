<?php

/**
 * Element Controls
 */
 

/* FIELDS */
$fields =  array(
	'redirect' => array(
		'type'    => 'text',
		'ui' => array(
			'title'   => __('Custom Redirect', 'gg_ml'),
			'tooltip' => __('Set a custom redirect after logout - use a full page URL', 'pc_ml'),
		),
	),
);

return $fields;
