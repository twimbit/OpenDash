<?php

/**
 * Defaults Values
 */

return array(
	'allow' 	=> array('all'),
	'block'		=> array(),
	'warning'	=> '0',
	'message'	=> ''
);