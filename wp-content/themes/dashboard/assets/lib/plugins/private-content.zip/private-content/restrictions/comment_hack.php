<?php
// empty page to override comments template - checks comments restriction parameter

if(get_option('pg_hc_warning') && isset($GLOBALS['pc_restricted_comm_result']) && !isset($GLOBALS['pc_cr_warning_shown']) && !isset($GLOBALS['pc_pag_contents_hidden'])) {
	include_once(PC_DIR .'/functions.php');
	
	$rcr = $GLOBALS['pc_restricted_comm_result'];
	$rcm = $GLOBALS['pc_restricted_comm_matching'];
	
	$key = ($rcr['check_result'] === 2) ? 'pc_default_hcwp_mex' : 'pc_default_hc_mex'; 
	$txt = pc_get_message($key);

	echo do_shortcode('[pc-pvt-content allow="'. implode(',', (array)$rcm['allow']) .'" block="'. implode(',', (array)$rcm['block']) .'" message="'. addslashes($txt) .'" warning="1"][/pc-pvt-content]');
}
