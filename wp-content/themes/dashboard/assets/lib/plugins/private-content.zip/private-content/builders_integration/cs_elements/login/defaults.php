<?php

/**
 * Defaults Values
 */

return array(
	'redirect' 	=> ''
);