<?php

/**
 * Defaults Values
 */

return array(
	'fid' => '', // fake index to not conflict with CS
	'layout' => '',
	'custom_categories' => array(),
	'redirect' => ''
);