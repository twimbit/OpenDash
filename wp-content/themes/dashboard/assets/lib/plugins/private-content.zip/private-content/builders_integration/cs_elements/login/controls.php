<?php

/**
 * Element Controls
 */
 

/* FIELDS */
$fields =  array(
	'redirect' => array(
		'type'    => 'text',
		'ui' => array(
			'title'   => __('Custom Redirect', 'gg_ml'),
			'tooltip' => __('Set a custom redirect after login - use a full page URL', 'pc_ml'),
		),
	),
	'align' => array(
		'type'    => 'select',
		'ui' => array(
			'title'   => __('Alignment', 'pc_ml'),
			'tooltip' => '',
		),
		'options' => array(
			'choices' => array(
				array('value' => 'center', 	'label' => __('Center', 'pc_ml')),
				array('value' => 'left', 	'label' => __('Left', 'pc_ml')),
				array('value' => 'right',	'label' => __('Right', 'pc_ml')),
			)
		)
	),
);

return $fields;
