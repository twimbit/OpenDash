<?php

/**
 * Element Controls
 */
 

/* FIELDS */
$fields =  array(
	'allow' => array(
		'type'    => 'multi-choose',
		'ui' => array(
			'title'   => __('Who can see contents?', 'pc_ml'),
			'tooltip' => '',
		),
		'options' => array(
			'choices' => pc_cs_uc_array()
		),
	),
	
	'block' => array(
		'type'    => 'multi-choose',
		'ui' => array(
			'title'   => __('Who to block? (optional)', 'pc_ml'),
			'tooltip' => '',
		),
		'options' => array(
			'choices' => pc_cs_uc_array(false)
		),
	),
	
	'warning' => array(
		'type'    => 'toggle',
		'ui' => array(
			'title'   => __('Show warning box?', 'pc_ml'),
			'tooltip' => __('Check to display a yellow warning box', 'pc_ml'),
		),
	),
	
	'message' => array(
		'type'    => 'text',
		'ui' => array(
			'title'   => __('Custom message for not allowed users', 'pc_ml'),
		),
	),
	
	'content' => array(
		'type'    => 'editor',
		'ui' => array(
			'title'   => __("Contents", "pc_ml"),
			'tooltip' => '',
		),
		'context' => 'content',
		'suggest' => ''
    ),
);



return $fields;
