<?php
// PRIVATECONTENT INTEGRATIONS - SHOTRCODES


add_filter('pc_tinymce_tabs', 'pcud_tinymce_tabs');

function pcud_tinymce_tabs($tabs) {
	include_once(PCUD_DIR .'/functions.php');
	include_once(PC_DIR .'/classes/pc_form_framework.php');
	$f_fw = new pc_form;
	
	// get forms
	$forms = get_terms('pcud_forms', 'hide_empty=0');
	$form_fields = $f_fw->fields;	
	
	
	
	/* User data shortcode */
	$contents = '
	<ul>
		<li class="lcwp_scw_field pc_scw_field">
			<label>'. __('User data to display', 'pcud_ml') .'</label>
	
			<select name="pcud_fields_list" id="pcud_fields_list" class="lcweb-chosen f_type" data-placeholder="'. __('Select field', 'pcud_ml') .' .." autocomplete="off">
				<option value="username">'. __('username', 'pcud_ml') .'</option>';
			
			  foreach($form_fields as $field_id => $data) {
				  if(!in_array($field_id, pcud_wizards_ignore_fields(true))) {
					  $contents .= '<option value="'.$field_id.'">'.$data['label'].'</option>';
				  }
			  }		
	
    $contents .= '		  
    		</select>
		</li>
		<li class="lcwp_scw_field pc_scw_field">
			<input type="button" id="pcud-user-data-submit" class="button-primary" value="'. __('Insert', 'pcud_ml') .'" name="submit" />
		</li>
	';
	$tabs['pcud_user_data'] = array(
		'name' 		=> 'PCUD - '. __("User's Data", 'pcud_ml'),
		'contents'	=> $contents .'</ul>'
	);
	



	/* Custom form */
	$contents = '
	<ul>
		<li class="lcwp_scw_field pc_scw_field">
			<label>'. __('Form to display', 'pcud_ml') .'</label>
	
			<select name="pcud_form_list" id="pcud_forms_list" class="lcweb-chosen f_type" data-placeholder="'. __('Select form', 'pcud_ml') .' .." autocomplete="off">';
			
			  foreach ($forms as $form) {
				  $contents .= '<option value="'.$form->term_id.'">'.$form->name.'</option>';
			  }
	
    $contents .= '		  
    		</select>
		</li>
		<li class="lcwp_scw_field pc_scw_field">
			<label>'. __('Layout', 'pcud_ml') .'</label>
	
			<select name="pcud_form_layout" id="pcud_forms_layout" class="lcweb-chosen f_type" data-placeholder="'. __('Select an option', 'pcud_ml') .' .." autocomplete="off">
				<option value="" selected="selected">'. __('Default one', 'pcud_ml') .'</option>
				<option value="one_col">'. __('Single column', 'pcud_ml') .'</option>
				<option value="fluid">'. __('Fluid (multi column)', 'pcud_ml') .'</option>
			</select>
		</li>
		<li class="lcwp_scw_field pc_scw_field">
			<label>'. __('Form alignment', 'pcud_ml') .'</label>
			<select name="pcud_forms_align" id="pcud_forms_align" class="lcweb-chosen" data-placeholder="'. __('Select an option', 'pcud_ml') .' .." autocomplete="off">
				<option value="center" selected="selected">'. __('Center', 'pc_ml') .'</option>
				<option value="left">'. __('Left', 'pc_ml') .'</option>
				<option value="right">'. __('Right', 'pc_ml') .'</option>
			</select>
		</li>	
		<li class="lcwp_scw_field pc_scw_field">
			<input type="button" id="pcud-form-submit" class="button-primary" value="'. __('Insert Form', 'pcud_ml') .'" name="submit" />
		</li>
	';
	$tabs['pcud_cust_form'] = array(
		'name' 		=> 'PCUD - '. __("Custom Form", 'pcud_ml'),
		'contents'	=> $contents .'</ul>'
	);




	/* Conditional block */
	$contents = '
	<ul>
		<li class="lcwp_scw_field pc_scw_field">
			<label>'. __('Show content when', 'pcud_ml') .'</label>
	
			<select name="pcud_cb_field" id="pcud_cb_field" class="lcweb-chosen f_type" data-placeholder="'. __('Select field', 'pcud_ml') .' .." autocomplete="off">';
			
			foreach($form_fields as $field_id => $data) {
				if(!in_array($field_id, pcud_wizards_ignore_fields())) {
					$contents .= '<option value="'.$field_id.'">'.$data['label'].'</option>';
				}
			}
	
    $contents .= '		  
    		</select>
		</li>
		<li class="lcwp_scw_field pc_scw_field">
			<select name="pcud_cb_condition" id="pcud_cb_condition" autocomplete="off" style="width: 24%;">
				<option value="=" >'. __('is equal to', 'pcud_ml') .'</option>
				<option value="!=" >'. __('is different from', 'pcud_ml') .'</option>	
				<option value="big" >'. __('is greater than', 'pcud_ml') .'</option>	
				<option value="small" >'. __('is lower than', 'pcud_ml') .'</option>
				<option value="like">'. __('contains', 'pcud_ml') .'</option>		
			</select>
			
            <input type="text" name="pcud_cb_val" id="pcud_cb_val" value="" autocomplete="off" style="float: right; max-width: 74%; position: relative;" />
		</li>	
		<li class="lcwp_scw_field pc_scw_field">
			<input type="button" id="pcud_cb_submit" class="button-primary" value="'. __('Insert Block', 'pcud_ml') .'" name="submit" />
		</li>
	';
	$tabs['pcud_cond_block'] = array(
		'name' 		=> 'PCUD - '. __("Conditional Block", 'pcud_ml'),
		'contents'	=> $contents .'</ul>'
	);


	$GLOBALS['pcud_print_tinymce_js'] = true;
	return $tabs;
}




// add javascript code in footer
add_action('admin_footer', 'pcud_tinymce_js');
function pcud_tinymce_js() {
	if(!isset($GLOBALS['pcud_print_tinymce_js']));	
	
	?>
	<script type="text/javascript">
	jQuery(document).ready(function(e) {
		
		// [pcud-user-data] 
		jQuery(document).delegate("#pcud-user-data-submit", "click", function() {
			var fid = jQuery("#pcud_fields_list").val();
			
			if(fid != "") {
				var shortcode = '[pcud-user-data f="'+fid+'"]';
				tinyMCE.activeEditor.execCommand("mceInsertContent", 0, shortcode);
				jQuery.magnificPopup.close();
			}
		});
		
		// [pcud-form] 
		jQuery(document).delegate("#pcud-form-submit", "click", function() {
			var fid = jQuery("#pcud_forms_list").val();
			
			if(fid) {
				var sc = '[pcud-form form="'+fid+'"';
				
				// layout
				if(jQuery('#pcud_forms_layout').val()) {
					sc += ' layout="'+ jQuery('#pcud_forms_layout').val() +'"';	
				}
				
				// alignment
				if(jQuery('#pcud_forms_align').val() != 'center') {
					sc += ' align="'+ jQuery('#pcud_forms_align').val() +'"';	
				}
				
				var shortcode = sc +']';
				tinyMCE.activeEditor.execCommand("mceInsertContent", 0, shortcode);
				jQuery.magnificPopup.close();	
			}
		});
		
		// [pcud-cond-block] 
		jQuery(document).delegate("#pcud_cb_submit", "click", function() {
			var fid = jQuery("#pcud_cb_field").val();
			var cond = jQuery("#pcud_cb_condition").val();
			var val = jQuery("#pcud_cb_val").val(); 
			val = val.replace(/"/g, '&quot;');
			
			if(fid != "") {
				var shortcode = '[pcud-cond-block f="'+ fid +'" cond="'+ cond +'" val="'+ val +'"][/pcud-cond-block]';
				tinyMCE.activeEditor.execCommand("mceInsertContent", 0, shortcode);
				jQuery.magnificPopup.close();	
			}
		});
	});
	</script>
    <?php
}

