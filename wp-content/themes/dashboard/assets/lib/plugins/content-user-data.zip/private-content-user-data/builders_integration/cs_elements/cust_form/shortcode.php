<?php

/**
 * Shortcode handler
 */

if(!isset($id)) 		{$id = '';}
if(!isset($class)) 		{$class = '';}
if(!isset($style)) 		{$style = '';}

cs_atts( array('id' => $id, 'class' => $class, 'style' => $style ) );

$atts = array(
	'form' 		=> $form,
	'layout' 	=> $layout,
);

$params = '';
foreach($atts as $key => $val) {
	$params .= ' '. $key .'="'. esc_attr($val) .'"';
}

echo do_shortcode('[pcud-form '. $params .']');
