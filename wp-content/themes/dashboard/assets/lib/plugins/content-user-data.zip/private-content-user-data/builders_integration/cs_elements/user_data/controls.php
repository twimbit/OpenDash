<?php

/**
 * Element Controls
 */
 

/* FIELDS */
$fields =  array(
	'f' => array(
		'type'    => 'select',
		'ui' => array(
			'title'   => __('User data to display', 'pcud_ml'),
			'tooltip' => '',
		),
		'options' => array(
			'choices' => pcud_cs_fl_array(true)
		),
	),
);

return $fields;
