<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if(!defined('ABSPATH')) exit;



class pcud_user_data_on_elementor extends Widget_Base {
	
	 public function get_icon() {
      return 'emtr_lcweb_icon';
   }
	
	public function get_name() {
		return 'pcud-user-data';
	}

	public function get_categories() {
		return array('privatecontent');
	}

   public function get_title() {
      return 'PCUD - '. __('User Data', 'pc_ml');
   }



   protected function _register_controls() {

		// get user fields
		include_once(PC_DIR .'/classes/pc_form_framework.php');
		include_once(PCUD_DIR .'/functions.php');
		
		register_taxonomy_pcud_fields();
		$f_fw = new pc_form;
		
		$user_fields = array( __('Choose a field ..', 'pcud_ml') => ' ');
		foreach($f_fw->fields as $field_id => $data) {
			if($field_id == 'username' || !in_array($field_id, pcud_wizards_ignore_fields(true))) {
				$user_fields[ $field_id ] = $data['label'];
			}
		}

		
		//////////////////////
	

		$this->start_controls_section(
			'main',
			array(
				'label' => __('Main Parameters', 'pcud_ml'),
			)
		);
  
		$this->add_control(
		   'f',
		   array(
			  'label' 	=> __('User data to display', 'pcud_ml'),
			  'type' 	=> Controls_Manager::SELECT,
			  'default' => current(array_keys( $user_fields )),
			  'options' => $user_fields
		   )
		);
		
			
		$this->end_controls_section();
   }


	
	////////////////////////



	protected function render() {
     	$vals = $this->get_settings();
		//var_dump($vals);

		$parts = array('f');
		$params = '';
		
		foreach($parts as $part) {
			$params .= $part.'="';
			
			if(!isset($vals[$part])) {$vals[$part] = '';}
			$params .= $vals[$part].'" ';	
		}
		
		echo do_shortcode('[pcud-user-data '. $params .']');
	}


	protected function _content_template() {}
}
