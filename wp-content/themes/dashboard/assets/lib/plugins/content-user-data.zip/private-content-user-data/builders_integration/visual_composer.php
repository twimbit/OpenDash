<?php
//  visual composer integration


// user fields array builder for VC
function pcud_vc_fl_array($use_cat = false) {
	include_once(PC_DIR .'/classes/pc_form_framework.php');
	include_once(PCUD_DIR .'/functions.php');
	
	register_taxonomy_pcud_fields();
	$f_fw = new pc_form;
	
	$arr = array( __('Choose a field ..', 'pcud_ml') => ' ');
	foreach($f_fw->fields as $field_id => $data) {
		if($field_id == 'username' || !in_array($field_id, pcud_wizards_ignore_fields($use_cat))) {
			$arr[ $data['label'] ] = $field_id;
		}
	}
	
	return $arr;
}



function pcud_on_visual_composer() {
    register_taxonomy_pcud_forms(); // be sure tax are registered
	
	
	#########################################
	######## USER DATA ######################
	#########################################
	
	// parameters
	$params = array(
		array(
			'type' 			=> 'dropdown',
			'heading' 		=> __('User data to display', 'pcud_ml'),
			'param_name' 	=> 'f',
			'admin_label' 	=> true,
			'value' 		=> pcud_vc_fl_array(true),
		),
	);
	
	// compile
	vc_map(
        array(
            'name' 			=> 'PCUD - '. __('User Data', 'pc_ml'),
			'description'	=> __("Displays PrivateContent user data", 'pcud_ml'),
            'base' 			=> 'pcud-user-data',
            'category' 		=> "PrivateContent",
			'icon'			=> PCUD_URL .'/img/vc_icon.png',
            'params' 		=> $params,
        )
    );
	
	
	
	
	
	#########################################
	####### CUSTOM FORM #####################
	#########################################
	
	$form_arr = array();
	$forms = get_terms('pcud_forms', 'hide_empty=0');
	
	foreach($forms as $form) {
		$form_arr[ $form->name ] = $form->term_id;	
	}
	
	// parameters
	$params = array(
		array(
			'type' 			=> 'dropdown',
			'heading' 		=> __('Custom form to use', 'pcud_ml'),
			'param_name' 	=> 'form',
			'admin_label' 	=> true,
			'value' 		=> $form_arr,
		),
		array(
			'type' 			=> 'dropdown',
			'heading' 		=> __('Layout', 'pcud_ml'),
			'param_name' 	=> 'layout',
			'admin_label' 	=> true,
			'value' 		=> array(
				__('Default one', 'pcud_ml') => '',
				__('Single column', 'pcud_ml') => 'one_col',
				__('Fluid (multi column)', 'pcud_ml') => 'fluid',
			),
		),
		array(
			'type' 			=> 'dropdown',
			'heading' 		=> __('Alignment', 'pcud_ml'),
			'param_name' 	=> 'align',
			'admin_label' 	=> true,
			'value' 		=> array(
				__('Center', 'pcud_ml') 	=> 'center',
				__('Left', 'pcud_ml') 	=> 'left',
				__('Right', 'pcud_ml') 	=> 'right',
			),
		),
	);
		
	// compile
	vc_map(
        array(
            'name' 			=> 'PCUD - '. __('Custom Form', 'pcud_ml'),
			'description'	=> __("Displays User Data add-on custom form", 'pcud_ml'),
            'base' 			=> 'pcud-form',
            'category' 		=> "PrivateContent",
			'icon'			=> PCUD_URL .'/img/vc_icon.png',
			'admin_enqueue_css'	 => PCUD_URL .'/css/vc_fix.css',
            'params' 		=> $params,
        )
    );
	
	
	

	#########################################
	####### CONDITIONAL BLOCK ###############
	#########################################
	
	// parameters
	$params = array(
		array(
			'type' 			=> 'dropdown',
			'heading' 		=> __('Field to match', 'pcud_ml'),
			'param_name' 	=> 'f',
			'admin_label' 	=> true,
			'value' 		=> pcud_vc_fl_array(),
		),
		array(
			'type' 			=> 'dropdown',
			'heading' 		=> __('Define condition', 'pcud_ml'),
			'param_name' 	=> 'cond',
			'admin_label' 	=> true,
			'value' 		=> array(
				__('is equal to', 'pcud_ml') 		=> '=',
				__('is different from', 'pcud_ml')	=> '!=',
				__('is greater than', 'pcud_ml')	=> 'big',
				__('is lower than', 'pcud_ml')		=> 'small',
				__('contains', 'pcud_ml')			=> 'like'
			),
		),
		array(
			'type' 			=> 'textfield',
			'heading' 		=> __('Matching value', 'pcud_ml'),
			'param_name' 	=> 'val',
			'value' 		=> '',
		),
		
		 array(
            "type" => "textarea_html",
            "holder" => "div",
            "heading" => __("Contents", "pc_ml"),
            "param_name" => "content",
            "value" => '',
            "description" => __("Protected content", "pc_ml")
         )
	);
  
	// compile
	vc_map(
        array(
           	'name' 			=> 'PCUD - '. __('Conditional Block', 'pcud_ml'),
			'description'	=> __("Restrict contents basing on conditional matching", 'pc_ml'),
            'base' 			=> 'pcud-cond-block',
            'category' 		=> "PrivateContent",
			'icon'			=> PCUD_URL .'/img/vc_icon.png',
			'admin_enqueue_css'	 => PCUD_URL .'/css/vc_fix.css',
            'params' 		=> $params,
        )
    );

}
add_action('vc_before_init', 'pcud_on_visual_composer');


