<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if(!defined('ABSPATH')) exit;



class pcud_cond_block_on_elementor extends Widget_Base {
	
	 public function get_icon() {
      return 'emtr_lcweb_icon';
   }
	
	public function get_name() {
		return 'pcud-cond-block';
	}

	public function get_categories() {
		return array('privatecontent');
	}

   public function get_title() {
      return 'PCUD - '. __('Conditional Block', 'pcud_ml');
   }




	protected function _register_controls() {
		

		// get user fields
		include_once(PC_DIR .'/classes/pc_form_framework.php');
		include_once(PCUD_DIR .'/functions.php');
		
		register_taxonomy_pcud_fields();
		$f_fw = new pc_form;
		
		$user_fields = array( __('Choose a field ..', 'pcud_ml') => ' ');
		foreach($f_fw->fields as $field_id => $data) {
			if($field_id == 'username' || !in_array($field_id, pcud_wizards_ignore_fields(false))) {
				$user_fields[ $field_id ] = $data['label'];
			}
		}

		
		//////////////////////


		$this->start_controls_section(
			'main',
			array(
				'label' => __('Main Parameters', 'pcud_ml'),
			)
		);
   
		$this->add_control(
		   'f',
		   array(
			  'label' 	=> __('User data to display', 'pcud_ml'),
			  'type' 	=> Controls_Manager::SELECT,
			  'default' => current(array_keys( $user_fields )),
			  'options' => $user_fields
		   )
		);
		
		$this->add_control(
		   'cond',
		   array(
			  'label' 		=> __('Define condition', 'pcud_ml'),
			  'type' 	=> Controls_Manager::SELECT,
			  'default' => '=',
			  'options' => array(
			  	'=' 	=> __('is equal to', 'pcud_ml'),
				'!='	=> __('is different from', 'pcud_ml'),
				'big'	=> __('is greater than', 'pcud_ml'),
				'small'	=> __('is lower than', 'pcud_ml'),
				'like'	=> __('contains', 'pcud_ml')
			  )
		   )
		);
		
		$this->add_control(
		   'val',
		   array(
			  	'label' => __('Matching value', 'pcud_ml'),
				'type' 	=> Controls_Manager::TEXT,
		   )
		);
		
		$this->add_control(
		   'contents',
		   array(
			  	'label' => __("Contents to hide", "pc_ml"),
				'type' => Controls_Manager::WYSIWYG,
		   )
		);
		
		
		$this->end_controls_section();
   }


	
	////////////////////////


	protected function render() {
     	$vals = $this->get_settings();
		//var_dump($vals);

		$parts = array('f', 'cond', 'val');
		$params = '';
		
		foreach($parts as $part) {
			$params .= $part.'="';

			if(!isset($vals[$part])) {$vals[$part] = '';}
			$params .= $vals[$part].'" ';	
		}
		
		echo do_shortcode('[pcud-cond-block '. $params .']'. trim($vals['contents']) .'[/pcud-cond-block]');
	}


	protected function _content_template() {}
}
