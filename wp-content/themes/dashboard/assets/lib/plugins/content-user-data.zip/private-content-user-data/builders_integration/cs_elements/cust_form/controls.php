<?php

/**
 * Element Controls
 */
 
 
$form_arr = array();
$forms = get_terms('pcud_forms', 'hide_empty=0');

foreach($forms as $form) {
	$form_arr[] = array(
		'value' => $form->term_id,
		'label' => $form->name
	);	
}
 

/* FIELDS */
$fields =  array(
	'form' => array(
		'type'    => 'select',
		'ui' => array(
			'title'   => __('Custom form to use', 'pcud_ml'),
			'tooltip' => '',
		),
		'options' => array(
			'choices' => $form_arr
		),
	),
	
	'layout' => array(
		'type'    => 'select',
		'ui' => array(
			'title'   => __('Layout', 'pc_ml'),
			'tooltip' => '',
		),
		'options' => array(
			'choices' => array(
				array('value' => '', 		'label' => __('Default one', 'pc_ml')),
				array('value' => 'one_col', 'label' => __('Single column', 'pc_ml')),
				array('value' => 'fluid',	'label' => __('Fluid (multi column)', 'pc_ml')),
			)
		)
	),
	
	'align' => array(
		'type'    => 'select',
		'ui' => array(
			'title'   => __('Alignment', 'pcud_ml'),
			'tooltip' => '',
		),
		'options' => array(
			'choices' => array(
				array('value' => 'center', 	'label' => __('Center', 'pcud_ml')),
				array('value' => 'left', 	'label' => __('Left', 'pcud_ml')),
				array('value' => 'right',	'label' => __('Right', 'pcud_ml')),
			)
		)
	),
);

return $fields;
