<?php
// ADD-ON SETTINGS - INTEGRATED IN PVTCONTENT AND MAIL ACTION ONES


/////////////////////////////////////////////////
// ADD PSW FORCED RESET text into settings //////
/////////////////////////////////////////////////

function pcud_cf_fpr_legend($structure) {
	$to_edit = $structure['main_opts'];
	$ml_key = 'pcud_ml';
	
	
	// PCMA - force reset on password retrieval
	if(defined('PCMA_VER') && PCMA_VER >= 1.7) {
		$pcma_f = array(
			'pcud_fpr_on_pcma_recovery' => array(
				'label' => __('Force on Mail Actions add-on password recovery?', $ml_key),
				'type'	=> 'checkbox',
				'note'	=> __('If checked, forces password reset when user logs in through password recovery system', $ml_key),
			),
		);	
	} else {
		$pcma_f = array();	
	}
	
	$to_add = array(
		'pcud_fpr_legend_wrap' => array(
			'sect_name'	=>  'User Data add-on - '. __('Forced Password Reset', $ml_key),
			'fields' 	=> array(
			
				'pcud_fpr_legend' => array(
					'label'	 	=> __('Password reset legend', $ml_key),
					'type'		=> 'textarea',
					'def'		=> __('Due to security reasons, you must change your password.
Please insert a new password, different from the past one.', $ml_key),
					'fullwidth' => true,
					'required'	=> true,
					'note'		=> __('This text will be used in the form, above password fields. Is mandatory and supports HTML.', $ml_key)
				),
			) + $pcma_f,
		),
	);
	
	$structure['main_opts'] = pc_inject_array_elem($to_add, $to_edit, 'analytics');
	return $structure;
}
add_filter('pc_settings_structure', 'pcud_cf_fpr_legend');




/////////////////////////////////////////////////
// ADD CUSTOM FORM BUTTON'S ICON into settings //
/////////////////////////////////////////////////

function pcud_cf_btn_icon_field($field_id, $field, $value, $all_vals) {
	$icon = get_option($field_id);
	?>
    <tr class="pc_<?php echo $field_id ?>_tr">
		<td class="lcwp_sf_label">
        	<label>User Data add-on - <?php _e("Custom form button's icon", 'pcud_ml') ?></label>
        </td>
		<td class="lcwp_sf_field">
			
            <div class="pc_field_icon_trigger">
            	<i class="fa <?php echo $icon ?>" title="set icon" style="display: inline-block;"></i>
                <input type="hidden" name="<?php echo $field_id ?>" value="<?php echo $icon ?>" maxlength="40" /> 
            </div>
		</td>
	</tr>
    <?php
}
function pcud_cf_btn_opt($structure) {
	$structure['styling']['button_icons']['fields']['pcud_cf_btn_icon'] = array(
		'type'		=> 'custom',
		'callback'	=> 'pcud_cf_btn_icon_field',
		'validation'=> array(
			array('index' => 'pcud_cf_btn_icon', 'label' => "User Data add-on - Custom Form button's icon"),
		)
	);
	return $structure;
}
add_filter('pc_settings_structure', 'pcud_cf_btn_opt');




/////////////////////////////////////////////
// ADD DATEPICKER style into settings  //////
/////////////////////////////////////////////

function pcud_datepicker_style_opt($structure) {
	include_once(PC_DIR . '/functions.php');
	
	$to_edit = $structure['styling']['colors']['fields'];
	$to_add = array(
		'pc_datepicker_col' => array(
			'label' => __("Datepicker style", 'pcud_ml'),
			'type'	=> 'select',
			'val' 	=> array(
				'light' => __('Light', 'pc_ml'), 
				'dark'	=> __('Dark', 'pc_ml')
			),
			'note'	=> ''
		)
	);
	
	$structure['styling']['colors']['fields'] = pc_inject_array_elem($to_add, $to_edit, 'pg_recaptcha_col');
	return $structure;
}
add_filter('pc_settings_structure', 'pcud_datepicker_style_opt');




/////////////////////////////////////////////////////////////////




// MAIL ACTIONS INTEGRATIONS 
if(is_plugin_active('private-content-mail-actions/pc_mail_actions.php') || is_plugin_active('pvtcontent_bundle/pvtcontent_bundle.php') || defined('PCMA_DIR')) :

// pcma settings - add tab	
function pcud_pcma_tabs($tabs) {
	$tabs['pcud_data_update'] = 'User Data add-on';
	return $tabs;	
}
add_filter('pcma_settings_tabs', 'pcud_pcma_tabs');	
	


// receivers - custom field
// Admin notifier - receiver email address
function pcud_sfan_receivers_field($field_id, $field, $value, $all_vals) {
	?>
    <tr class="pcma_<?php echo $field_id ?>">
		<td class="lcwp_sf_label"><label><?php _e("Receiver's e-mail address", 'pcud_ml') ?></label></td>
		<td class="lcwp_sf_field" colspan="2">
			
            <?php $val = (is_array($value)) ? implode(',', $value) : $value; ?>
            <input type="text" name="<?php echo $field_id ?>" value="<?php echo $val ?>" autocomplete="off" />
			
            <p class="lcwp_sf_note"><?php _e('E-mail receiving the notification - multiple addresses supported, <strong>comma split</strong>', 'pcud_ml') ?></p> 
		</td>
	</tr>
    <?php
}

	
// pcma settings - add tab contents	
function pcud_pcma_tab_content($structure) {
	
	$def_subj 	= __("User's data updated", 'pcud_ml');
	$def_txt	= __('Hello, 
%USERNAME% has just updated its data through custom form.', 'pcma_ml');
	
	$structure['pcud_data_update'] = array(
		'pcud_du_enable' => array(
			'sect_name'	=>  __('Custom Forms Submission Notifier', 'pcma_ml'),
			'fields' 	=> array(
				
				'pcud_sf_admin_notif' => array(
					'label' => __('E-mail admins on custom form submission?', 'pcma_ml'),
					'type'	=> 'checkbox',
					'def'	=> false,
					'note'	=> __("If checked, notifies admins when a custom form is submitted by a user", 'pcma_ml'),
				),
				'pcud_sfan_receivers' => array(
					'type'		=> 'custom',
					'callback'	=> 'pcud_sfan_receivers_field',
					'validation'=> array(
						array('index' => 'pcud_sfan_receivers', 'label' => __("User Data add-on - receiver's e-mail address", 'pcud_ml'))
					)
				),
			),
		),
		
		'pcud_du_mail_builder' => array(
			'sect_name'	=>  __('E-mail builder', 'pcma_ml'),
			'fields' 	=> array(
				
				'nnu_legend' => pcma_phs_legend(
					array(
						'%SITE-TITLE%'	=> __('Website title specified in WP settings', 'pcud_ml'),
						'%NAME%'		=> __("User's name", 'pcud_ml'),
						'%SURNAME%'		=> __("User's surame", 'pcud_ml'),
						'%USERNAME%'	=> __("User's userame", 'pcud_ml'),
						'%MAIL%'		=> __("User's e-mail", 'pcud_ml'),
						'%TEL%'			=> __("User's telephone", 'pcud_ml'),
						'%CAT%'			=> __("User categories", 'pcud_ml'),
					)
				),
				'pcud_sfan_title' => array(
					'label' 	=> __('E-mail title', 'pcud_ml'),
					'type'		=> 'text',
					'def' 		=> $def_subj,
					'fullwidth' => true,
				),
				'pcud_sfan_txt' => array(
					'label' => __("E-mail text", 'pcud_ml'),
					'type'	=> 'wp_editor',
					'def' 	=> $def_txt,
					'rows' 	=> 13,
				), 
			),
		),
	);
	
	return $structure;
}
add_action('pcma_settings_structure', 'pcud_pcma_tab_content');		
 
  	
// pcma settings - explode mail receivers
function pcud_pcma_before_save_settings($fdata) {
	
	if(!empty($fdata['pcud_sfan_receivers'])) {
		$fdata['pcud_sfan_receivers'] = explode(',', $fdata['pcud_sfan_receivers']);	
	}
			
	return $fdata;	
}
add_filter('pcma_before_save_settings', 'pcud_pcma_before_save_settings');	


// pcma settings - custom validation
function pcud_pcma_setting_errors($errors, $fdata) {
	
	if(!empty($fdata['pcud_sf_admin_notif'])) {
		if(empty($fdata['pcud_sfan_receivers']) || empty($fdata['pcud_sfan_title']) || empty($fdata['pcud_sfan_txt'])) {
			//$errors[ __('Custom Forms Submission Notifier', 'pcud_ml') ] = __('All fields must be filled to enable it', 'pcud_ml'); 	
			$errors[ __('User Data add-on', 'pcud_ml') ] = __('All fields must be filled to enable it', 'pcud_ml'); // better readability by customers
		}
	}
			
	return $errors;	
}
add_filter('pcma_setting_errors', 'pcud_pcma_setting_errors', 10, 2);	




// pcma settings - send e-mail
function pcud_pcma_send_email($indexes) {
	if(function_exists('pcma_is_active') && pcma_is_active() && get_option('pcud_sf_admin_notif')) {
		include_once(PCMA_DIR . '/functions.php');
		
		$txt = pcma_replace_placeholders($GLOBALS['pc_user_id'], get_option('pcud_sfan_txt'));
		$title = pcma_replace_placeholders($GLOBALS['pc_user_id'], get_option('pcud_sfan_title'));
		$mail_sent = pcma_send_mail('', get_option('pcud_sfan_receivers'), $title, $txt);
	}	
}
add_action('pcud_user_updated_data', 'pcud_pcma_send_email');


// mail actions integration's end	
endif;
