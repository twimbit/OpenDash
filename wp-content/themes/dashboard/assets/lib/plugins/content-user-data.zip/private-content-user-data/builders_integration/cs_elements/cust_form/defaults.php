<?php

/**
 * Defaults Values
 */

return array(
	'form'		=> '',
	'layout'	=> ''
);