<?php

/**
 * Element Controls
 */
 

/* FIELDS */
$fields =  array(
	'f' => array(
		'type'    => 'select',
		'ui' => array(
			'title'   => __('Field to match', 'pcud_ml'),
			'tooltip' => '',
		),
		'options' => array(
			'choices' => pcud_cs_fl_array()
		),
	),
	
	'cond' => array(
		'type'    => 'select',
		'ui' => array(
			'title'   => __('Define condition', 'pcud_ml'),
			'tooltip' => '',
		),
		'options' => array(
			'choices' => array(
				array('label' => __('is equal to', 'pcud_ml'), 			'value' => '='),
				array('label' => __('is different from', 'pcud_ml'), 	'value' => '!='),
				array('label' => __('is greater than', 'pcud_ml'), 		'value' => 'big'),
				array('label' => __('is lower than', 'pcud_ml'), 		'value' => 'small'),
				array('label' => __('contains', 'pcud_ml'), 			'value' => 'like')
			)
		)
	),
	
	'val' => array(
		'type'    => 'text',
		'ui' => array(
			'title'   => __('Matching value', 'pcud_ml'),
		),
	),
	
	'content' => array(
		'type'    => 'editor',
		'ui' => array(
			'title'   => __("Contents", "pc_ml"),
			'tooltip' => '',
		),
		'context' => 'content',
		'suggest' => ''
    ),
);



return $fields;
