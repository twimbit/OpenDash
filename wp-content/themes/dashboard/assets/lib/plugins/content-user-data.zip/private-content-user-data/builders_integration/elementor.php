<?php
// Elementor integration
include_once( ABSPATH . 'wp-admin/includes/plugin.php');
if(is_plugin_active('elementor/elementor.php') ) {
if(!defined('ABSPATH')) exit;



class pcud_on_elementor {
	private $widgets_basepath = '';

	
	public function __construct() {
		
		/*** enqueue ***/
		$this->widgets_basepath = PCUD_DIR .'/builders_integration/elementor_elements';
		
		add_action('elementor/widgets/widgets_registered', array( $this, 'register_pcud_form'));
		add_action('elementor/widgets/widgets_registered', array( $this, 'register_pcud_user_data'));
		add_action('elementor/widgets/widgets_registered', array( $this, 'register_pcud_cond_block'));
	}
		 
		 
	
	// login
	public function register_pcud_form() {
		include_once($this->widgets_basepath .'/cust_form.php');
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new pcud_form_on_elementor() );
	}
	
	// logout
	public function register_pcud_user_data() {
		include_once($this->widgets_basepath .'/user_data.php');
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new pcud_user_data_on_elementor() );
	}
	
	// user deletion
	public function register_pcud_cond_block() {
		include_once($this->widgets_basepath .'/cond_block.php');
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new pcud_cond_block_on_elementor() );
	}

}
add_action('wp_loaded', function() {
	new pcud_on_elementor();
}, 1);




////
} // end elementor's existence check