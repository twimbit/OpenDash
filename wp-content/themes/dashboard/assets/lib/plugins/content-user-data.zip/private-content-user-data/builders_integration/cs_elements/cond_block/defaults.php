<?php

/**
 * Defaults Values
 */

return array(
	'f'		=> '',
	'cond'	=> '',
	'val'	=> ''
);