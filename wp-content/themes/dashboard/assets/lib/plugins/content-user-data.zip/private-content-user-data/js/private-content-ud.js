/**************************
   HANDLING CUSTOM FORMS
**************************/	

jQuery(document).ready(function($) {
	
	$('body').delegate('.pc_custom_form_btn:not(.pc_loading_btn)', 'click', function(e) {
		e.preventDefault();
		
		$pcud_target_form = $(this).parents('form');
		
		// maintain textarea line breaks
		$pcud_target_form.find('textarea').each(function() {
            $(this).val( $(this).val().replace(/\r\n|\r|\n/gi, "<br />") );
        });
		
	
		var f_data = $(this).parents('form').serialize();
		
		// HTML5 validate first
		if(!$pcud_target_form.pc_validate_form_fieldset()) {
			return false;	
		}
		
		// restore textarea values
		$pcud_target_form.find('textarea').each(function() {
            $(this).val( $(this).val().replace(/<br \/>/gi,"\n") );
        });


		$pcud_target_form.find('.pc_custom_form_btn').addClass('pc_loading_btn');
		$pcud_target_form.find('.pc_custom_form_message').empty();
		
		$.ajax({
			type: "POST",
			url: window.location.href,
			data: "type=pcud_cf_submit&" + f_data,
			dataType: "json",
			success: function(pc_data){
				if(pc_data.resp == 'success') {
					$pcud_target_form.find('.pc_custom_form_message').empty().append('<span class="pc_success_mess">' + pc_data.mess + '</span>');
				}
				else {
					$pcud_target_form.find('.pc_custom_form_message').empty().append('<span class="pc_error_mess">' + pc_data.mess + '</span>');
				}
				
				// redirect
				if(typeof(pc_data.redirect) != 'undefined' && pc_data.redirect) {
					setTimeout(function() {
					  window.location.href = pc_data.redirect;
					}, 1000);		
				}
				
				// a bit of delay to display the loader
				setTimeout(function() {
					$pcud_target_form.find('.pc_custom_form_btn').removeClass('pc_loading_btn');
				}, 370);
			}
		});
	});
	
	// enter key handler
	$('.pc_custom_form .pc_rf_field input').keypress(function(event){
		if(event.keyCode === 13){
			$(this).parents('form').find('.pc_custom_form_btn').trigger('click');
		}
		
		event.cancelBubble = true;
		if(event.stopPropagation) event.stopPropagation();
   	});
	
	
	// datepicker
	if($('.pcud_datepicker').length) {
		var pcud_datepicker_init = function(type) {
			return {
				dateFormat : (type == 'eu') ? 'dd/mm/yy' : 'mm/dd/yy',
				beforeShow: function(input, inst) {
					if( !$('#ui-datepicker-div').parent().hasClass('pcud_dp') ) {
						$('#ui-datepicker-div').wrap('<div class="pcud_dp"></div>');
					}
				},
				monthNames: 		pcud_datepick_str.monthNames,
				monthNamesShort: 	pcud_datepick_str.monthNamesShort,
				dayNames: 			pcud_datepick_str.dayNames,
				dayNamesShort: 		pcud_datepick_str.dayNamesShort,
				dayNamesMin:		pcud_datepick_str.dayNamesMin,
				isRTL:				pcud_datepick_str.isRTL
			};	
		}
		
		$('.pcud_dp_eu_date').datepicker( pcud_datepicker_init('eu') );
		$('.pcud_dp_us_date').datepicker( pcud_datepicker_init('us') );
	}
});
	