<?php
// PRIVATECONTENT INTEGRATIONS


///////////////////////////////////////////
/// ADD-ON MENU ///////////////////////////
///////////////////////////////////////////

add_action('pc_addons_menu_ready', 'pcud_in_pc_menu', 40);

function pcud_in_pc_menu($slug) {
	add_submenu_page($slug, __('Custom Fields Builder', 'pcud_ml'), __('Custom Fields Builder', 'pcud_ml'), 'install_plugins', 'pcud_fields_builder', 'pcud_cust_fields_builder');	
	add_submenu_page($slug, __('Custom Forms Builder', 'pcud_ml'), __('Custom Forms Builder', 'pcud_ml'), 'install_plugins', 'pcud_forms_builder', 'pcud_cust_forms_builder');
}
function pcud_cust_fields_builder() { include_once(PCUD_DIR . '/cust_fields_builder.php'); }
function pcud_cust_forms_builder() { include_once(PCUD_DIR . '/cust_forms_builder.php');	}





//////////////////////////////////////////////////////////////////////





///////////////////////////////////////////////
// ADD CUSTO FIELDS into framework ///////////
///////////////////////////////////////////////

function pcud_add_fields_into_pc($fields) {
	include_once(PCUD_DIR . '/functions.php');
	
	$pcud_fields = get_terms('pcud_fields', 'hide_empty=0');

	// if is WP error (called before taxonomies setup) - return fields
	if(is_wp_error($pcud_fields)) {return $fields;} 
	
	foreach($pcud_fields as $term) {
		$data = unserialize(base64_decode($term->description));
		$field_args = array('label' => pcud_wpml_translated_string($term->slug, $term->name));
		
		foreach($data as $index => $val) {
			if($index == 'opt') {
				$field_args[$index] = pcud_wpml_translated_string($term->slug, $val, 'options');	
			} 
			elseif($index == 'multi_select') {
				$field_args['multiple'] = (empty($val)) ? false : true;
			} 
			elseif($index == 'placeh') {
				$field_args[$index] = pcud_wpml_translated_string($term->slug, $val, 'placeh');	
			} 
			elseif($index == 'check_txt') {
				$field_args[$index] = pcud_wpml_translated_string($term->slug, $val, 'check_txt');	
			} 
			else {
				$field_args[$index] = $val;	
			}
		}
		
		$fields[$term->slug] = $field_args;
	}
	
	return $fields;
}
add_filter('pc_form_fields_filter', 'pcud_add_fields_into_pc');






///////////////////////////////////////////////
// USERS LIST - show custom fields ////////////
///////////////////////////////////////////////

function pcud_user_list_custom_fields($table_cols) {
	$to_show = get_option('pcud_fields_in_users_list', array());

	if(is_array($to_show)) {
		// avoid useless queries - use stored fields
		include_once(PC_DIR .'/classes/pc_form_framework.php');
		$f_fw = new pc_form;
		$fields = $f_fw->fields;
		
		foreach($to_show as $index) {
			if(isset($fields[$index])) {
				$table_cols[$index] = array(
					'name' 		=> $fields[$index]['label'],
					'sortable' 	=> (in_array($fields[$index]['type'], array('multi_select', 'checkbox'))) ? false : true,
				);
			}
		}
	}	
	  
	return $table_cols;	
}
add_filter('pc_users_list_table_fields', 'pcud_user_list_custom_fields');







//////////////////////////////////////////////////////////
// IMPORT PROCESS - add custom fields and try to import //
//////////////////////////////////////////////////////////

// form - wizard to add fields
function pcud_import_form($fields) {
	include_once(PCUD_DIR .'/functions.php');
	return array_merge($fields, pcud_sorted_fields_indexes()); 
}
add_filter('pc_import_custom_fields', 'pcud_import_form');








////////////////////////////////////////////////////
// ADMIN USER DASHBOARD - ADD AND VALIDATE FIELDS //
////////////////////////////////////////////////////


// validation
function pcud_user_dashboard_validation($form_structure) {
	include_once(PCUD_DIR .'/functions.php');
	
	$form_structure['include'] = array_merge($form_structure['include'], pcud_sorted_fields_indexes());  
	return $form_structure;
}
add_filter('pc_user_dashboard_validation', 'pcud_user_dashboard_validation');



// new dashboard tab
function pcud_user_dashboard_tabs($tabs) {
	return $tabs + array(
		'pcud' => 'User Data add-on'
	);	
}
add_filter('pc_user_dashboard_tabs', 'pcud_user_dashboard_tabs', 10);



// tab contents
function pcud_user_dashboard_tab_sections($sections, $user_id) {
	return 
	$sections + array(
		'pcud_fields' => array(
			'name'		=> '',
			'classes'	=> 'pc_ud_2_cols_form',
			'callback' 	=> 'pcud_user_dashboard_fields'
		)
	);	
}
add_filter('pc_user_dashboard_pcud_tab_sections', 'pcud_user_dashboard_tab_sections', 1, 2);



// code
function pcud_user_dashboard_fields($user_id = false) {
	include_once(PCUD_DIR .'/functions.php');
	include_once(PC_DIR .'/classes/pc_form_framework.php');
	
	global $pc_users;
	$form_fw = new pc_form;

	$custom_f_indexes = pcud_sorted_fields_indexes();
	if(empty($custom_f_indexes)) {return '';}
	
	
	// user data base array
	$ud = array();
	foreach($custom_f_indexes as $cfi) {
		$ud[$cfi] = '';	
	}

	// if editing - fill it
	if($user_id) {
		$ud = $pc_users->get_user($user_id, array(
			'to_get' => $custom_f_indexes
		));
	}
	
	
    $code = '
    <table class="widefat">
      <tbody>
	  	<tr>';
      
	  	$a = 1;
	  	foreach($custom_f_indexes as $f_index) {
			$f = $form_fw->fields[$f_index];
			$val = $ud[$f_index];
			
			// specific cases
			$placeh = isset($f['placeh']) ? 'placeholder="'.$f['placeh'].'"' : '';
			
			// label
			$code .= '
				<th>'. $f['label'] .'</th>
				<td>';
			
			
				//// code depending on field type
				if($f['type'] == 'text') {
					$dp_class = ($f['subtype'] == 'eu_date' || $f['subtype'] == 'us_date') ? 'class="pcud_datepicker pcud_dp_'.$f['subtype'].'"': '';
				   
					$code .= '
					<input type="'.$f['type'].'" name="'.$f_index.'" value="'.pc_sanitize_input($val).'" maxlength="'.$f['maxlen'].'" '.$placeh.' '. $dp_class.' autocomplete="off" />';
				}
				
				// textarea
				elseif($f['type'] == 'textarea') {
					$code .= '
					  <textarea name="'.$f_index.'" autocomplete="off" '.$placeh.' style="min-height: 45px;">'. str_replace('<br />', '
					', $val) .'</textarea>';
				}
				
				// select
				elseif($f['type'] == 'select' || $f['type'] == 'checkbox') {	
					$opts = $form_fw->get_field_options($f['opt']);
					$multiple = ($f['type'] == 'checkbox' || (isset($f['multiple']) && $f['multiple'])) ? 'multiple="multiple"' : '';
					$multi_name = ($multiple) ? '[]' : '';
					
					$code .= '
					<select name="'.$f_index.$multi_name.'"  class="lcwp_sf_chosen" '.$multiple.' data-placeholder="'. __('Select values', 'pcud_ml') .' .." autocomplete="off">';
					
						foreach($opts as $opt) { 
							$sel = (in_array($opt, (array)$val)) ? 'selected="selected"' : false;
							$code .= '<option value="'.$opt.'" '.$sel.'>'.$opt.'</option>'; 
						}
						
					$code.= '
					</select>';			
				}
				
				// assoc-select
				elseif($f['type'] == 'assoc_select') {	
					$opts = $form_fw->get_field_options($f['opt']);
					$multiple = (isset($f['multiple']) && $f['multiple']) ? 'multiple="multiple"' : '';
					$multi_name = ($multiple) ? '[]' : '';
					
					$code .= '
					<select name="'.$f_index.$multi_name.'"  class="lcwp_sf_chosen" '.$multiple.' data-placeholder="'. __('Select values', 'pcud_ml') .' .." autocomplete="off">';
					
						foreach($opts as $index => $name) { 
							$sel = (in_array($index, (array)$val)) ? 'selected="selected"' : false;
							$code .= '<option value="'.$index.'" '.$sel.'>'.$name.'</option>'; 
						}
						
					$code.= '
					</select>';			
				}
				
				// single-option checkbox
				elseif($f['type'] == 'single_checkbox') {	
					$checked = (empty($val)) ? '' : 'checked="checked"';
					$code .= '
					<input type="checkbox" name="'.$f_index.'" value="1" '.$checked.' class="lcwp_sf_check" autocomplete="off" />';
				}
		
		

			// change row each 2 fields
			if($a % 2 == 0) {
				$code .= ($a == (count($custom_f_indexes) + 1)) ? '</tr>' : '<tr></tr>';
			}
			
			$a++;
		}
			
	
	echo $code .'
		</tbody>
	</table>';
	
	
	?>
	<!-- datepicker init -->
	<script type='text/javascript'>
	jQuery(document).ready(function($) {
		if($('.pcud_datepicker').length) {
			// dynamically add datepicker style
			$('head').append("<link rel='stylesheet' href='<?php echo PCUD_URL ?>/css/datepicker/light/pcud_light.theme.min.css' type='text/css' media='all' />");
			
			var pcud_datepicker_init = function(type) {
				return {
					dateFormat : (type == 'eu') ? 'dd/mm/yy' : 'mm/dd/yy',
					beforeShow: function(input, inst) {
						jQuery('#ui-datepicker-div').wrap('<div class="pcud_dp"></div>');
					},
					monthNames: 		pcud_datepick_str.monthNames,
					monthNamesShort: 	pcud_datepick_str.monthNamesShort,
					dayNames: 			pcud_datepick_str.dayNames,
					dayNamesShort: 		pcud_datepick_str.dayNamesShort,
					dayNamesMin:		pcud_datepick_str.dayNamesMin,
					isRTL:				pcud_datepick_str.isRTL
				};	
			}
			
			$('.pcud_dp_eu_date').datepicker( pcud_datepicker_init('eu') );
			$('.pcud_dp_us_date').datepicker( pcud_datepicker_init('us') );
		}
	});
	</script>
	<?php
}




////////////////////////////////////////////////////
// ADMIN USER DASHBOARD - FORCE PSW RESET BOX //////
////////////////////////////////////////////////////


// tab contents
function pcud_ud_force_psw_reset($sections, $user_id) {
	if(!$user_id)  {
		return $sections;	
	}
	
	return 
	$sections + array(
		'pcud_fpr' => array(
			'name'		=> 'User Data add-on - '. __('Forced Password Reset', 'pcud_ml'),
			'classes'	=> 'pc_ud_onehalf_w lor',
			'callback' 	=> 'pcud_ud_force_psw_reset_cb'
		)
	);	
}
add_filter('pc_user_dashboard_main_tab_sections', 'pcud_ud_force_psw_reset', 30, 2);



// code
function pcud_ud_force_psw_reset_cb($user_id) {
	global $pc_meta;
	$fpr_key = $pc_meta->get_meta($user_id, 'pcud_forced_psw_reset');
	
	$ok_vis  = (empty($fpr_key)) ? '' : 'style="display: none;"';
	$req_vis = (empty($fpr_key)) ? 'style="display: none;"' : '';
	
	?>
	<div id="pcud_fpr_ok" class="pc_warn pc_wps_warn pc_success" <?php echo $ok_vis ?>>
		<?php _e('Password status ok', 'pcud_ml') ?>
        <button class="button-secondary pcud_fpr_change_status"><?php _e('Change Status', 'pcud_ml') ?></button>
	</div>     
	
	<div id="pcud_fpr_required" class="pc_warn pc_wps_warn pc_warning" <?php echo $req_vis ?>>
		<?php _e('Password reset required', 'pcud_ml') ?>
        <button class="button-secondary pcud_fpr_change_status"><?php _e('Change Status', 'pcud_ml') ?></button>
	</div>     

	<script type="text/javascript">
	jQuery(document).ready(function($) {
		var pcud_fpr_acting = false;

		$(document).delegate('.pcud_fpr_change_status', 'click', function(e) {		
			e.preventDefault();
			if(pcud_fpr_acting) {return false;}
			
			pcud_fpr_acting = true;
			var $btn = $(this);
			$btn.fadeTo(200, 0.7);

			var cmd = ($(this).parents('#pcud_fpr_required').length) ? 'unset' : 'set';
			
			var data = {
				action		: 'pcud_fpr_in_edit_user',
				pc_cmd		: cmd,
				pc_user_id	: <?php echo $user_id; ?>,
				pc_nonce	: '<?php echo wp_create_nonce('lcwp_ajax') ?>'
			};
			$.post(ajaxurl, data, function(response) {
				if($.trim(response) == 'success') {
					if(cmd == 'set') {
						$('#pcud_fpr_ok').hide();
						$('#pcud_fpr_required').show();
					} else {
						$('#pcud_fpr_ok').show();
						$('#pcud_fpr_required').hide();	
					}
				}
				else {
					pc_toast_message('error', response);
				}
				
				pcud_fpr_acting = false;
				$btn.fadeTo(200, 0.7);
			});
		});
	});
	</script>
	<?php
}
