<?php

/**
 * Defaults Values
 */

return array(
	'f' 	=> ''
);