<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if(!defined('ABSPATH')) exit;



class pcud_form_on_elementor extends Widget_Base {
	
	 public function get_icon() {
      return 'emtr_lcweb_icon';
   }
	
	public function get_name() {
		return 'pcud-form';
	}

	public function get_categories() {
		return array('privatecontent');
	}

   public function get_title() {
      return 'PCUD - '. __('Custom Form', 'pcud_ml');
   }



   protected function _register_controls() {
			
		// get forms	
		$forms_arr = array();
		$forms = get_terms('pcud_forms', 'hide_empty=0');
		
		foreach($forms as $form) {
			$forms_arr[ $form->term_id ] = $form->name;	
		}	
		
		
		//////////////////////
			
			
		$this->start_controls_section(
			'main',
			array(
				'label' => __('Main Parameters', 'pcud_ml'),
			)
		);
  
		$this->add_control(
		   'form',
		   array(
			  'label' 	=> __('Which form?', 'pcud_ml'),
			  'type' 	=> Controls_Manager::SELECT,
			  'default' => current(array_keys( $forms_arr )),
			  'options' => $forms_arr
		   )
		);
		
		$this->add_control(
		   'layout',
		   array(
			  'label' 	=> __('Layout', 'pcud_ml'),
			  'type' 	=> Controls_Manager::SELECT,
			  'default' => '',
			  'options' => array(
			  	'' 			=> __('Default one', 'pcud_ml'),
				'one_col' 	=> __('Single column', 'pcud_ml'),
				'fluid'		=> __('Fluid (multi column)', 'pcud_ml'),
			  )
		   )
		);
		
		$this->add_control(
		   'align',
		   array(
			  'label' 	=> __('Alignment', 'pcud_ml'),
			  'type' 	=> Controls_Manager::SELECT,
			  'default' => 'center',
			  'options' => array(
			  	'center' 	=> __('Center', 'pcud_ml'),
				'left'		=> __('Left', 'pcud_ml'),
				'right'		=> __('Right', 'pcud_ml'),
			  )
		   )
		);
			
		$this->end_controls_section();
   }


	
	////////////////////////



	protected function render() {
     	$vals = $this->get_settings();
		//var_dump($vals);

		$parts = array('form', 'layout', 'align');
		$params = '';
		
		foreach($parts as $part) {
			$params .= $part.'="';
			
			if(!isset($vals[$part])) {$vals[$part] = '';}
			$params .= $vals[$part].'" ';	
		}
		
		echo do_shortcode('[pcud-form '. $params .']');
	}


	protected function _content_template() {}
}
