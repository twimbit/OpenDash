<?php
// Handle AJAX call for custom forms

add_action('init', 'pcud_handle_custom_form', 5); // use 5 to be sure taxonomies have been registered and auths performed

function pcud_handle_custom_form() {
	if(isset($_POST['type']) && $_POST['type'] == 'pcud_cf_submit') {
		require_once(PC_DIR .'/classes/pc_form_framework.php');
		require_once(PCUD_DIR .'/functions.php');
		global $wpdb, $pc_users;
		
		$f_fw = new pc_form;
		$form_id = (int)$_POST['pcud_fid']; 
		
		// check for logged users
		$pc_logged = pc_user_logged(false);
		if($pc_logged === false && !current_user_can(get_option('pg_min_role', 'upload_files'))) {
			die( json_encode(array( 
				'resp' => 'error',
				'mess' => __('You must be logged to use this form', 'pcud_ml') 
			)));
		}


		////////// VALIDATION ////////////////////////////////////
		
		// get form structure	
		$term = get_term_by('id', $form_id, 'pcud_forms');
		if(empty($term)) {
			die( json_encode(array( 
				'resp' => 'error',
				'mess' => __('Form not found', 'pcud_ml') 
			)));
		}
		
		if(empty($term->description)) {
			// retrocompatibility
			$form_fields = (array)get_option('pcud_form_'.$form_id, array());	
		} else {
			$form_fields = unserialize(base64_decode($term->description));	
		}

	
		$indexes = $f_fw->generate_validator( pcud_v2_field_names_sanitize($form_fields) );
		
		$is_valid = $f_fw->validate_form($indexes, $cust_errors = array(), false, false);	
		$fdata = $f_fw->form_data;
		
		if(!$is_valid) {
			$error = $f_fw->errors;
		}
		else {
			$GLOBALS['pc_updating_user'] = true; // report that is updating user - avoid logout
			
			// check for redirects
			if(isset($form_fields['redirect']) && !empty($form_fields['redirect'])) {
				$redirect = ($form_fields['redirect'] == 'custom') ? $form_fields['cust_redir'] : get_permalink($form_fields['redirect']);
			}
			else {$redirect = '';}
			
			// if not PC user - stop here
			if(!$pc_logged) {
				die( json_encode(array( 
					'resp' 		=> 'success',
					'mess' 		=> __('Form submitted successfully.<br/> Not logged as PrivateContent user, nothing has been saved', 'pcud_ml'),
					'redirect'	=> $redirect
				)));	
			}

			// update user
			$result = $pc_users->update_user($GLOBALS['pc_user_id'], $fdata);
			if(!$result) {
				$error = $pc_users->validation_errors;	
			}
		}

		// results
		if(isset($error) && !empty($error)) {
			die( json_encode(array( 
				'resp' => 'error',
				'mess' => $error
			)));
		}
		else {
			// if is updating password - sync also cookie
			if(isset($fdata['psw'])) {
				setcookie('pc_user', $GLOBALS['pc_user_id'].'|||'. $pc_users->encrypt_psw($fdata['psw']), time() + (3600 * 6), '/');
			}
			
			
			// Create Google Analytics event
			if(isset($GLOBALS['pc_google_analytics'])) {
				$params = array(
					't'		=> 'event',
					'ec'	=> 'User Data add-on',
					'ea'	=> 'custom_form_save',
					'el'	=> 'Form "'. $term->name .'" saved',
					'ni'	=> 0,
				);
				$GLOBALS['pc_google_analytics']->call($params, $GLOBALS['pc_user_id']);
			}
			
			
			// PCUD-ACTION - user updated its data - passes form data
			do_action('pcud_user_updated_data', $fdata);	
			
			
			// custom message
			if(isset($form_fields['cust_mess']) && !empty($form_fields['cust_mess'])) {
				
				if(function_exists('icl_t')) {
					$mess = icl_t('PrivateContent User Data', 'Form #'.$form_id.' - custom message', $form_fields['cust_mess']);
				} else {
					$mess = $form_fields['cust_mess'];	
				}
			} 
			else {
				$mess = __('Data saved successfully', 'pcud_ml');
			}
			
			
			// success message
			$mess = json_encode(array( 
				'resp' 		=> 'success',
				'mess' 		=> $mess,
				'redirect'	=> $redirect
			));
			die($mess);
		}
		
		die(); // security block
	}
}



// Create Google Analytics event
function pcud_cf_saved($calls) {
	$calls['pcud_cf_save'] = array(
		't'		=> 'event',
		'ec'	=> 'User Data add-on',
		'ea'	=> 'custom_form_save',
		'el'	=> 'Custom form '. $_POST['pcud_fid'] .' saved',
		'ni'	=> 0,
	);
	return $calls;	
}